from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Any

from Journal_Experiment import (
    EXECUTION_SHARD_POLICY,
    TERMINAL_STATUSES,
    canonical_json,
    execution_shard_assignments,
    latest_attempts,
    machine_profile_errors,
    sha256_text,
)


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    records = []
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid JSONL line {line_number}: {exc}") from exc
    return records


def _is_blank(value: Any) -> bool:
    return value is None or str(value).strip() == ""


def _truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def _objective_vector(row: dict[str, Any]) -> tuple[int, ...] | None:
    raw = row.get("objective_vector")
    if _is_blank(raw):
        return None
    if isinstance(raw, (list, tuple)):
        return tuple(int(value) for value in raw)
    return tuple(int(value.strip()) for value in str(raw).split(",") if value.strip())


def waiting_metric_errors(row: dict[str, Any]) -> list[str]:
    """Check the new objective vector against the recorded participant costs."""
    try:
        raw = row["participant_internal_idle_slots"]
        values = [
            int(value)
            for value in (
                raw if isinstance(raw, (tuple, list)) else str(raw).split(",")
            )
        ]
        if not values or any(v < 0 for v in values):
            return ["missing or invalid participant idle costs"]
        total, maximum, squared = sum(values), max(values), sum(v * v for v in values)
        objective_mode = row["objective_mode"]
        if objective_mode in {"ir_im_is", "ir_im_isq"}:
            participants_raw = row["objective_participants"]
            participants = [
                int(value)
                for value in (
                    participants_raw
                    if isinstance(participants_raw, (tuple, list))
                    else str(participants_raw).split(",")
                )
                if str(value).strip()
            ]
            if any(participant < 1 or participant > len(values) for participant in participants):
                return ["invalid objective participant IDs"]
            pstar_values = [values[participant - 1] for participant in participants]
            idle_range = (
                max(pstar_values) - min(pstar_values)
                if len(pstar_values) >= 2
                else 0
            )
            maximum = max(pstar_values, default=0)
            expected = (
                (idle_range, maximum, squared)
                if objective_mode == "ir_im_isq"
                else (idle_range, maximum, total)
            )
        else:
            expected = {
                "is": (total,),
                "isq": (squared,),
                "im_is": (maximum, total),
            }[objective_mode]
        errors = []
        for field, value in (("total_internal_idle_slots", total),
                             ("maximum_internal_idle_slots", maximum),
                             ("squared_internal_idle_slots", squared)):
            if int(row[field]) != value:
                errors.append(f"{field} disagrees with participant costs")
        if objective_mode in {"ir_im_is", "ir_im_isq"} and int(row["idle_range_pstar"]) != idle_range:
            errors.append("idle_range_pstar disagrees with objective-participant costs")
        if row.get("participant_idle_cap_rule", "none") == "interpolated_bounds":
            raw_caps = row["participant_idle_caps"]
            caps = [
                int(value)
                for value in (
                    raw_caps
                    if isinstance(raw_caps, (tuple, list))
                    else str(raw_caps).split(",")
                )
            ]
            if len(caps) != len(values):
                errors.append("participant idle cap vector has wrong length")
            elif any(value > cap for value, cap in zip(values, caps)):
                errors.append("participant idle cap is violated")
        if _objective_vector(row) != expected:
            errors.append("waiting objective vector disagrees with participant costs")
        proven = _objective_vector({"objective_vector": row.get("proven_objective_vector")})
        if proven != expected:
            errors.append("proven waiting objective vector is missing or inconsistent")
        weights_raw = row["objective_tier_weights"]
        weights = [int(v) for v in (weights_raw if isinstance(weights_raw, (list, tuple))
                                   else str(weights_raw).split(","))]
        if len(weights) != len(expected) or any(v <= 0 for v in weights):
            errors.append("invalid objective tier weights")
        elif int(row["lexicographic_scalar_cost"]) != sum(w * v for w, v in zip(weights, expected)):
            errors.append("weighted solver cost disagrees with waiting objective")
        return errors
    except (ValueError, KeyError, TypeError):
        return ["missing or malformed waiting metrics/cost certificate"]


def validate_campaign(
    output_dir: Path,
    *,
    allow_dirty: bool = False,
    allow_incomplete: bool = False,
    allow_errors: bool = False,
    allow_environment_drift: bool = False,
) -> tuple[list[str], dict[str, Any]]:
    errors: list[str] = []
    try:
        plan = _read_json(output_dir / "plan.json")
    except FileNotFoundError:
        return ["missing plan.json"], {}
    common_gcp_assumed = plan.get("reuse_policy") == "validated_common_gcp"
    allow_environment_drift = allow_environment_drift or common_gcp_assumed
    try:
        environment = _read_json(output_dir / "environment.json")
    except FileNotFoundError:
        environment = {}
        errors.append("missing environment.json")
    try:
        records = _read_jsonl(output_dir / "raw" / "results.jsonl")
        latest = latest_attempts(records)
    except (ValueError, KeyError) as exc:
        return [f"invalid results.jsonl: {exc}"], {}

    jobs = {job["run_key"]: job for job in plan.get("jobs", [])}
    reuse_target_rules = {
        (
            str(rule["target_block_id"]),
            str(rule["target_configuration_id"]),
            int(rule["target_repetition"]),
        ): rule
        for rule in plan.get("reuse_results", [])
    }
    unhashed_plan = dict(plan)
    recorded_plan_sha256 = unhashed_plan.pop("plan_sha256", "")
    recomputed_plan_sha256 = sha256_text(canonical_json(unhashed_plan))
    if recorded_plan_sha256 != recomputed_plan_sha256:
        errors.append("plan.json content does not match plan_sha256")
    if len(jobs) != int(plan.get("job_count", -1)):
        errors.append("plan job_count does not match unique run keys")
    extra = sorted(set(latest) - set(jobs))
    missing = sorted(set(jobs) - set(latest))
    if extra:
        errors.append(f"results contain {len(extra)} unplanned run keys")
    if missing and not allow_incomplete:
        errors.append(f"campaign is missing {len(missing)} planned run keys")
    normalized_path = output_dir / "normalized" / "detailed.csv"
    if normalized_path.is_file():
        with normalized_path.open(newline="", encoding="utf-8") as stream:
            normalized_rows = list(csv.DictReader(stream))
        normalized_keys = [row.get("run_key", "") for row in normalized_rows]
        if len(normalized_keys) != len(set(normalized_keys)):
            errors.append("normalized/detailed.csv has duplicate run keys")
        if set(normalized_keys) != set(latest):
            errors.append("normalized/detailed.csv is stale or incomplete")
        for row in normalized_rows:
            record = latest.get(row.get("run_key", ""))
            if record is not None and str(row.get("attempt", "")) != str(
                record.get("attempt", "")
            ):
                errors.append(
                    f"{row.get('run_key')}: normalized attempt is not latest"
                )
    elif latest:
        errors.append("missing normalized/detailed.csv")

    if environment:
        if environment.get("plan_sha256") != plan.get("plan_sha256"):
            errors.append("environment/plan SHA-256 mismatch")
        if environment.get("git_dirty") and not allow_dirty:
            errors.append("production provenance records git_dirty=true")
        if (
            environment.get("environment_drift_accepted")
            and not allow_environment_drift
        ):
            errors.append(
                "campaign contains accepted environment drift; rerun validation "
                "with --allow-environment-drift"
            )
        if environment.get("required_machine", {}) != plan.get(
            "required_machine", {}
        ):
            errors.append("environment/plan required-machine profile mismatch")
        if not allow_environment_drift:
            for mismatch in machine_profile_errors(
                plan.get("required_machine"), environment
            ):
                errors.append(
                    f"production machine profile mismatch: {mismatch}"
                )
    expected_uwr_hash = str(environment.get("uwrmaxsat_sha256", ""))
    execution_shard_count = int(environment.get("execution_shard_count", 1))
    execution_shard_indices = tuple(
        int(value)
        for value in environment.get("execution_shard_indices", [0])
    )
    shard_assignments = execution_shard_assignments(plan, execution_shard_count)
    required_machine = plan.get("required_machine", {})
    peak_memory_fraction = required_machine.get("max_peak_memory_fraction")
    system_memory_mb = environment.get("system_memory_mb")
    try:
        peak_memory_limit_mb = (
            float(peak_memory_fraction) * float(system_memory_mb)
            if peak_memory_fraction is not None and system_memory_mb is not None
            else None
        )
    except (TypeError, ValueError):
        peak_memory_limit_mb = None

    status_counts: Counter[str] = Counter()
    result_origin_counts: Counter[str] = Counter()
    content_ids: set[str] = set()
    lineage_ids: set[str] = set()
    rows: list[dict[str, Any]] = []
    for run_key, record in latest.items():
        if run_key not in jobs:
            continue
        job = jobs[run_key]
        row = record.get("row", {})
        if record.get("run_key") != row.get("run_key"):
            errors.append(f"{run_key}: record/row run_key mismatch")
        rows.append(row)
        status = str(row.get("status", ""))
        status_counts[status] += 1
        if status == "ERROR" and not allow_errors:
            errors.append(f"{run_key}: terminal ERROR row")
        elif status not in TERMINAL_STATUSES and status != "ERROR":
            errors.append(f"{run_key}: unknown status {status!r}")
        for field in (
            "instance_content_id",
            "instance_sha256",
            "base_lineage_id",
            "experiment_block",
            "planned_configuration_id",
            "repetition",
            "run_order",
            "campaign_plan_sha256",
        ):
            expected = {
                "experiment_block": job["experiment_block"],
                "planned_configuration_id": job["planned_configuration_id"],
                "repetition": job["repetition"],
                "run_order": job["run_order"],
                "campaign_plan_sha256": plan["plan_sha256"],
            }.get(field, job.get(field))
            if str(row.get(field, "")) != str(expected):
                errors.append(
                    f"{run_key}: metadata mismatch for {field}: "
                    f"{row.get(field)!r}!={expected!r}"
                )
        reuse_rule = reuse_target_rules.get(
            (
                str(job["experiment_block"]),
                str(job["planned_configuration_id"]),
                int(job["repetition"]),
            )
        )
        cell_rule = plan.get("reuse_cells", {}).get(run_key)
        if cell_rule is not None:
            reuse_rule = cell_rule
        result_origin = str(row.get("result_origin", "") or "executed")
        result_origin_counts[result_origin] += 1
        if reuse_rule is not None and result_origin != "reused":
            errors.append(f"{run_key}: planned reused result was executed")
        elif reuse_rule is None and result_origin == "reused":
            errors.append(f"{run_key}: unplanned reused result")
        elif result_origin not in {"executed", "reused"}:
            errors.append(f"{run_key}: unknown result origin {result_origin!r}")
        if reuse_rule is not None and result_origin == "reused":
            expected_reuse = {
                "reused_from_campaign_id": reuse_rule["source_campaign_id"],
                "reused_from_experiment_block": reuse_rule["source_block_id"],
                "reused_from_configuration_id": reuse_rule[
                    "source_configuration_id"
                ],
                "reused_from_repetition": reuse_rule["source_repetition"],
            }
            for field, expected in expected_reuse.items():
                if str(row.get(field, "")) != str(expected):
                    errors.append(
                        f"{run_key}: reuse provenance mismatch for {field}"
                    )
            expected_source_run_key = cell_rule["source_run_key"] if cell_rule else "::".join(
                (
                    str(reuse_rule["source_campaign_id"]),
                    str(reuse_rule["source_block_id"]),
                    str(job["instance_content_id"]),
                    str(reuse_rule["source_configuration_id"]),
                    f"rep-{reuse_rule['source_repetition']}",
                )
            )
            if row.get("reused_from_run_key") != expected_source_run_key:
                errors.append(f"{run_key}: reused source run key mismatch")
            if cell_rule and row.get("reused_source_record_sha256") != cell_rule.get(
                "source_row_sha256"
            ):
                errors.append(f"{run_key}: reused source-row hash mismatch")
            for field in (
                "reused_from_plan_sha256",
                "reused_source_record_sha256",
            ):
                if not re.fullmatch(r"[0-9a-f]{64}", str(row.get(field, ""))):
                    errors.append(f"{run_key}: invalid {field}")
        expected_mode = job["configuration"].get("objective_mode", "")
        if str(row.get("objective_mode", "")) != str(expected_mode):
            errors.append(f"{run_key}: objective_mode mismatch")
        if execution_shard_count > 1:
            expected_shard_index = shard_assignments[run_key]
            row_shard_indices = tuple(
                int(value.strip())
                for value in str(
                    row.get("execution_shard_indices", "")
                ).split(",")
                if value.strip()
            )
            try:
                row_shard_count = int(row.get("execution_shard_count", -1))
                row_shard_index = int(row.get("execution_shard_index", -1))
            except (TypeError, ValueError):
                row_shard_count = -1
                row_shard_index = -1
            if row_shard_count != execution_shard_count:
                errors.append(f"{run_key}: execution shard count mismatch")
            if environment.get("merged_from_shards"):
                if expected_shard_index not in row_shard_indices:
                    errors.append(
                        f"{run_key}: source shard assignment mismatch"
                    )
            elif row_shard_indices != execution_shard_indices:
                errors.append(f"{run_key}: execution shard assignment mismatch")
            if row_shard_index != expected_shard_index:
                errors.append(f"{run_key}: execution shard index mismatch")
            if row.get("execution_shard_policy") != EXECUTION_SHARD_POLICY:
                errors.append(f"{run_key}: execution shard policy mismatch")
            if expected_shard_index not in execution_shard_indices:
                errors.append(f"{run_key}: result belongs to an unassigned shard")
        is_shared_boolean_model = (
            job["configuration"].get("executor") == "main"
        )
        expected_compact = job["configuration"].get(
            "compact_encoding", "reference"
        )
        if is_shared_boolean_model and str(
            row.get("compact_encoding", "")
        ) != str(expected_compact):
            errors.append(f"{run_key}: compact_encoding mismatch")
        expected_collision_amo = job["configuration"].get(
            "collision_amo", "pairwise"
        )
        observed_collision_amo = row.get("collision_amo", "")
        if (
            _is_blank(observed_collision_amo)
            and "collision_amo" not in job["configuration"]
        ):
            observed_collision_amo = "pairwise"
        if is_shared_boolean_model and str(
            observed_collision_amo
        ) != str(expected_collision_amo):
            errors.append(f"{run_key}: collision_amo mismatch")
        expected_cap_rule = job["configuration"].get(
            "participant_idle_cap_rule", "none"
        )
        expected_cap_alpha = str(
            job["configuration"].get("participant_idle_cap_alpha", "1/2")
        )
        if is_shared_boolean_model and str(
            row.get("participant_idle_cap_rule", "none")
        ) != expected_cap_rule:
            errors.append(f"{run_key}: participant_idle_cap_rule mismatch")
        if is_shared_boolean_model and expected_cap_rule != "none":
            try:
                observed_alpha = Fraction(
                    str(row.get("participant_idle_cap_alpha"))
                )
            except (ValueError, ZeroDivisionError):
                observed_alpha = None
            if observed_alpha != Fraction(expected_cap_alpha):
                errors.append(f"{run_key}: participant_idle_cap_alpha mismatch")
        if (
            is_shared_boolean_model
            and expected_collision_amo == "adaptive_commander"
            and not _is_blank(row.get("collision_amo_max_group_size"))
            and int(float(row["collision_amo_max_group_size"])) >= 6
            and int(float(row.get("collision_amo_commander_group_count") or 0))
            <= 0
        ):
            errors.append(
                f"{run_key}: adaptive commander selected but no group encoded"
            )
        if is_shared_boolean_model and expected_mode == "bg_d2" and expected_compact in {
            "certified_bg",
            "optimized",
        }:
            branch = str(row.get("zero_break_branch", ""))
            if branch not in {"certified", "general_fallback"}:
                errors.append(
                    f"{run_key}: missing certified/fallback BG-d2 branch"
                )
        for field, requirement in (
            ("threads", required_machine.get("threads_per_run")),
            ("random_seed", required_machine.get("random_seed")),
        ):
            value = row.get(field)
            if requirement is not None and not _is_blank(value):
                if str(value) != str(requirement):
                    errors.append(
                        f"{run_key}: {field}={value!r}, expected {requirement!r}"
                    )
        row_peak_memory_limit_mb = peak_memory_limit_mb
        if allow_environment_drift and peak_memory_fraction is not None:
            try:
                row_peak_memory_limit_mb = float(peak_memory_fraction) * float(
                    row.get("system_memory_mb")
                )
            except (TypeError, ValueError):
                row_peak_memory_limit_mb = peak_memory_limit_mb
        if row_peak_memory_limit_mb is not None and status in TERMINAL_STATUSES:
            peak_memory_mb = row.get("peak_memory_mb")
            if _is_blank(peak_memory_mb):
                errors.append(f"{run_key}: missing peak_memory_mb")
            elif float(peak_memory_mb) > row_peak_memory_limit_mb:
                errors.append(
                    f"{run_key}: peak_memory_mb={peak_memory_mb} exceeds "
                    f"{float(peak_memory_fraction):.0%} of system RAM "
                    f"({row_peak_memory_limit_mb:.3f} MiB)"
                )
        if status == "OPTIMAL":
            if _objective_vector(row) is None:
                errors.append(f"{run_key}: OPTIMAL row has no objective vector")
            if not _is_blank(row.get("validation_errors")):
                errors.append(f"{run_key}: OPTIMAL row has validation errors")
            if _truthy(row.get("runtime_censored")):
                errors.append(f"{run_key}: OPTIMAL row is marked censored")
        if expected_mode in {"is", "isq", "im_is", "ir_im_is", "ir_im_isq"} and status == "OPTIMAL":
            errors.extend(f"{run_key}: {error}" for error in waiting_metric_errors(row))
        if status == "TIMEOUT" and not _truthy(row.get("runtime_censored")):
            errors.append(f"{run_key}: TIMEOUT row is not marked censored")
        row_uwr_hash = str(row.get("solver_binary_sha256", ""))
        configuration = job["configuration"]
        requires_uwr = (
            configuration.get("executor") in {"org_ir", "org_idle"}
            or (
                configuration.get("executor") == "org_bg_d2"
                and configuration.get("backend", "uwrmaxsat") == "uwrmaxsat"
            )
            or (
                configuration.get("executor") == "main"
                and configuration.get("solver") == "maxsat"
                and configuration.get("maxsat_backend", "uwrmaxsat")
                == "uwrmaxsat"
            )
        )
        if requires_uwr and not row_uwr_hash:
            errors.append(f"{run_key}: missing required UWrMaxSAT binary hash")
        if (
            not allow_environment_drift
            and row_uwr_hash
            and expected_uwr_hash
            and row_uwr_hash != expected_uwr_hash
        ):
            errors.append(f"{run_key}: solver binary SHA-256 drift")
        content_ids.add(str(row.get("instance_content_id", "")))
        lineage_ids.add(str(row.get("base_lineage_id", "")))

    # Every exact representation/method solving the same content/objective and
    # repetition must agree. Timeouts are omitted, but OPTIMAL versus UNSAT is
    # always an inconsistency.
    agreement_groups: dict[
        tuple[str, str, str, str, str], list[dict[str, Any]]
    ] = defaultdict(list)
    for row in rows:
        agreement_groups[
            (
                str(row.get("instance_content_id", "")),
                str(row.get("objective_mode", "")),
                str(row.get("participant_idle_cap_rule", "none")),
                str(row.get("participant_idle_cap_alpha", "1/2")),
                str(row.get("repetition", "")),
            )
        ].append(row)
    agreement_checked = 0
    for group_key, group_rows in agreement_groups.items():
        exact_rows = [
            row
            for row in group_rows
            if row.get("status") in {"OPTIMAL", "UNSAT"}
        ]
        statuses = {row.get("status") for row in exact_rows}
        if "OPTIMAL" in statuses and "UNSAT" in statuses:
            errors.append(f"objective/status disagreement for {group_key}")
            continue
        vectors = {
            _objective_vector(row)
            for row in exact_rows
            if row.get("status") == "OPTIMAL"
        }
        if len(vectors) > 1:
            errors.append(
                "objective-vector disagreement for "
                f"{group_key}: {sorted(vectors, key=str)}"
            )
        if len(exact_rows) >= 2:
            agreement_checked += 1

    # Diagnostic strata for the historical fairness cap. IR feasibility is a
    # base-problem witness; BG-d2 UNSAT after IR OPTIMAL is cap-induced UNSAT.
    by_content_rep: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_content_rep[
            (
                str(row.get("instance_content_id", "")),
                str(row.get("repetition", "")),
            )
        ].append(row)
    feasibility_classes: Counter[str] = Counter()
    for group_rows in by_content_rep.values():
        ir_statuses = {
            row.get("status")
            for row in group_rows
            if row.get("objective_mode")
            in {"ir", "ir_is", "ir_im_is", "ir_im_isq", "is", "isq", "im_is"}
            and row.get("status") in {"OPTIMAL", "UNSAT"}
        }
        bg_statuses = {
            row.get("status")
            for row in group_rows
            if row.get("objective_mode") == "bg_d2"
            and row.get("status") in {"OPTIMAL", "UNSAT"}
        }
        if "UNSAT" in ir_statuses:
            feasibility_classes["base_unsat"] += 1
        elif "OPTIMAL" in ir_statuses and bg_statuses == {"UNSAT"}:
            feasibility_classes["base_feasible_bg_cap_unsat"] += 1
        elif "OPTIMAL" in bg_statuses:
            feasibility_classes["bg_d2_feasible"] += 1
        else:
            feasibility_classes["unclassified"] += 1

    report = {
        "validated_utc": datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat(),
        "plan_sha256": plan.get("plan_sha256"),
        "planned_jobs": len(jobs),
        "latest_attempts": len(latest),
        "raw_attempts": len(records),
        "missing_jobs": len(missing),
        "extra_jobs": len(extra),
        "status_counts": dict(status_counts),
        "result_origin_counts": dict(result_origin_counts),
        "unique_contents": len(content_ids - {""}),
        "unique_lineages": len(lineage_ids - {""}),
        "agreement_groups_checked": agreement_checked,
        "peak_memory_limit_mb": peak_memory_limit_mb,
        "boot_ids": sorted(
            {
                str(row.get("campaign_boot_id", ""))
                for row in rows
                if not _is_blank(row.get("campaign_boot_id"))
            }
        ),
        "feasibility_classes": dict(feasibility_classes),
        "reuse_policy": plan.get("reuse_policy", "strict"),
        "common_gcp_environment_assumed": common_gcp_assumed,
        "environment_drift_accepted": allow_environment_drift,
        "valid": not errors,
        "errors": errors,
    }
    return errors, report


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate a journal campaign archive.")
    parser.add_argument("--output", required=True)
    parser.add_argument("--allow-dirty", action="store_true")
    parser.add_argument("--allow-incomplete", action="store_true")
    parser.add_argument("--allow-errors", action="store_true")
    parser.add_argument(
        "--allow-environment-drift",
        action="store_true",
        help=(
            "accept recorded per-row solver/machine differences while retaining "
            "their provenance"
        ),
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    output = Path(args.output).resolve()
    errors, report = validate_campaign(
        output,
        allow_dirty=args.allow_dirty,
        allow_incomplete=args.allow_incomplete,
        allow_errors=args.allow_errors,
        allow_environment_drift=args.allow_environment_drift,
    )
    report_path = output / "validation_report.json"
    with report_path.open("w", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")
    print(
        f"planned={report.get('planned_jobs')} latest={report.get('latest_attempts')} "
        f"valid={report.get('valid')} errors={len(errors)}"
    )
    for error in errors[:50]:
        print(f"ERROR: {error}")
    if len(errors) > 50:
        print(f"ERROR: ... {len(errors) - 50} additional errors")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
