from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import random
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Any, Iterable

from Dataset_Manifest import file_sha256
from B2B_Instance import (
    VALID_COLLISION_AMO_ENCODINGS,
    VALID_COMPACT_ENCODINGS,
)
from Main import InstanceSpec, collect_instances, write_detailed_csv
from MaxSAT_Solver import executable_sha256, resolve_uwrmaxsat_binary

try:
    import psutil
except ImportError:  # pragma: no cover - production requirements include psutil.
    psutil = None


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_VERSION = 1
TERMINAL_STATUSES = {"OPTIMAL", "UNSAT", "TIMEOUT"}
SUPPORTED_EXECUTORS = {
    "main",
    "org_bg_d2",
    "org_ir",
    "org_idle",
    "direct_idle",
}
SUPPORTED_BOOLEAN_SOLVERS = {"maxsat", "multiple", "incremental"}
EXECUTION_SHARD_POLICY = "content_rank_round_robin_v1"


class CampaignInterrupted(Exception):
    """Raised after a termination signal so the active child can be reaped."""


def _boot_id() -> str:
    path = Path("/proc/sys/kernel/random/boot_id")
    try:
        return path.read_text(encoding="ascii").strip()
    except OSError:
        return ""


def _cpu_model() -> str:
    try:
        with Path("/proc/cpuinfo").open(encoding="utf-8") as stream:
            for line in stream:
                if line.lower().startswith("model name"):
                    value = line.split(":", 1)[1].strip()
                    if value:
                        return value
    except OSError:
        pass

    return platform.processor().strip()


def _cpu_governor() -> str:
    try:
        return Path(
            "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
        ).read_text(encoding="ascii").strip()
    except OSError:
        return ""


def current_machine_profile() -> dict[str, Any]:
    """Return the hardware fields that define a comparable production VM."""
    memory = psutil.virtual_memory() if psutil is not None else None
    swap = psutil.swap_memory() if psutil is not None else None
    return {
        "cpu_model": _cpu_model(),
        "physical_cpu_cores": (
            psutil.cpu_count(logical=False) if psutil is not None else None
        ),
        "logical_cpu_cores": os.cpu_count(),
        "system_memory_mb": (
            round(memory.total / (1024 * 1024), 3)
            if memory is not None
            else None
        ),
        "swap_memory_mb": (
            round(swap.total / (1024 * 1024), 3)
            if swap is not None
            else None
        ),
    }


def machine_profile_errors(
    required: dict[str, Any] | None,
    actual: dict[str, Any] | None = None,
) -> list[str]:
    """Compare an observed VM against a frozen experiment resource profile."""
    if not required:
        return []
    observed = dict(actual or current_machine_profile())
    errors: list[str] = []
    required_model = str(required.get("cpu_model_contains", "")).strip()
    actual_model = str(observed.get("cpu_model", "")).strip()
    if required_model and required_model.casefold() not in actual_model.casefold():
        errors.append(
            f"cpu_model={actual_model!r} does not contain {required_model!r}"
        )
    for field in ("physical_cpu_cores", "logical_cpu_cores"):
        if field not in required:
            continue
        if observed.get(field) is None:
            errors.append(f"{field} could not be measured")
        elif int(observed[field]) != int(required[field]):
            errors.append(
                f"{field}={observed[field]!r}, expected {required[field]!r}"
            )
    bounded_fields = (
        ("system_memory_mb", "system_memory_mb_min", "system_memory_mb_max"),
        ("swap_memory_mb", "swap_memory_mb_min", "swap_memory_mb_max"),
    )
    for actual_field, minimum_field, maximum_field in bounded_fields:
        if minimum_field not in required and maximum_field not in required:
            continue
        value = observed.get(actual_field)
        if value is None:
            errors.append(f"{actual_field} could not be measured")
            continue
        numeric = float(value)
        if minimum_field in required and numeric < float(required[minimum_field]):
            errors.append(
                f"{actual_field}={numeric}, below {required[minimum_field]}"
            )
        if maximum_field in required and numeric > float(required[maximum_field]):
            errors.append(
                f"{actual_field}={numeric}, above {required[maximum_field]}"
            )
    return errors


def _machine_snapshot() -> dict[str, Any]:
    try:
        load = os.getloadavg()
    except (AttributeError, OSError):  # pragma: no cover - Windows fallback.
        load = (None, None, None)
    available_memory_mb = (
        round(psutil.virtual_memory().available / (1024 * 1024), 3)
        if psutil is not None
        else None
    )
    return {
        "load_1m": load[0],
        "load_5m": load[1],
        "load_15m": load[2],
        "available_memory_mb": available_memory_mb,
    }


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _stable_seed(*parts: Any) -> int:
    digest = hashlib.sha256("|".join(map(str, parts)).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def _relative_to_project(path: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(PROJECT_ROOT).as_posix()
    except ValueError:
        return str(resolved)


def _resolve_project_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else PROJECT_ROOT / path


def read_config(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        config = json.load(stream)
    blocks_from = config.get("blocks_from")
    if blocks_from:
        source_path = Path(str(blocks_from))
        if not source_path.is_absolute():
            source_path = path.parent / source_path
        with source_path.resolve().open(encoding="utf-8") as stream:
            source = json.load(stream)
        if not source.get("blocks"):
            raise ValueError(f"blocks_from contains no blocks: {source_path}")
        config["blocks"] = source["blocks"]
        overrides = {
            str(key): int(value)
            for key, value in config.get("block_repetitions", {}).items()
        }
        known_blocks = {block.get("id") for block in config["blocks"]}
        unknown_overrides = sorted(set(overrides) - known_blocks)
        if unknown_overrides:
            raise ValueError(
                f"repetition overrides reference unknown blocks: {unknown_overrides}"
            )
        for block in config["blocks"]:
            if block.get("id") in overrides:
                block["repetitions"] = overrides[block["id"]]
        dataset_overrides = config.get("block_datasets", {})
        unknown_dataset_overrides = sorted(
            set(dataset_overrides) - known_blocks
        )
        if unknown_dataset_overrides:
            raise ValueError(
                "dataset overrides reference unknown blocks: "
                f"{unknown_dataset_overrides}"
            )
        for block in config["blocks"]:
            if block.get("id") in dataset_overrides:
                block["datasets"] = list(dataset_overrides[block["id"]])
        config["resolved_blocks_from"] = _relative_to_project(source_path)
        config["resolved_blocks_sha256"] = file_sha256(source_path)
    if config.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(
            f"unsupported journal config schema: {config.get('schema_version')!r}"
        )
    if not config.get("campaign_name"):
        raise ValueError("campaign_name is required")
    if not config.get("datasets"):
        raise ValueError("at least one dataset is required")
    if not config.get("blocks"):
        raise ValueError("at least one experiment block is required")
    return config


def _filter_instances(
    instances: list[InstanceSpec],
    dataset: dict[str, Any],
) -> list[InstanceSpec]:
    names = set(dataset.get("instance_names", []))
    variants = set(dataset.get("variants", []))
    lineages = set(dataset.get("lineage_ids", []))
    selected = [
        instance
        for instance in instances
        if (not names or instance.instance_name in names)
        and (not variants or bool(variants.intersection(instance.variant.split("|"))))
        and (
            not lineages
            or (instance.base_lineage_id or "") in lineages
        )
    ]
    selected.sort(key=lambda instance: (instance.base_lineage_id, instance.instance_name))
    max_instances = dataset.get("max_instances")
    if max_instances is not None:
        if int(max_instances) <= 0:
            raise ValueError("max_instances must be positive")
        selected = selected[: int(max_instances)]
    if not selected:
        raise ValueError(f"dataset {dataset['id']!r} selects no instances")
    return selected


def resolve_datasets(config: dict[str, Any]) -> dict[str, list[InstanceSpec]]:
    resolved: dict[str, list[InstanceSpec]] = {}
    for dataset in config["datasets"]:
        dataset_id = dataset.get("id")
        if not dataset_id or dataset_id in resolved:
            raise ValueError(f"invalid or duplicate dataset id: {dataset_id!r}")
        manifest = _resolve_project_path(dataset["manifest"])
        instances = collect_instances(
            None,
            None,
            str(manifest),
            dataset.get("family", "all"),
        )
        resolved[dataset_id] = _filter_instances(instances, dataset)
    return resolved


def _validate_configuration(configuration: dict[str, Any]) -> None:
    config_id = configuration.get("id")
    executor = configuration.get("executor")
    if not config_id:
        raise ValueError("every configuration requires an id")
    if executor not in SUPPORTED_EXECUTORS:
        raise ValueError(f"unsupported executor for {config_id}: {executor!r}")
    if executor == "main":
        solver = configuration.get("solver")
        if solver not in SUPPORTED_BOOLEAN_SOLVERS:
            raise ValueError(
                f"journal main configuration {config_id!r} requires one "
                f"Boolean solver, got {solver!r}"
            )
        if configuration.get("objective_mode") not in {
            "ir",
            "bg_d2",
            "bg_dinf",
            "ir_is",
            "ir_im_is",
            "ir_im_isq",
            "bg_ir_is",
            "is",
            "isq",
            "im_is",
        }:
            raise ValueError(f"invalid objective mode in {config_id!r}")
        compact_encoding = configuration.get("compact_encoding", "reference")
        if compact_encoding not in VALID_COMPACT_ENCODINGS:
            raise ValueError(
                f"invalid compact encoding in {config_id!r}: "
                f"{compact_encoding!r}"
            )
        if (
            solver in {"multiple", "incremental"}
            and configuration["objective_mode"]
            in {"ir", "ir_is", "ir_im_is", "ir_im_isq", "bg_ir_is"}
            and compact_encoding in {"direct_range_soft", "optimized"}
        ):
            raise ValueError(
                f"{compact_encoding!r} is MaxSAT-only for "
                f"{configuration['objective_mode']!r} in {config_id!r}"
            )
        if configuration["objective_mode"] in {"isq", "ir_im_isq"} and solver != "maxsat":
            raise ValueError("ISQ requires MaxSAT weighted penalties")
        if (
            compact_encoding == "objective_aware"
            and configuration["objective_mode"]
            in {
                "ir",
                "ir_is",
                "ir_im_is",
                "ir_im_isq",
                "bg_ir_is",
                "is",
                "isq",
                "im_is",
            }
            and solver != "maxsat"
        ):
            raise ValueError(
                "objective_aware waiting objectives require MaxSAT"
            )
        cap_rule = configuration.get("participant_idle_cap_rule", "none")
        if cap_rule not in {"none", "interpolated_bounds"}:
            raise ValueError(f"invalid participant idle cap rule in {config_id!r}")
        try:
            cap_alpha = Fraction(
                str(configuration.get("participant_idle_cap_alpha", "1/2"))
            )
        except (ValueError, ZeroDivisionError) as exc:
            raise ValueError(
                f"invalid participant idle cap alpha in {config_id!r}"
            ) from exc
        if not 0 <= cap_alpha <= 1:
            raise ValueError(
                f"participant idle cap alpha outside [0,1] in {config_id!r}"
            )
        if cap_rule != "none" and configuration["objective_mode"] not in {
            "ir_im_is",
            "ir_im_isq",
        }:
            raise ValueError(
                f"participant idle caps do not apply to "
                f"{configuration['objective_mode']!r} in {config_id!r}"
            )
        collision_amo = configuration.get("collision_amo", "pairwise")
        if collision_amo not in VALID_COLLISION_AMO_ENCODINGS:
            raise ValueError(
                f"invalid collision AMO in {config_id!r}: "
                f"{collision_amo!r}"
            )
        for field in (
            "domain_mode",
            "precedence_encoding",
            "precedence_graph",
            "domain_filter_graph",
            "encoding_variant",
        ):
            if field not in configuration:
                raise ValueError(f"{config_id!r} is missing {field!r}")
    elif executor == "org_bg_d2":
        if configuration.get("objective_mode", "bg_d2") != "bg_d2":
            raise ValueError("org_bg_d2 executor only supports bg_d2")
    elif executor == "org_ir":
        if configuration.get("objective_mode", "ir") != "ir":
            raise ValueError("org_ir executor only supports ir")
    elif executor in {"org_idle", "direct_idle"}:
        if configuration.get("objective_mode") not in {
            "ir",
            "is",
            "isq",
            "im_is",
            "ir_is",
            "ir_im_is",
            "ir_im_isq",
        }:
            raise ValueError(
                "direct_idle has an unsupported waiting objective"
            )
        cap_rule = configuration.get("participant_idle_cap_rule", "none")
        if cap_rule not in {"none", "interpolated_bounds"}:
            raise ValueError(
                "direct_idle has an invalid participant idle cap rule"
            )
        if (
            cap_rule != "none"
            and configuration["objective_mode"]
            not in {"ir_im_is", "ir_im_isq"}
        ):
            raise ValueError(
                "direct_idle caps apply only to ir_im_is and ir_im_isq"
            )
        try:
            alpha = Fraction(
                str(configuration.get("participant_idle_cap_alpha", "1/2"))
            )
        except (ValueError, ZeroDivisionError) as exc:
            raise ValueError("direct_idle has an invalid cap alpha") from exc
        if not 0 <= alpha <= 1:
            raise ValueError(
                "direct_idle participant idle cap alpha lies outside [0,1]"
            )


def _balanced_instance_order(
    instances: Iterable[InstanceSpec],
    *,
    seed: int,
) -> list[InstanceSpec]:
    """Deterministically shuffle while interleaving benchmark families."""

    rng = random.Random(seed)
    groups: dict[str, list[InstanceSpec]] = {}
    for instance in instances:
        groups.setdefault(instance.family, []).append(instance)
    for values in groups.values():
        rng.shuffle(values)
    group_names = sorted(groups)
    rng.shuffle(group_names)
    ordered: list[InstanceSpec] = []
    while any(groups.values()):
        for group_name in group_names:
            if groups[group_name]:
                ordered.append(groups[group_name].pop())
        rng.shuffle(group_names)
    return ordered


def build_plan(
    config: dict[str, Any],
    datasets: dict[str, list[InstanceSpec]],
    *,
    only_blocks: set[str] | None = None,
) -> dict[str, Any]:
    global_seed = int(config.get("run_order_seed", 0))
    jobs: list[dict[str, Any]] = []
    seen_configurations: dict[str, str] = {}
    seen_blocks: set[str] = set()
    for block in config["blocks"]:
        block_id = block.get("id")
        if not block_id or block_id in seen_blocks:
            raise ValueError(f"invalid or duplicate block id: {block_id!r}")
        seen_blocks.add(block_id)
        if only_blocks and block_id not in only_blocks:
            continue
        repetitions = int(block.get("repetitions", 1))
        if repetitions <= 0:
            raise ValueError(f"block {block_id!r} has invalid repetitions")
        block_instances: dict[str, InstanceSpec] = {}
        for dataset_id in block.get("datasets", []):
            if dataset_id not in datasets:
                raise ValueError(
                    f"block {block_id!r} references unknown dataset {dataset_id!r}"
                )
            for instance in datasets[dataset_id]:
                block_instances.setdefault(instance.content_id, instance)
        if not block_instances:
            raise ValueError(f"block {block_id!r} selects no instances")
        configurations = block.get("configurations", [])
        if not configurations:
            raise ValueError(f"block {block_id!r} has no configurations")
        for configuration in configurations:
            _validate_configuration(configuration)
            config_id = configuration["id"]
            serialized = canonical_json(configuration)
            if (
                config_id in seen_configurations
                and seen_configurations[config_id] != serialized
            ):
                raise ValueError(
                    "a planned configuration id has divergent definitions: "
                    f"{config_id!r}"
                )
            seen_configurations[config_id] = serialized

        for repetition in range(1, repetitions + 1):
            instances = _balanced_instance_order(
                block_instances.values(),
                seed=_stable_seed(
                    global_seed,
                    block_id,
                    repetition,
                    "instances",
                ),
            )
            for instance in instances:
                ordered_configurations = [dict(value) for value in configurations]
                random.Random(
                    _stable_seed(
                        global_seed,
                        block_id,
                        repetition,
                        instance.content_id,
                        "configurations",
                    )
                ).shuffle(ordered_configurations)
                for configuration in ordered_configurations:
                    run_key = "::".join(
                        (
                            config["campaign_name"],
                            block_id,
                            instance.content_id,
                            configuration["id"],
                            f"rep-{repetition}",
                        )
                    )
                    jobs.append(
                        {
                            "run_order": len(jobs) + 1,
                            "run_key": run_key,
                            "experiment_block": block_id,
                            "repetition": repetition,
                            "instance": instance.instance_name,
                            "instance_content_id": instance.content_id,
                            "instance_sha256": instance.sha256,
                            "base_lineage_id": instance.base_lineage_id,
                            "instance_family": instance.family,
                            "instance_variant": instance.variant,
                            "instance_path": _relative_to_project(instance.path),
                            "planned_configuration_id": configuration["id"],
                            "configuration": configuration,
                        }
                    )
    if not jobs:
        raise ValueError("the selected block filter produced no jobs")
    expected_jobs = config.get("expected_job_count")
    if not only_blocks and expected_jobs is not None and len(jobs) != int(expected_jobs):
        raise ValueError(f"frozen campaign expects {expected_jobs} jobs, got {len(jobs)}")
    reuse_results = config.get("reuse_results", [])
    if not isinstance(reuse_results, list):
        raise ValueError("reuse_results must be a list")
    normalized_reuse_results: list[dict[str, Any]] = []
    target_cells = {
        (
            str(job["experiment_block"]),
            str(job["planned_configuration_id"]),
            int(job["repetition"]),
        )
        for job in jobs
    }
    seen_reuse_targets: set[tuple[str, str, int]] = set()
    required_reuse_fields = (
        "source_campaign_id",
        "source_block_id",
        "source_configuration_id",
        "source_repetition",
        "target_block_id",
        "target_configuration_id",
        "target_repetition",
    )
    for position, raw_rule in enumerate(reuse_results, start=1):
        if not isinstance(raw_rule, dict):
            raise ValueError(f"reuse_results entry {position} must be an object")
        missing_fields = [
            field for field in required_reuse_fields if field not in raw_rule
        ]
        if missing_fields:
            raise ValueError(
                f"reuse_results entry {position} is missing: "
                + ", ".join(missing_fields)
            )
        rule = {
            "source_campaign_id": str(raw_rule["source_campaign_id"]),
            "source_block_id": str(raw_rule["source_block_id"]),
            "source_configuration_id": str(
                raw_rule["source_configuration_id"]
            ),
            "source_repetition": int(raw_rule["source_repetition"]),
            "target_block_id": str(raw_rule["target_block_id"]),
            "target_configuration_id": str(
                raw_rule["target_configuration_id"]
            ),
            "target_repetition": int(raw_rule["target_repetition"]),
        }
        if rule["source_repetition"] <= 0 or rule["target_repetition"] <= 0:
            raise ValueError("reuse result repetitions must be positive")
        target = (
            rule["target_block_id"],
            rule["target_configuration_id"],
            rule["target_repetition"],
        )
        if target not in target_cells:
            raise ValueError(
                "reuse_results references an unknown target cell: "
                f"{target!r}"
            )
        if target in seen_reuse_targets:
            raise ValueError(
                f"multiple reuse_results entries target the same cell: {target!r}"
            )
        seen_reuse_targets.add(target)
        normalized_reuse_results.append(rule)

    reuse_policy = str(config.get("reuse_policy", "strict"))
    if reuse_policy not in {"strict", "validated_common_gcp"}:
        raise ValueError(
            "reuse_policy must be 'strict' or 'validated_common_gcp'"
        )
    payload = {
        "schema_version": SCHEMA_VERSION,
        "campaign_id": config["campaign_name"],
        "run_order_seed": global_seed,
        "timeout_seconds": float(config.get("timeout_seconds", 7200.0)),
        "controller_grace_seconds": float(
            config.get("controller_grace_seconds", 120.0)
        ),
        "required_machine": dict(config.get("required_machine", {})),
        "reuse_policy": reuse_policy,
        "job_count": len(jobs),
        "jobs": jobs,
    }
    if normalized_reuse_results:
        payload["reuse_results"] = normalized_reuse_results
    # Per-instance reuse supports partially completed source campaigns.  The
    # preparation tool binds every source row to one immutable target run key.
    reuse_cells = config.get("reuse_cells", {})
    if reuse_cells:
        if normalized_reuse_results or not isinstance(reuse_cells, dict):
            raise ValueError("reuse_cells must be a mapping without reuse_results")
        job_keys = {job["run_key"] for job in jobs}
        if set(reuse_cells) - job_keys:
            raise ValueError("reuse_cells contains unplanned target run keys")
        required_fields = {
            "source_campaign_id", "source_block_id", "source_configuration_id",
            "source_repetition", "source_run_key", "source_row_sha256",
        }
        for rule in reuse_cells.values():
            if not isinstance(rule, dict) or required_fields - rule.keys():
                raise ValueError("reuse_cells contains an incomplete source mapping")
            if int(rule["source_repetition"]) <= 0:
                raise ValueError("reuse_cells source repetitions must be positive")
            if not re.fullmatch(r"[0-9a-f]{64}", str(rule["source_row_sha256"])):
                raise ValueError("reuse_cells contains an invalid source-row SHA-256")
        payload["reuse_cells"] = reuse_cells
    if config.get("frozen_sources"):
        payload["frozen_sources"] = config["frozen_sources"]
    payload["plan_sha256"] = sha256_text(canonical_json(payload))
    return payload


def execution_shard_assignments(
    plan: dict[str, Any],
    shard_count: int,
) -> dict[str, int]:
    """Assign all configurations of one content to the same balanced shard."""

    if shard_count <= 0:
        raise ValueError("shard_count must be positive")
    content_ids = sorted(
        {str(job["instance_content_id"]) for job in plan["jobs"]}
    )
    content_shards = {
        content_id: rank % shard_count
        for rank, content_id in enumerate(content_ids)
    }
    return {
        job["run_key"]: content_shards[str(job["instance_content_id"])]
        for job in plan["jobs"]
    }


def _git_metadata() -> tuple[str, bool]:
    commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    dirty = bool(
        subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
    )
    return commit, dirty


def build_environment(
    config_path: Path,
    config: dict[str, Any],
    plan: dict[str, Any],
    *,
    uwrmaxsat_binary: Path | None,
    command: list[str],
    execution_shard_count: int = 1,
    execution_shard_indices: tuple[int, ...] = (0,),
) -> dict[str, Any]:
    commit, dirty = _git_metadata()
    manifest_hashes = {}
    for dataset in config["datasets"]:
        manifest = _resolve_project_path(dataset["manifest"])
        manifest_hashes[_relative_to_project(manifest)] = file_sha256(manifest)
    requirements = PROJECT_ROOT / "src" / "requirements.txt"
    environment = {
        "created_utc": utc_now(),
        "campaign_id": config["campaign_name"],
        "config_path": _relative_to_project(config_path),
        "config_sha256": file_sha256(config_path),
        "plan_sha256": plan["plan_sha256"],
        "git_commit": commit,
        "git_dirty": dirty,
        "python_executable": sys.executable,
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "hostname": platform.node(),
        "boot_id": _boot_id(),
        "cpu_governor": _cpu_governor(),
        "kernel_release": platform.release(),
        "required_machine": plan.get("required_machine", {}),
        "requirements_sha256": (
            file_sha256(requirements) if requirements.is_file() else ""
        ),
        "manifest_sha256": manifest_hashes,
        "uwrmaxsat_binary": str(uwrmaxsat_binary or ""),
        "uwrmaxsat_sha256": (
            executable_sha256(uwrmaxsat_binary)
            if uwrmaxsat_binary is not None
            else ""
        ),
        "execution_shard_count": execution_shard_count,
        "execution_shard_indices": list(execution_shard_indices),
        "execution_shard_policy": EXECUTION_SHARD_POLICY,
        "runner_command": shlex.join(command),
    }
    environment.update(current_machine_profile())
    return environment


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    records = []
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"corrupt JSONL at {path}:{line_number}: {exc}"
                ) from exc
    return records


def _append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(canonical_json(record) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def latest_attempts(records: Iterable[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for record in records:
        run_key = record["run_key"]
        previous = latest.get(run_key)
        if previous is None or int(record["attempt"]) > int(previous["attempt"]):
            latest[run_key] = record
        elif int(record["attempt"]) == int(previous["attempt"]):
            raise ValueError(f"duplicate attempt for run_key={run_key!r}")
    return latest


def _read_single_csv_row(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 1:
        raise ValueError(f"expected one result row in {path}, found {len(rows)}")
    return dict(rows[0])


def _configuration_command(
    job: dict[str, Any],
    *,
    timeout: float,
    temp_dir: Path,
    uwrmaxsat_binary: Path | None,
    uwrmaxsat_sha256: str,
) -> tuple[list[str], Path]:
    configuration = job["configuration"]
    executor = configuration["executor"]
    instance_path = _resolve_project_path(job["instance_path"])
    detailed = temp_dir / "detailed.csv"
    if executor == "main":
        command = [
            sys.executable,
            "-u",
            str(PROJECT_ROOT / "src" / "Main.py"),
            "--instance",
            str(instance_path),
            "--solver",
            configuration["solver"],
            "--objective-mode",
            configuration["objective_mode"],
            "--compact-encoding",
            configuration.get("compact_encoding", "reference"),
            "--collision-amo",
            configuration.get("collision_amo", "pairwise"),
            "--participant-idle-cap-rule",
            configuration.get("participant_idle_cap_rule", "none"),
            "--participant-idle-cap-alpha",
            str(configuration.get("participant_idle_cap_alpha", "1/2")),
            "--domain-mode",
            configuration["domain_mode"],
            "--domain-filter-graph",
            configuration["domain_filter_graph"],
            "--precedence-encoding",
            configuration["precedence_encoding"],
            "--precedence-graph",
            configuration["precedence_graph"],
            "--encoding-variant",
            configuration["encoding_variant"],
            "--maxsat-backend",
            configuration.get("maxsat_backend", "uwrmaxsat"),
            "--sat-backend",
            configuration.get("sat_backend", "cadical"),
            "--timeout",
            str(timeout),
            "--threads",
            "1",
            "--random-seed",
            "0",
            "--csv",
            str(temp_dir / "aggregate.csv"),
            "--long-csv",
            str(detailed),
            "--no-excel",
        ]
        if configuration["solver"] == "maxsat" and configuration.get(
            "maxsat_backend", "uwrmaxsat"
        ) == "uwrmaxsat":
            if uwrmaxsat_binary is None:
                raise FileNotFoundError("UWrMaxSAT is required by this configuration")
            command.extend(
                [
                    "--uwrmaxsat-bin",
                    str(uwrmaxsat_binary),
                    "--uwrmaxsat-sha256",
                    uwrmaxsat_sha256,
                ]
            )
        return command, detailed
    if executor == "org_bg_d2":
        backend = configuration.get("backend", "uwrmaxsat")
        command = [
            sys.executable,
            "-u",
            str(PROJECT_ROOT / "src" / "ORG_BG_D2.py"),
            "--instance",
            str(instance_path),
            "--backend",
            backend,
            "--timeout",
            str(timeout),
            "--csv",
            str(detailed),
            "--no-excel",
        ]
        if backend == "uwrmaxsat":
            if uwrmaxsat_binary is None:
                raise FileNotFoundError("UWrMaxSAT is required by ORG BG-d2")
            command.extend(
                [
                    "--uwrmaxsat-bin",
                    str(uwrmaxsat_binary),
                    "--uwrmaxsat-sha256",
                    uwrmaxsat_sha256,
                ]
            )
        return command, detailed
    if executor in {"org_ir", "org_idle", "direct_idle"}:
        if uwrmaxsat_binary is None:
            raise FileNotFoundError("UWrMaxSAT is required by ORG IR")
        command = [
            sys.executable,
            "-u",
            str(PROJECT_ROOT / "src" / "ORG_new.py"),
            "--instance",
            str(instance_path),
            "--timeout",
            str(timeout),
            "--uwrmaxsat-bin",
            str(uwrmaxsat_binary),
            "--uwrmaxsat-sha256",
            uwrmaxsat_sha256,
            "--csv",
            str(detailed),
            "--excel-dir",
            str(temp_dir / "excel"),
        ]
        if executor in {"org_idle", "direct_idle"}:
            command.extend(
                [
                    "--objective-mode",
                    configuration["objective_mode"],
                    "--participant-idle-cap-rule",
                    configuration.get("participant_idle_cap_rule", "none"),
                    "--participant-idle-cap-alpha",
                    str(configuration.get("participant_idle_cap_alpha", "1/2")),
                ]
            )
        return command, detailed
    raise AssertionError(executor)


def _terminate_process_group(process: subprocess.Popen[Any]) -> None:
    if process.poll() is not None:
        return
    if os.name == "nt":  # pragma: no cover - GCP production is Linux.
        process.terminate()
    else:
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        if os.name == "nt":  # pragma: no cover
            process.kill()
        else:
            os.killpg(process.pid, signal.SIGKILL)
        process.wait()


def run_job(
    job: dict[str, Any],
    *,
    output_dir: Path,
    timeout: float,
    controller_grace: float,
    uwrmaxsat_binary: Path | None,
    uwrmaxsat_sha256: str,
    attempt: int,
    plan_sha256: str,
    campaign_id: str,
    run_order_seed: int,
) -> dict[str, Any]:
    log_name = (
        f"{job['run_order']:06d}_"
        f"{sha256_text(job['run_key'])[:12]}_attempt-{attempt}.log"
    )
    log_path = output_dir / "logs" / log_name
    log_path.parent.mkdir(parents=True, exist_ok=True)
    work_root = output_dir / "work"
    work_root.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    controller_timeout = False
    return_code: int | None = None
    row: dict[str, Any]
    before = _machine_snapshot()
    with tempfile.TemporaryDirectory(prefix="cell-", dir=work_root) as temporary:
        temp_dir = Path(temporary)
        command, detailed_path = _configuration_command(
            job,
            timeout=timeout,
            temp_dir=temp_dir,
            uwrmaxsat_binary=uwrmaxsat_binary,
            uwrmaxsat_sha256=uwrmaxsat_sha256,
        )
        with log_path.open("w", encoding="utf-8") as log_stream:
            log_stream.write(f"started_utc={utc_now()}\n")
            log_stream.write(f"command={shlex.join(command)}\n\n")
            log_stream.flush()
            process = subprocess.Popen(
                command,
                cwd=PROJECT_ROOT,
                stdout=log_stream,
                stderr=subprocess.STDOUT,
                text=True,
                start_new_session=(os.name != "nt"),
            )
            try:
                return_code = process.wait(timeout=timeout + controller_grace)
            except subprocess.TimeoutExpired:
                controller_timeout = True
                _terminate_process_group(process)
                return_code = process.returncode
            except (CampaignInterrupted, KeyboardInterrupt):
                _terminate_process_group(process)
                log_stream.write("\ncell interrupted; no result row committed\n")
                log_stream.flush()
                raise
        if detailed_path.is_file():
            row = _read_single_csv_row(detailed_path)
        elif controller_timeout:
            row = {
                "instance": job["instance"],
                "instance_content_id": job["instance_content_id"],
                "instance_sha256": job["instance_sha256"],
                "base_lineage_id": job["base_lineage_id"],
                "instance_family": job["instance_family"],
                "instance_variant": job["instance_variant"],
                "instance_path": job["instance_path"],
                "status": "TIMEOUT",
                "sat_result": "TIMEOUT",
                "runtime_seconds": timeout,
                "runtime_censored": True,
                "objective_mode": job["configuration"].get("objective_mode", ""),
                "error_type": "ControllerTimeout",
                "error_message": (
                    "cell executor exceeded solver timeout plus controller grace"
                ),
            }
        else:
            row = {
                "instance": job["instance"],
                "instance_content_id": job["instance_content_id"],
                "instance_sha256": job["instance_sha256"],
                "base_lineage_id": job["base_lineage_id"],
                "instance_family": job["instance_family"],
                "instance_variant": job["instance_variant"],
                "instance_path": job["instance_path"],
                "status": "ERROR",
                "sat_result": "ERROR",
                "runtime_seconds": round(time.perf_counter() - started, 6),
                "runtime_censored": False,
                "objective_mode": job["configuration"].get("objective_mode", ""),
                "error_type": "ExecutorFailure",
                "error_message": (
                    f"executor returned {return_code} without a detailed CSV"
                ),
            }
    after = _machine_snapshot()
    row.setdefault(
        "compact_encoding",
        job["configuration"].get("compact_encoding", "reference"),
    )
    row.setdefault(
        "collision_amo",
        job["configuration"].get("collision_amo", "pairwise"),
    )
    row.setdefault(
        "participant_idle_cap_rule",
        job["configuration"].get("participant_idle_cap_rule", "none"),
    )
    row.setdefault(
        "participant_idle_cap_alpha",
        str(job["configuration"].get("participant_idle_cap_alpha", "1/2")),
    )
    row.update(
        {
            "campaign_id": campaign_id,
            "executor_instance_content_id": row.get("instance_content_id", ""),
            "instance_content_id": job["instance_content_id"],
            "instance_sha256": job["instance_sha256"],
            "instance_path": job["instance_path"],
            "instance_variant": job["instance_variant"],
            "instance_family": job["instance_family"],
            "base_lineage_id": job["base_lineage_id"],
            "result_origin": "executed",
            "experiment_block": job["experiment_block"],
            "planned_configuration_id": job["planned_configuration_id"],
            "repetition": job["repetition"],
            "run_order": job["run_order"],
            "run_key": job["run_key"],
            "attempt": attempt,
            "run_order_seed": run_order_seed,
            "campaign_plan_sha256": plan_sha256,
            "campaign_executor_seconds": round(time.perf_counter() - started, 6),
            "campaign_log": log_path.relative_to(output_dir).as_posix(),
            "campaign_executor_returncode": return_code,
            "campaign_boot_id": _boot_id(),
            "campaign_load_1m_before": before["load_1m"],
            "campaign_load_5m_before": before["load_5m"],
            "campaign_load_15m_before": before["load_15m"],
            "campaign_available_memory_mb_before": before[
                "available_memory_mb"
            ],
            "campaign_load_1m_after": after["load_1m"],
            "campaign_available_memory_mb_after": after[
                "available_memory_mb"
            ],
        }
    )
    return {
        "run_key": job["run_key"],
        "attempt": attempt,
        "completed_utc": utc_now(),
        "row": row,
    }


def materialize_results(output_dir: Path) -> list[dict[str, Any]]:
    records = _read_jsonl(output_dir / "raw" / "results.jsonl")
    rows = [record["row"] for record in latest_attempts(records).values()]
    rows.sort(key=lambda row: int(row["run_order"]))
    normalized = output_dir / "normalized" / "detailed.csv"
    write_detailed_csv(normalized, rows)
    return rows


def _configuration_without_id(configuration: dict[str, Any]) -> dict[str, Any]:
    comparable = dict(configuration)
    comparable.pop("id", None)
    return comparable


def _validate_reuse_source(
    source_output: Path,
    *,
    allow_dirty: bool,
    allow_environment_drift: bool,
) -> None:
    command = [
        sys.executable,
        str(PROJECT_ROOT / "src" / "Validate_Journal_Run.py"),
        "--output",
        str(source_output),
        "--allow-incomplete",
    ]
    if allow_dirty:
        command.append("--allow-dirty")
    if allow_environment_drift:
        command.append("--allow-environment-drift")
    completed = subprocess.run(
        command,
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = (completed.stdout + completed.stderr).strip()
        raise ValueError(
            f"reuse source failed validation: {source_output}: {detail}"
        )


def _reuse_environment_mismatches(
    target: dict[str, Any],
    source: dict[str, Any],
) -> list[str]:
    exact_fields = (
        "git_commit",
        "git_dirty",
        "requirements_sha256",
        "manifest_sha256",
        "uwrmaxsat_sha256",
        "required_machine",
        "python_version",
        "kernel_release",
        "cpu_model",
        "physical_cpu_cores",
        "logical_cpu_cores",
    )
    return [
        field for field in exact_fields if source.get(field) != target.get(field)
    ]


def _reuse_result_errors(row: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if row.get("status") not in TERMINAL_STATUSES:
        errors.append("result is not terminal")
    if str(row.get("campaign_executor_returncode", "")).strip() not in {"", "0"}:
        errors.append("executor return code is nonzero")
    for field in ("error_type", "error_message", "validation_errors"):
        if str(row.get(field, "")).strip():
            errors.append(f"{field} is nonempty")
    return errors


def _copy_reused_log(
    source_output: Path,
    target_output: Path,
    source_campaign_id: str,
    source_log: str,
) -> str:
    if not source_log:
        return ""
    relative = Path(source_log)
    candidates: list[Path] = []
    direct = source_output / relative
    if direct.is_file():
        candidates.append(direct)
    if not candidates:
        candidates.extend(
            path
            for path in (source_output / "logs").glob(
                f"**/{relative.name}"
            )
            if path.is_file()
        )
    if len(candidates) != 1:
        return ""
    safe_campaign = re.sub(r"[^A-Za-z0-9_.-]+", "_", source_campaign_id)
    destination = (
        target_output / "logs" / "reused" / safe_campaign / relative.name
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        shutil.copy2(candidates[0], destination)
    return destination.relative_to(target_output).as_posix()


def import_reused_results(
    output_dir: Path,
    plan: dict[str, Any],
    environment: dict[str, Any],
    source_outputs: Iterable[Path],
    *,
    execution_shard_count: int,
    execution_shard_indices: tuple[int, ...],
    allow_dirty: bool = False,
    allow_environment_drift: bool = False,
) -> dict[str, Any]:
    """Import planned result cells from compatible completed campaigns."""

    rules = list(plan.get("reuse_results", []))
    reuse_policy = str(plan.get("reuse_policy", "strict"))
    assume_common_gcp = reuse_policy == "validated_common_gcp"
    accept_source_dirty = allow_dirty or assume_common_gcp
    accept_environment_differences = allow_environment_drift or assume_common_gcp
    resolved_sources = [path.resolve() for path in source_outputs]
    if not rules:
        if resolved_sources:
            raise ValueError("--reuse-output was provided but the plan has no rules")
        return {"imported": 0, "already_completed": 0, "sources": []}
    if not resolved_sources:
        raise ValueError(
            "this campaign requires --reuse-output for its planned reused results"
        )

    sources: dict[str, dict[str, Any]] = {}
    for source_output in resolved_sources:
        _validate_reuse_source(
            source_output,
            allow_dirty=accept_source_dirty,
            allow_environment_drift=accept_environment_differences,
        )
        source_plan = json.loads(
            (source_output / "plan.json").read_text(encoding="utf-8")
        )
        source_environment = json.loads(
            (source_output / "environment.json").read_text(encoding="utf-8")
        )
        campaign_id = str(source_plan.get("campaign_id", ""))
        if not campaign_id:
            raise ValueError(f"reuse source has no campaign id: {source_output}")
        if campaign_id in sources:
            raise ValueError(
                f"multiple reuse outputs provide campaign {campaign_id!r}"
            )
        mismatches = _reuse_environment_mismatches(
            environment, source_environment
        )
        if mismatches and not accept_environment_differences:
            raise ValueError(
                f"reuse source {campaign_id!r} has incompatible environment "
                "fields: " + ", ".join(mismatches)
            )
        if float(source_plan.get("timeout_seconds", -1)) != float(
            plan.get("timeout_seconds", -2)
        ):
            raise ValueError(
                f"reuse source {campaign_id!r} has a different timeout"
            )
        source_records = latest_attempts(
            _read_jsonl(source_output / "raw" / "results.jsonl")
        )
        source_jobs = {
            (
                str(job["experiment_block"]),
                str(job["planned_configuration_id"]),
                int(job["repetition"]),
                str(job["instance_content_id"]),
            ): job
            for job in source_plan.get("jobs", [])
        }
        sources[campaign_id] = {
            "output": source_output,
            "plan": source_plan,
            "environment": source_environment,
            "accepted_environment_mismatches": (
                mismatches if accept_environment_differences else []
            ),
            "records": source_records,
            "jobs": source_jobs,
        }

    missing_campaigns = sorted(
        {str(rule["source_campaign_id"]) for rule in rules} - set(sources)
    )
    if missing_campaigns:
        raise ValueError(
            "no --reuse-output provides required campaigns: "
            + ", ".join(missing_campaigns)
        )

    target_assignments = execution_shard_assignments(
        plan, execution_shard_count
    )
    target_rules = {
        (
            str(rule["target_block_id"]),
            str(rule["target_configuration_id"]),
            int(rule["target_repetition"]),
        ): rule
        for rule in rules
    }
    target_raw_path = output_dir / "raw" / "results.jsonl"
    target_records = _read_jsonl(target_raw_path)
    target_latest = latest_attempts(target_records)
    imported = 0
    already_completed = 0
    source_reports: dict[str, dict[str, Any]] = {
        campaign_id: {
            "campaign_id": campaign_id,
            "plan_sha256": source["plan"]["plan_sha256"],
            "imported": 0,
            "already_completed": 0,
            "accepted_environment_mismatches": source[
                "accepted_environment_mismatches"
            ],
        }
        for campaign_id, source in sources.items()
    }

    for target_job in plan["jobs"]:
        rule = target_rules.get(
            (
                str(target_job["experiment_block"]),
                str(target_job["planned_configuration_id"]),
                int(target_job["repetition"]),
            )
        )
        if rule is None:
            continue
        if (
            target_assignments[target_job["run_key"]]
            not in execution_shard_indices
        ):
            continue
        existing = target_latest.get(target_job["run_key"])
        if existing is not None and existing.get("row", {}).get(
            "status"
        ) in TERMINAL_STATUSES:
            already_completed += 1
            source_reports[str(rule["source_campaign_id"])][
                "already_completed"
            ] += 1
            continue

        source_campaign_id = str(rule["source_campaign_id"])
        source = sources.get(source_campaign_id)
        if source is None:
            raise ValueError(
                f"no --reuse-output provides campaign {source_campaign_id!r}"
            )
        source_key = (
            str(rule["source_block_id"]),
            str(rule["source_configuration_id"]),
            int(rule["source_repetition"]),
            str(target_job["instance_content_id"]),
        )
        source_job = source["jobs"].get(source_key)
        if source_job is None:
            raise ValueError(
                "reuse source plan is missing the required cell: "
                f"{source_key!r}"
            )
        if canonical_json(
            _configuration_without_id(source_job["configuration"])
        ) != canonical_json(
            _configuration_without_id(target_job["configuration"])
        ):
            raise ValueError(
                "reuse source and target configurations differ beyond their IDs: "
                f"{source_job['planned_configuration_id']!r} -> "
                f"{target_job['planned_configuration_id']!r}"
            )
        source_record = source["records"].get(source_job["run_key"])
        if source_record is None:
            raise ValueError(
                f"reuse source has no result for {source_job['run_key']!r}"
            )
        source_row = source_record.get("row", {})
        result_errors = _reuse_result_errors(source_row)
        if result_errors:
            raise ValueError(
                f"reuse source result is invalid for {source_job['run_key']!r}: "
                + "; ".join(result_errors)
            )

        row = dict(source_row)
        source_log = str(row.get("campaign_log", ""))
        row.update(
            {
                "campaign_id": plan["campaign_id"],
                "experiment_block": target_job["experiment_block"],
                "planned_configuration_id": target_job[
                    "planned_configuration_id"
                ],
                "repetition": target_job["repetition"],
                "run_order": target_job["run_order"],
                "run_key": target_job["run_key"],
                "attempt": (
                    int(existing["attempt"]) + 1 if existing is not None else 1
                ),
                "run_order_seed": plan["run_order_seed"],
                "campaign_plan_sha256": plan["plan_sha256"],
                "execution_shard_count": execution_shard_count,
                "execution_shard_indices": ",".join(
                    str(index) for index in execution_shard_indices
                ),
                "execution_shard_index": target_assignments[
                    target_job["run_key"]
                ],
                "execution_shard_policy": EXECUTION_SHARD_POLICY,
                "result_origin": "reused",
                "reused_from_campaign_id": source_campaign_id,
                "reused_from_plan_sha256": source["plan"]["plan_sha256"],
                "reused_from_run_key": source_job["run_key"],
                "reused_from_experiment_block": source_job[
                    "experiment_block"
                ],
                "reused_from_configuration_id": source_job[
                    "planned_configuration_id"
                ],
                "reused_from_repetition": source_job["repetition"],
                "reused_from_run_order": source_job["run_order"],
                "reused_from_run_order_seed": source["plan"][
                    "run_order_seed"
                ],
                "reused_from_execution_shard_index": source_row.get(
                    "execution_shard_index", ""
                ),
                "reused_from_campaign_log": source_log,
                "reused_source_record_sha256": sha256_text(
                    canonical_json(source_record)
                ),
            }
        )
        row["campaign_log"] = _copy_reused_log(
            source["output"],
            output_dir,
            source_campaign_id,
            source_log,
        )
        record = {
            "run_key": target_job["run_key"],
            "attempt": row["attempt"],
            "completed_utc": source_record.get("completed_utc", utc_now()),
            "row": row,
        }
        _append_jsonl(target_raw_path, record)
        target_latest[target_job["run_key"]] = record
        imported += 1
        source_reports[source_campaign_id]["imported"] += 1

    expected_selected = sum(
        (
            str(job["experiment_block"]),
            str(job["planned_configuration_id"]),
            int(job["repetition"]),
        )
        in target_rules
        and target_assignments[job["run_key"]] in execution_shard_indices
        for job in plan["jobs"]
    )
    if imported + already_completed != expected_selected:
        raise ValueError(
            "reuse import did not cover every planned target result: "
            f"covered={imported + already_completed}, "
            f"expected={expected_selected}"
        )
    return {
        "reuse_policy": reuse_policy,
        "common_gcp_environment_assumed": assume_common_gcp,
        "imported": imported,
        "already_completed": already_completed,
        "expected_selected": expected_selected,
        "sources": sorted(source_reports.values(), key=lambda item: item["campaign_id"]),
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run deterministic, append-only journal experiment campaigns."
    )
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--uwrmaxsat-bin")
    parser.add_argument(
        "--uwrmaxsat-sha256",
        help="required production pin; must match the resolved executable",
    )
    parser.add_argument("--plan-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--retry-errors", action="store_true")
    parser.add_argument("--allow-dirty", action="store_true")
    parser.add_argument(
        "--allow-environment-drift",
        action="store_true",
        help=(
            "resume after a VM/solver change; keep completed rows and record "
            "the accepted environment differences"
        ),
    )
    parser.add_argument(
        "--reuse-output",
        action="append",
        default=[],
        help=(
            "validated earlier campaign output supplying result cells declared "
            "by reuse_results; repeat for multiple source campaigns"
        ),
    )
    parser.add_argument("--max-runs", type=int)
    parser.add_argument("--only-block", action="append", default=[])
    parser.add_argument(
        "--shard-count",
        type=int,
        help=(
            "number of deterministic execution shards; the full plan and its "
            "SHA-256 remain unchanged"
        ),
    )
    parser.add_argument(
        "--shard-index",
        type=int,
        action="append",
        default=[],
        help=(
            "zero-based shard assigned to this output; repeat this option to "
            "give one VM several shards"
        ),
    )
    args = parser.parse_args(argv)
    if args.max_runs is not None and args.max_runs <= 0:
        parser.error("--max-runs must be positive")
    if (args.shard_count is None) != (not args.shard_index):
        parser.error(
            "--shard-count and at least one --shard-index are required together"
        )
    if args.shard_count is not None:
        if args.shard_count <= 0:
            parser.error("--shard-count must be positive")
        if len(set(args.shard_index)) != len(args.shard_index):
            parser.error("--shard-index values must be distinct")
        if any(
            index < 0 or index >= args.shard_count
            for index in args.shard_index
        ):
            parser.error(
                "every --shard-index must satisfy 0 <= index < shard count"
            )
        args.shard_index.sort()
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    config_path = Path(args.config).resolve()
    output_dir = Path(args.output_dir).resolve()
    config = read_config(config_path)
    shard_count = args.shard_count or 1
    shard_indices = tuple(args.shard_index or [0])
    datasets = resolve_datasets(config)
    plan = build_plan(
        config,
        datasets,
        only_blocks=set(args.only_block) or None,
    )
    shard_assignments = execution_shard_assignments(plan, shard_count)
    existing_plan_path = output_dir / "plan.json"
    if existing_plan_path.is_file():
        with existing_plan_path.open(encoding="utf-8") as stream:
            existing_plan = json.load(stream)
        if existing_plan.get("plan_sha256") != plan["plan_sha256"]:
            raise SystemExit("ERROR: existing campaign plan hash does not match")
        if not args.resume and not args.plan_only:
            raise SystemExit("ERROR: output exists; use --resume for the same plan")
    else:
        output_dir.mkdir(parents=True, exist_ok=True)
        _write_json(existing_plan_path, plan)

    print(
        f"campaign={plan['campaign_id']} jobs={plan['job_count']} "
        f"plan_sha256={plan['plan_sha256']}"
    )
    selected_job_count = sum(
        shard_assignments[job["run_key"]] in shard_indices
        for job in plan["jobs"]
    )
    print(
        f"execution_shards={list(shard_indices)}/{shard_count} "
        f"selected_jobs={selected_job_count} policy={EXECUTION_SHARD_POLICY}"
    )
    if args.plan_only:
        return 0

    commit, dirty = _git_metadata()
    if dirty and config.get("require_clean_worktree", True) and not args.allow_dirty:
        raise SystemExit(
            "ERROR: production campaign refuses a dirty worktree; commit the "
            "journal implementation or use --allow-dirty only for development"
        )

    profile_errors = machine_profile_errors(plan.get("required_machine"))
    if profile_errors and not args.allow_environment_drift:
        profile_id = plan.get("required_machine", {}).get("profile_id", "production")
        raise SystemExit(
            f"ERROR: machine does not match {profile_id!r}: "
            + "; ".join(profile_errors)
        )

    needs_uwr = any(
        (
            job["configuration"]["executor"]
            in {"org_ir", "org_idle", "direct_idle"}
            or (
                job["configuration"]["executor"] == "org_bg_d2"
                and job["configuration"].get("backend", "uwrmaxsat")
                == "uwrmaxsat"
            )
            or (
                job["configuration"]["executor"] == "main"
                and job["configuration"].get("solver") == "maxsat"
                and job["configuration"].get("maxsat_backend", "uwrmaxsat")
                == "uwrmaxsat"
            )
        )
        for job in plan["jobs"]
    )
    binary = (
        resolve_uwrmaxsat_binary(args.uwrmaxsat_bin)
        if needs_uwr or args.uwrmaxsat_bin
        else None
    )
    if (needs_uwr or args.uwrmaxsat_bin) and binary is None:
        raise SystemExit("ERROR: campaign requires a pinned UWrMaxSAT executable")
    binary_sha256 = executable_sha256(binary) if binary is not None else ""
    cli_sha256 = str(args.uwrmaxsat_sha256 or "").strip().lower()
    config_sha256 = str(config.get("uwrmaxsat_sha256", "")).strip().lower()
    if cli_sha256 and not re.fullmatch(r"[0-9a-f]{64}", cli_sha256):
        raise SystemExit("ERROR: --uwrmaxsat-sha256 must be 64 lowercase hex digits")
    if cli_sha256 and config_sha256 and cli_sha256 != config_sha256:
        raise SystemExit("ERROR: CLI and config UWrMaxSAT SHA-256 pins disagree")
    expected_sha256 = cli_sha256 or config_sha256
    if expected_sha256 and expected_sha256 != binary_sha256:
        raise SystemExit(
            "ERROR: UWrMaxSAT SHA-256 mismatch: "
            f"expected {expected_sha256}, got {binary_sha256}"
        )

    environment_path = output_dir / "environment.json"
    current_profile = current_machine_profile()
    requirements_path = PROJECT_ROOT / "src" / "requirements.txt"
    current_requirements_sha256 = (
        file_sha256(requirements_path) if requirements_path.is_file() else ""
    )
    if environment_path.is_file():
        with environment_path.open(encoding="utf-8") as stream:
            environment = json.load(stream)
        resume_mismatches = []
        accepted_resume_mismatches = []
        if environment.get("plan_sha256") != plan["plan_sha256"]:
            resume_mismatches.append("plan SHA-256")
        if environment.get("git_commit") != commit:
            accepted_resume_mismatches.append("git commit")
        if environment.get("config_sha256") != file_sha256(config_path):
            resume_mismatches.append("config SHA-256")
        current_manifest_hashes = {
            _relative_to_project(_resolve_project_path(dataset["manifest"])):
            file_sha256(_resolve_project_path(dataset["manifest"]))
            for dataset in config["datasets"]
        }
        if environment.get("manifest_sha256") != current_manifest_hashes:
            resume_mismatches.append("dataset manifest SHA-256")
        if str(environment.get("uwrmaxsat_sha256", "")) != binary_sha256:
            accepted_resume_mismatches.append("UWrMaxSAT SHA-256")
        current_environment_fields = {
            "requirements SHA-256": current_requirements_sha256,
            "Python version": platform.python_version(),
            "kernel release": platform.release(),
            "CPU model": current_profile.get("cpu_model"),
            "physical CPU cores": current_profile.get("physical_cpu_cores"),
            "logical CPU cores": current_profile.get("logical_cpu_cores"),
            "system memory": current_profile.get("system_memory_mb"),
        }
        recorded_environment_fields = {
            "requirements SHA-256": environment.get("requirements_sha256"),
            "Python version": environment.get("python_version"),
            "kernel release": environment.get("kernel_release"),
            "CPU model": environment.get("cpu_model"),
            "physical CPU cores": environment.get("physical_cpu_cores"),
            "logical CPU cores": environment.get("logical_cpu_cores"),
            "system memory": environment.get("system_memory_mb"),
        }
        accepted_resume_mismatches.extend(
            label
            for label, current_value in current_environment_fields.items()
            if recorded_environment_fields[label] != current_value
        )
        if int(environment.get("execution_shard_count", 1)) != shard_count:
            resume_mismatches.append("execution shard count")
        if tuple(environment.get("execution_shard_indices", [0])) != shard_indices:
            resume_mismatches.append("execution shard indices")
        if environment.get(
            "execution_shard_policy", EXECUTION_SHARD_POLICY
        ) != EXECUTION_SHARD_POLICY:
            resume_mismatches.append("execution shard policy")
        if resume_mismatches:
            raise SystemExit(
                "ERROR: refusing to mix environments while resuming: "
                + ", ".join(resume_mismatches)
            )
        if accepted_resume_mismatches and not args.allow_environment_drift:
            raise SystemExit(
                "ERROR: refusing to mix environments while resuming: "
                + ", ".join(accepted_resume_mismatches)
                + "; pass --allow-environment-drift to retain completed jobs "
                "and record the VM transition"
            )
        if args.allow_environment_drift:
            environment.setdefault("resume_environment_history", []).append(
                {
                    "resumed_utc": utc_now(),
                    "git_commit": commit,
                    "git_dirty": dirty,
                    "python_executable": sys.executable,
                    "python_version": platform.python_version(),
                    "kernel_release": platform.release(),
                    "uwrmaxsat_binary": str(binary or ""),
                    "uwrmaxsat_sha256": binary_sha256,
                    "accepted_mismatches": accepted_resume_mismatches,
                    "accepted_machine_profile_errors": profile_errors,
                    **current_profile,
                }
            )
            environment["environment_drift_accepted"] = True
            _write_json(environment_path, environment)
    else:
        environment = build_environment(
            config_path,
            config,
            plan,
            uwrmaxsat_binary=binary,
            command=[sys.executable, str(Path(__file__).resolve()), *(argv or sys.argv[1:])],
            execution_shard_count=shard_count,
            execution_shard_indices=shard_indices,
        )
        environment["git_commit"] = commit
        environment["git_dirty"] = dirty
        if args.allow_environment_drift and profile_errors:
            environment["environment_drift_accepted"] = True
            environment["accepted_machine_profile_errors"] = profile_errors
        _write_json(environment_path, environment)

    try:
        reuse_report = import_reused_results(
            output_dir,
            plan,
            environment,
            [Path(value) for value in args.reuse_output],
            execution_shard_count=shard_count,
            execution_shard_indices=shard_indices,
            allow_dirty=args.allow_dirty,
            allow_environment_drift=args.allow_environment_drift,
        )
    except (FileNotFoundError, KeyError, TypeError, ValueError) as exc:
        raise SystemExit(f"ERROR: unable to reuse planned results: {exc}") from exc
    if plan.get("reuse_results"):
        environment["result_reuse"] = reuse_report
        _write_json(environment_path, environment)
        print(
            "reuse_state "
            f"imported={reuse_report['imported']} "
            f"already_completed={reuse_report['already_completed']} "
            f"expected_selected={reuse_report['expected_selected']}",
            flush=True,
        )

    raw_path = output_dir / "raw" / "results.jsonl"
    records = _read_jsonl(raw_path)
    latest = latest_attempts(records)
    completed = {
        run_key
        for run_key, record in latest.items()
        if record["row"].get("status") in TERMINAL_STATUSES
    }
    pending = []
    for job in plan["jobs"]:
        record = latest.get(job["run_key"])
        if job["run_key"] in completed:
            continue
        if record is not None and not args.retry_errors:
            continue
        pending.append(job)
    pending = [
        job
        for job in pending
        if shard_assignments[job["run_key"]] in shard_indices
    ]
    if args.max_runs is not None:
        pending = pending[: args.max_runs]
    print(
        f"resume_state completed={len(completed)} pending_selected={len(pending)} "
        f"raw_attempts={len(records)} shards={list(shard_indices)}/{shard_count}"
    )

    timeout = float(plan["timeout_seconds"])
    controller_grace = float(plan["controller_grace_seconds"])
    interrupted_signal: int | None = None

    def _handle_signal(signum: int, _frame: Any) -> None:
        nonlocal interrupted_signal
        interrupted_signal = signum
        raise CampaignInterrupted(f"received signal {signum}")

    handled_signals = [signal.SIGINT, signal.SIGTERM]
    if hasattr(signal, "SIGHUP"):
        handled_signals.append(signal.SIGHUP)
    previous_handlers = {
        signum: signal.signal(signum, _handle_signal)
        for signum in handled_signals
    }
    for position, job in enumerate(pending, start=1):
        previous = latest.get(job["run_key"])
        attempt = int(previous["attempt"]) + 1 if previous is not None else 1
        print(
            f"[{position}/{len(pending)}] order={job['run_order']} "
            f"block={job['experiment_block']} instance={job['instance']} "
            f"config={job['planned_configuration_id']} rep={job['repetition']}",
            flush=True,
        )
        try:
            record = run_job(
                job,
                output_dir=output_dir,
                timeout=timeout,
                controller_grace=controller_grace,
                uwrmaxsat_binary=binary,
                uwrmaxsat_sha256=binary_sha256,
                attempt=attempt,
                plan_sha256=plan["plan_sha256"],
                campaign_id=plan["campaign_id"],
                run_order_seed=int(plan["run_order_seed"]),
            )
        except (CampaignInterrupted, KeyboardInterrupt):
            rows = materialize_results(output_dir)
            _write_json(
                output_dir / "campaign_status.json",
                {
                    "updated_utc": utc_now(),
                    "plan_sha256": plan["plan_sha256"],
                    "planned_jobs": plan["job_count"],
                    "latest_rows": len(rows),
                    "terminal_rows": sum(
                        row.get("status") in TERMINAL_STATUSES for row in rows
                    ),
                    "error_rows": sum(
                        row.get("status") == "ERROR" for row in rows
                    ),
                    "interrupted": True,
                    "signal": interrupted_signal,
                },
            )
            print("campaign interrupted safely; rerun with --resume", flush=True)
            return 130
        record["row"]["execution_shard_count"] = shard_count
        record["row"]["execution_shard_indices"] = ",".join(
            str(index) for index in shard_indices
        )
        record["row"]["execution_shard_index"] = (
            shard_assignments[job["run_key"]]
        )
        record["row"]["execution_shard_policy"] = EXECUTION_SHARD_POLICY
        _append_jsonl(raw_path, record)
        latest[job["run_key"]] = record
        status = record["row"].get("status")
        print(
            f"    status={status} vector={record['row'].get('objective_vector')} "
            f"runtime={record['row'].get('runtime_seconds')}",
            flush=True,
        )
    for signum, handler in previous_handlers.items():
        signal.signal(signum, handler)
    rows = materialize_results(output_dir)
    _write_json(
        output_dir / "campaign_status.json",
        {
            "updated_utc": utc_now(),
            "plan_sha256": plan["plan_sha256"],
            "planned_jobs": plan["job_count"],
            "latest_rows": len(rows),
            "terminal_rows": sum(row.get("status") in TERMINAL_STATUSES for row in rows),
            "error_rows": sum(row.get("status") == "ERROR" for row in rows),
        },
    )
    # A retry invocation must not report success merely because it selected no
    # new jobs while an earlier ERROR row is still the latest attempt.
    final_errors = sum(row.get("status") == "ERROR" for row in rows)
    return 2 if final_errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
