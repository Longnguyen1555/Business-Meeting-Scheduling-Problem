from __future__ import annotations

import re
import time
from bisect import bisect_right
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path
from typing import Literal

from pysat.card import CardEnc, EncType
from pysat.formula import CNF, IDPool, WCNF

PrecedenceMode = Literal["traditional", "staircase"]
PrecedenceEncoding = Literal["pairwise", "sparse_suffix"]
PrecedenceGraph = Literal["direct", "distance_closure"]
DomainFilterGraph = Literal["direct", "distance_closure"]
EncodingVariant = Literal["basic", "imp1", "imp2", "imp12", "imp12+"]
DomainMode = Literal["full", "reduced"]
ObjectiveMode = Literal[
    "ir",
    "bg_d2",
    "bg_dinf",
    "ir_is",
    "ir_im_is",
    "ir_im_isq",
    "bg_ir_is",
    "is",
    "isq",
    "im_is",
]
CompactEncoding = Literal[
    "reference",
    "certified_bg",
    "demand_driven",
    "shared_counter",
    "direct_range_soft",
    "optimized",
    "objective_aware",
]
CollisionAMOEncoding = Literal["pairwise", "adaptive_commander"]

VALID_PRECEDENCE_MODES = {"traditional", "staircase"}
VALID_PRECEDENCE_ENCODINGS = {"pairwise", "sparse_suffix"}
VALID_PRECEDENCE_GRAPHS = {"direct", "distance_closure"}
VALID_DOMAIN_FILTER_GRAPHS = {"direct", "distance_closure"}
VALID_ENCODING_VARIANTS = {"basic", "imp1", "imp2", "imp12", "imp12+"}
VALID_DOMAIN_MODES = {"full", "reduced"}
VALID_OBJECTIVE_MODES = {
    "ir",
    "bg_d2",
    "bg_dinf",
    "ir_is",
    "ir_im_is",
    "ir_im_isq",
    "bg_ir_is",
    "is",
    "isq",
    "im_is",
}
VALID_COMPACT_ENCODINGS = {
    "reference",
    "certified_bg",
    "demand_driven",
    "shared_counter",
    "direct_range_soft",
    "optimized",
    "objective_aware",
}
VALID_COLLISION_AMO_ENCODINGS = {"pairwise", "adaptive_commander"}
VALID_PARTICIPANT_IDLE_CAP_RULES = {"none", "interpolated_bounds"}

# The crossover is exact for the implemented encodings: pairwise uses
# n(n-1)/2 clauses, whereas a group-size-four commander AMO first improves
# that count at n=6 (14 instead of 15 clauses).  Keep these values frozen as
# part of the experimental configuration rather than tuning per instance.
COLLISION_AMO_COMMANDER_CUTOFF = 6
COLLISION_AMO_COMMANDER_GROUP_SIZE = 4

COMPACT_ENCODING_FEATURES = {
    "reference": frozenset(),
    "certified_bg": frozenset({"certified_bg"}),
    "demand_driven": frozenset({"demand_driven"}),
    "shared_counter": frozenset({"shared_counter"}),
    "direct_range_soft": frozenset({"direct_range_soft"}),
    "optimized": frozenset(
        {
            "certified_bg",
            "demand_driven",
            "shared_counter",
            "direct_range_soft",
        }
    ),
    "objective_aware": frozenset(
        {
            "certified_bg",
            "demand_driven",
            "shared_counter",
            "direct_range_soft",
            "attainable_values",
        }
    ),
}

LEGACY_PRECEDENCE_CONFIGURATIONS: dict[str, tuple[str, str]] = {
    "traditional": ("pairwise", "direct"),
    "staircase": ("sparse_suffix", "distance_closure"),
}


@dataclass(frozen=True)
class B2BInstance:
    """B2B instance using zero-based participants, meetings, and slots."""

    n_business: int
    n_meetings: int
    n_tables: int
    n_total_slots: int
    n_morning_slots: int
    requested: list[tuple[int, int, int]]  # (p1, p2, session), session in {1,2,3}
    meetings_by_business: list[list[int]]
    n_meetings_business: list[int]
    forbidden: list[set[int]]
    fixed: list[int | None]
    precedences: list[set[int]]  # precedences[post] = direct predecessors
    instance_name: str

    @property
    def morning_slots(self) -> range:
        return range(self.n_morning_slots)

    @property
    def afternoon_slots(self) -> range:
        return range(self.n_morning_slots, self.n_total_slots)

    @property
    def max_breaks_per_participant(self) -> int:
        """Legacy upper bound for the number of break groups from the paper."""
        return max(0, (self.n_total_slots - 1) // 2)

    @property
    def max_break_slots_per_participant(self) -> int:
        """Maximum possible idle slots strictly between first and last meetings."""
        return max(0, self.n_total_slots - 2)


@dataclass(frozen=True)
class PrecedenceGraphInfo:
    direct_predecessors: list[set[int]]
    transitive_predecessors: list[set[int]]
    longest_distance: list[dict[int, int]]
    successors: list[set[int]]
    cycle_nodes: tuple[int, ...]
    direct_edge_count: int
    transitive_edge_count: int
    max_chain_distance: int


@dataclass(frozen=True)
class DomainReductionStats:
    """Execution statistics for one exact domain-reduction fixpoint."""

    iterations: int
    feasible: bool


@dataclass(frozen=True)
class ObjectiveTier:
    """One exact tier in a lexicographic objective.

    Normally the true-literal count is the tier value. A MaxSAT-only compact
    tier may instead provide exact penalty clauses or positive within-tier
    weights (ISQ). Such weighted tiers are not plain SAT cardinalities.
    ``scalar_weight`` is one for a single-tier objective and a proven
    dominating weight for one-shot MaxSAT. SAT optimizers ignore this weight
    and optimize tiers sequentially.
    """

    name: str
    literals: tuple[int, ...]
    upper_bound: int
    scalar_weight: int
    penalty_clauses: tuple[tuple[int, ...], ...] = ()
    penalty_weights: tuple[int, ...] = ()

    def __post_init__(self) -> None:
        if self.penalty_weights and (
            len(self.penalty_weights) != len(self.maxsat_clauses)
            or any(weight <= 0 for weight in self.penalty_weights)
        ):
            raise ValueError("tier penalty weights must be positive and match clauses")

    @property
    def maxsat_weights(self) -> tuple[int, ...]:
        """Within-tier costs, before the lexicographic dominating multiplier."""
        return self.penalty_weights or (1,) * len(self.maxsat_clauses)

    @property
    def maxsat_clauses(self) -> tuple[tuple[int, ...], ...]:
        """Return clauses penalized by the corresponding ``maxsat_weights``."""

        if self.penalty_clauses:
            return self.penalty_clauses
        return tuple((-literal,) for literal in self.literals)

    @property
    def supports_cardinality_search(self) -> bool:
        """Whether the tier is a plain count usable by the SAT procedures."""

        return not self.penalty_clauses and not self.penalty_weights


@dataclass(frozen=True)
class B2BSolutionStats:
    """Schedule statistics for the internal-idle-slot range over P*.

    ``participant_breaks[p]`` is retained for backward compatibility, but now
    stores the total number of idle time slots between consecutive meetings of
    participant p, not the number of contiguous break groups. The objective
    gap is evaluated only over ``P* = {p : |M_p| >= 2}``.
    """

    total_breaks: int
    participant_breaks: list[int]
    objective_gap: int
    all_participant_idle_range: int
    objective_participants: tuple[int, ...]
    meetings_per_slot: list[list[int]]
    busy_participants_per_slot: list[int]
    participant_break_groups: list[int] = field(default_factory=list)
    total_break_groups: int = 0
    break_group_range: int = 0
    objective_mode: str = "ir"
    objective_vector: tuple[int, ...] = ()

    @property
    def total_internal_idle_slots(self) -> int:
        """Sum of internal idle slots over all participants."""
        return self.total_breaks

    @property
    def maximum_internal_idle_slots(self) -> int:
        return max((self.participant_breaks[p] for p in self.objective_participants), default=0)

    @property
    def squared_internal_idle_slots(self) -> int:
        return sum(self.participant_breaks[p] ** 2 for p in self.objective_participants)

    @property
    def participant_internal_idle_slots(self) -> list[int]:
        """Internal idle-slot count B(p) for every participant."""
        return self.participant_breaks

    @property
    def idle_range(self) -> int:
        """Range of internal-idle totals over P*."""
        return self.objective_gap

    @property
    def objective_participant_ids(self) -> tuple[int, ...]:
        """One-based participant IDs in P*."""
        return tuple(participant + 1 for participant in self.objective_participants)

    # Backward-compatible names used by the existing benchmark runner.
    @property
    def total_break_slots(self) -> int:
        return self.total_internal_idle_slots

    @property
    def participant_break_slots(self) -> list[int]:
        return self.participant_internal_idle_slots

@dataclass(frozen=True)
class B2BModelArtifacts:
    cnf: CNF
    objective_lits: list[int]
    objective_name: str
    objective_mode: str
    objective_tiers: tuple[ObjectiveTier, ...]
    objective_participants: tuple[int, ...]
    objective_gap_lits: list[int]
    idle_threshold_lits_by_participant: list[list[int]]
    break_group_end_lits_by_participant: list[list[int]]
    break_group_threshold_lits_by_participant: list[list[int]]
    break_group_range_lits: list[int]
    hole_lits_by_participant: list[list[int]]
    sorted_hole_lits_by_participant: list[list[int]]
    n_vars: int
    n_clauses: int
    n_primary_variables: int
    n_auxiliary_variables: int
    n_hard_literals: int
    max_hard_clause_length: int
    n_unit_hard_clauses: int
    n_binary_hard_clauses: int
    n_ternary_hard_clauses: int
    n_long_hard_clauses: int
    encoding_variant: str
    precedence_mode: str
    precedence_encoding: str
    precedence_graph: str
    precedence_configuration: str
    domain_mode: str
    domain_filter_graph: str
    domain_filter_iterations: int
    domain_filter_seconds: float
    enabled_constraints: list[str]
    full_schedule_candidates: int
    unary_eligible_schedule_candidates: int
    initial_schedule_candidates: int
    reduced_schedule_candidates: int
    active_schedule_candidates: int
    unary_removed_schedule_candidates: int
    preprocessing_removed_schedule_candidates: int
    removed_schedule_candidates: int
    precedence_direct_edges: int
    precedence_transitive_edges: int
    precedence_cycle_nodes: tuple[int, ...]
    precedence_max_distance: int
    precedence_relation_edges: int
    precedence_pairwise_clauses: int
    precedence_sparse_link_clauses: int
    precedence_unique_suffix_cuts: int
    objective_encoding: str
    compact_encoding: str
    compact_encoding_features: tuple[str, ...]
    zero_break_certificate_participant: int | None
    zero_break_certificate_reason: str
    zero_break_branch: str
    occupancy_alias_count: int
    prefix_alias_count: int
    suffix_alias_count: int
    first_alias_count: int
    shared_counter_state_count: int
    direct_range_soft_clause_count: int
    collision_amo_encoding: str
    collision_amo_cutoff: int
    collision_amo_commander_group_size: int
    collision_amo_pairwise_group_count: int
    collision_amo_commander_group_count: int
    collision_amo_commander_variable_count: int
    collision_amo_clause_count: int
    collision_amo_max_group_size: int
    participant_idle_cap_rule: str
    participant_idle_cap_alpha: str
    participant_idle_lower_bounds: tuple[int, ...]
    participant_idle_upper_bounds: tuple[int, ...]
    participant_idle_caps: tuple[int, ...]
    participant_idle_bounds_feasible: bool
    participant_idle_cap_clause_count: int
    participant_idle_attainable_values: tuple[tuple[int, ...], ...]
    idle_threshold_dense_level_count: int
    idle_threshold_encoded_level_count: int
    idle_threshold_removed_level_count: int
    objective_aggregate_dense_level_count: int
    objective_aggregate_encoded_level_count: int
    objective_constant_soft_weight: int

# ---------------------------------------------------------------------------
# MiniZinc .dzn parser
# ---------------------------------------------------------------------------


def _remove_comments(text: str) -> str:
    return "\n".join(
        line
        for raw in text.splitlines()
        if (line := raw.split("%", 1)[0].strip())
    )


def _extract_int(text: str, name: str) -> int:
    match = re.search(rf"\b{name}\s*=\s*(-?\d+)\s*;", text)
    if not match:
        raise ValueError(f"Cannot find integer field {name!r}")
    return int(match.group(1))


def _extract_block(text: str, name: str, open_char: str, close_char: str) -> str:
    match = re.search(rf"\b{name}\s*=\s*{re.escape(open_char)}", text)
    if not match:
        raise ValueError(f"Cannot find block field {name!r}")

    start = match.end()
    depth = 1
    i = start
    while i < len(text):
        ch = text[i]
        if ch == open_char:
            depth += 1
        elif ch == close_char:
            depth -= 1
            if depth == 0:
                return text[start:i]
        i += 1
    raise ValueError(f"Cannot find end of block field {name!r}")


def _extract_int_list(block: str) -> list[int]:
    return [int(x) for x in re.findall(r"-?\d+", block)]


def _extract_set_array(block: str) -> list[set[int]]:
    result: list[set[int]] = []
    i = 0
    while i < len(block):
        if block[i] != "{":
            i += 1
            continue
        start = i + 1
        depth = 1
        i += 1
        while i < len(block) and depth:
            if block[i] == "{":
                depth += 1
            elif block[i] == "}":
                depth -= 1
                if depth == 0:
                    result.append({int(x) for x in re.findall(r"-?\d+", block[start:i])})
                    break
            i += 1
        i += 1
    return result


def read_instance(path: str | Path, *, validate_meetingsx_business: bool = True) -> B2BInstance:
    """Read one original B2B .dzn file and convert all indices to zero-based."""

    path = Path(path)
    text = _remove_comments(path.read_text(encoding="utf-8"))

    n_business = _extract_int(text, "nBusiness")
    n_meetings = _extract_int(text, "nMeetings")
    n_tables = _extract_int(text, "nTables")
    n_total_slots = _extract_int(text, "nTotalSlots")
    n_morning_slots = _extract_int(text, "nMorningSlots")

    if n_business < 0 or n_meetings < 0 or n_tables < 0 or n_total_slots < 0:
        raise ValueError("Instance sizes must be non-negative")
    if not 0 <= n_morning_slots <= n_total_slots:
        raise ValueError("nMorningSlots must be between 0 and nTotalSlots")

    requested_nums = _extract_int_list(_extract_block(text, "requested", "[", "]"))
    if len(requested_nums) != 3 * n_meetings:
        raise ValueError(
            f"requested must contain 3*nMeetings values; got {len(requested_nums)} "
            f"for nMeetings={n_meetings}"
        )

    requested: list[tuple[int, int, int]] = []
    for i in range(0, len(requested_nums), 3):
        p1 = requested_nums[i] - 1
        p2 = requested_nums[i + 1] - 1
        session = requested_nums[i + 2]
        m = i // 3
        if not (0 <= p1 < n_business and 0 <= p2 < n_business):
            raise ValueError(f"Meeting {m + 1} contains an invalid participant")
        if p1 == p2:
            raise ValueError(f"Meeting {m + 1} contains the same participant twice")
        if session not in {1, 2, 3}:
            raise ValueError(f"Meeting {m + 1} has invalid session code {session}")
        requested.append((p1, p2, session))

    meetingsx_business_raw = _extract_set_array(
        _extract_block(text, "meetingsxBusiness", "[", "]")
    )
    n_meetings_business = _extract_int_list(
        _extract_block(text, "nMeetingsBusiness", "[", "]")
    )
    forbidden_raw = _extract_set_array(_extract_block(text, "forbidden", "[", "]"))
    fixed_raw = _extract_int_list(_extract_block(text, "fixed", "[", "]"))
    precedences_raw = _extract_set_array(_extract_block(text, "precedences", "[", "]"))

    if len(n_meetings_business) != n_business:
        raise ValueError("nMeetingsBusiness must have nBusiness integers")
    if len(forbidden_raw) != n_business:
        raise ValueError("forbidden must have nBusiness sets")
    if len(fixed_raw) != n_meetings:
        raise ValueError("fixed must have nMeetings integers")
    if len(precedences_raw) != n_meetings:
        raise ValueError("precedences must have nMeetings sets")

    forbidden: list[set[int]] = []
    for p, slots in enumerate(forbidden_raw):
        converted = {slot - 1 for slot in slots if slot > 0}
        invalid = [slot + 1 for slot in converted if not 0 <= slot < n_total_slots]
        if invalid:
            raise ValueError(f"Participant {p + 1} has invalid forbidden slots {invalid}")
        forbidden.append(converted)

    fixed: list[int | None] = []
    for m, slot in enumerate(fixed_raw):
        value = None if slot == 0 else slot - 1
        if value is not None and not 0 <= value < n_total_slots:
            raise ValueError(f"Meeting {m + 1} has invalid fixed slot {slot}")
        fixed.append(value)

    precedences: list[set[int]] = []
    for post, preds in enumerate(precedences_raw):
        converted = {pred - 1 for pred in preds if pred > 0}
        invalid = [pred + 1 for pred in converted if not 0 <= pred < n_meetings]
        if invalid:
            raise ValueError(f"Meeting {post + 1} has invalid predecessors {invalid}")
        precedences.append(converted)

    meetings_by_business: list[list[int]] = [[] for _ in range(n_business)]
    for m, (p1, p2, _) in enumerate(requested):
        meetings_by_business[p1].append(m)
        meetings_by_business[p2].append(m)

    for p, meetings in enumerate(meetings_by_business):
        if len(meetings) != n_meetings_business[p]:
            raise ValueError(
                f"Participant {p + 1}: derived {len(meetings)} meetings but "
                f"nMeetingsBusiness says {n_meetings_business[p]}"
            )

    if validate_meetingsx_business:
        if len(meetingsx_business_raw) != n_business:
            raise ValueError("meetingsxBusiness must have nBusiness sets")
        for p, meetings in enumerate(meetings_by_business):
            # Original data uses dummy value 1 and shifts meeting ids by +1.
            expected = {1} | {m + 2 for m in meetings}
            if meetingsx_business_raw[p] != expected:
                raise ValueError(
                    f"Participant {p + 1}: meetingsxBusiness mismatch; "
                    f"expected {sorted(expected)}, got {sorted(meetingsx_business_raw[p])}"
                )

    return B2BInstance(
        n_business=n_business,
        n_meetings=n_meetings,
        n_tables=n_tables,
        n_total_slots=n_total_slots,
        n_morning_slots=n_morning_slots,
        requested=requested,
        meetings_by_business=meetings_by_business,
        n_meetings_business=n_meetings_business,
        forbidden=forbidden,
        fixed=fixed,
        precedences=precedences,
        instance_name=path.name,
    )


# ---------------------------------------------------------------------------
# Precedence graph and optimized domain reduction
# ---------------------------------------------------------------------------


def build_precedence_graph(precedences: list[set[int]]) -> PrecedenceGraphInfo:
    """Build E*, detect cycles, and compute longest precedence-chain distances.

    ``longest_distance[post][pred] = d`` means that the longest directed path
    from ``pred`` to ``post`` contains ``d`` strict-precedence edges. Therefore
    every feasible schedule satisfies ``time(pred) + d <= time(post)``.
    """

    n = len(precedences)
    direct = [set(preds) for preds in precedences]
    closure = [set(preds) for preds in precedences]

    for k in range(n):
        for post in range(n):
            if k in closure[post]:
                closure[post].update(closure[k])

    successors = [set() for _ in range(n)]
    indegree = [0] * n
    for post, preds in enumerate(direct):
        indegree[post] = len(preds)
        for pred in preds:
            successors[pred].add(post)

    cycle_nodes = tuple(v for v in range(n) if v in closure[v])
    longest_distance: list[dict[int, int]] = [dict() for _ in range(n)]

    if not cycle_nodes:
        ready = [v for v, deg in enumerate(indegree) if deg == 0]
        topo: list[int] = []
        cursor = 0
        while cursor < len(ready):
            node = ready[cursor]
            cursor += 1
            topo.append(node)
            for post in successors[node]:
                indegree[post] -= 1
                if indegree[post] == 0:
                    ready.append(post)

        for post in topo:
            distances = longest_distance[post]
            for pred in direct[post]:
                distances[pred] = max(distances.get(pred, 0), 1)
                for ancestor, distance in longest_distance[pred].items():
                    distances[ancestor] = max(
                        distances.get(ancestor, 0), distance + 1
                    )

    return PrecedenceGraphInfo(
        direct_predecessors=direct,
        transitive_predecessors=closure,
        longest_distance=longest_distance,
        successors=successors,
        cycle_nodes=cycle_nodes,
        direct_edge_count=sum(map(len, direct)),
        transitive_edge_count=sum(map(len, closure)),
        max_chain_distance=max(
            (distance for row in longest_distance for distance in row.values()),
            default=0,
        ),
    )


def _session_slots(inst: B2BInstance, m: int) -> set[int]:
    session = inst.requested[m][2]
    if session == 1:
        return set(inst.morning_slots)
    if session == 2:
        return set(inst.afternoon_slots)
    return set(range(inst.n_total_slots))


def original_eligible_slots(inst: B2BInstance, m: int) -> set[int]:
    """Unary domain from session, fixed meeting, and participant availability."""

    p1, p2, _ = inst.requested[m]
    slots = _session_slots(inst, m)
    fixed = inst.fixed[m]
    if fixed is not None:
        slots.intersection_update({fixed})
    slots.difference_update(inst.forbidden[p1])
    slots.difference_update(inst.forbidden[p2])
    return slots


def _has_full_slot_matching(
    meetings: list[int],
    domains: list[set[int]],
    *,
    fixed_meeting: int | None = None,
    fixed_slot: int | None = None,
) -> bool:
    """Check participant all-different feasibility with one optional fixed edge."""

    if fixed_meeting is not None:
        if fixed_slot is None or fixed_slot not in domains[fixed_meeting]:
            return False
        blocked = {fixed_slot}
        remaining = [m for m in meetings if m != fixed_meeting]
    else:
        blocked = set()
        remaining = list(meetings)

    remaining.sort(key=lambda m: len(domains[m] - blocked))
    slot_owner: dict[int, int] = {}

    def augment(meeting: int, seen: set[int]) -> bool:
        for slot in sorted(domains[meeting]):
            if slot in blocked or slot in seen:
                continue
            seen.add(slot)
            owner = slot_owner.get(slot)
            if owner is None or augment(owner, seen):
                slot_owner[slot] = meeting
                return True
        return False

    return all(augment(meeting, set()) for meeting in remaining)


def compute_participant_idle_bounds(
    inst: B2BInstance,
) -> tuple[tuple[int, ...], tuple[int, ...], bool]:
    """Return reproducible unary-domain bounds ``LB_p`` and ``UB_p`` for idle.

    The bounds deliberately use only the original unary domains (session,
    fixed meetings, and participant availability), so Full and Reduced models
    receive identical caps. ``LB_p`` is the shortest interval in which the
    participant's meetings admit distinct eligible slots. ``UB_p`` spans the
    earliest and latest eligible slots. Inter-participant table conflicts and
    precedences are excluded from this bound calculation.
    """

    domains = [
        set(original_eligible_slots(inst, meeting))
        for meeting in range(inst.n_meetings)
    ]
    lower: list[int] = []
    upper: list[int] = []
    feasible = True

    for meetings in inst.meetings_by_business:
        count = len(meetings)
        if count <= 1:
            lower.append(0)
            upper.append(0)
            continue

        union = set().union(*(domains[meeting] for meeting in meetings))
        participant_feasible = bool(union) and _has_full_slot_matching(
            meetings, domains
        )
        if not participant_feasible:
            lower.append(0)
            upper.append(0)
            feasible = False
            continue

        upper_bound = max(0, max(union) - min(union) + 1 - count)
        lower_bound: int | None = None
        for width in range(count, inst.n_total_slots + 1):
            for left in range(0, inst.n_total_slots - width + 1):
                right = left + width - 1
                restricted = list(domains)
                restricted = [set(values) for values in restricted]
                for meeting in meetings:
                    restricted[meeting].intersection_update(range(left, right + 1))
                if _has_full_slot_matching(meetings, restricted):
                    lower_bound = width - count
                    break
            if lower_bound is not None:
                break

        if lower_bound is None:
            lower.append(0)
            upper.append(upper_bound)
            feasible = False
        else:
            lower.append(lower_bound)
            upper.append(upper_bound)

    return tuple(lower), tuple(upper), feasible


def _has_interval_matching_with_endpoints(
    meetings: list[int],
    domains: list[set[int]],
    *,
    left: int,
    right: int,
    left_meeting: int,
    right_meeting: int,
) -> bool:
    """Return whether a participant can occupy both ends of an interval.

    ``left_meeting`` and ``right_meeting`` are fixed to the two endpoints.
    Every remaining meeting must use a distinct interior slot.  The routine is
    deliberately local to one participant.  It therefore provides a safe
    support test without making assumptions about other participants or table
    capacity.
    """

    if left_meeting == right_meeting:
        return False
    if left not in domains[left_meeting] or right not in domains[right_meeting]:
        return False

    remaining = [
        meeting
        for meeting in meetings
        if meeting not in {left_meeting, right_meeting}
    ]
    if not remaining:
        return True

    interior = set(range(left + 1, right))
    eligible = {
        meeting: domains[meeting].intersection(interior)
        for meeting in remaining
    }
    if any(not values for values in eligible.values()):
        return False

    remaining.sort(key=lambda meeting: len(eligible[meeting]))
    slot_owner: dict[int, int] = {}

    def augment(meeting: int, seen: set[int]) -> bool:
        for slot in sorted(eligible[meeting]):
            if slot in seen:
                continue
            seen.add(slot)
            owner = slot_owner.get(slot)
            if owner is None or augment(owner, seen):
                slot_owner[slot] = meeting
                return True
        return False

    return all(augment(meeting, set()) for meeting in remaining)


def compute_participant_attainable_idle_values(
    inst: B2BInstance,
    domains: list[list[int]] | list[set[int]],
) -> tuple[tuple[int, ...], ...]:
    """Compute locally attainable internal-waiting values for each participant.

    A value is retained when the participant's meetings admit a distinct-slot
    matching whose first and last occupied slots realize that value.  The
    supplied domains may already include any solution-preserving filtering.
    Consequently, every globally feasible schedule uses a retained value, while
    values that need conflicts with other participants may remain in the set.
    This one-sided guarantee is exactly what objective compression requires.
    """

    if len(domains) != inst.n_meetings:
        raise ValueError("domain count must match the number of meetings")
    normalized = [set(values) for values in domains]
    profiles: list[tuple[int, ...]] = []

    for meetings in inst.meetings_by_business:
        count = len(meetings)
        if count <= 1:
            profiles.append((0,))
            continue
        if any(not normalized[meeting] for meeting in meetings):
            profiles.append((0,))
            continue

        possible_slots = sorted(
            set().union(*(normalized[meeting] for meeting in meetings))
        )
        values: set[int] = set()
        for left in possible_slots:
            left_candidates = [
                meeting for meeting in meetings if left in normalized[meeting]
            ]
            for right in possible_slots:
                if right - left + 1 < count:
                    continue
                right_candidates = [
                    meeting for meeting in meetings if right in normalized[meeting]
                ]
                supported = any(
                    _has_interval_matching_with_endpoints(
                        meetings,
                        normalized,
                        left=left,
                        right=right,
                        left_meeting=left_meeting,
                        right_meeting=right_meeting,
                    )
                    for left_meeting in left_candidates
                    for right_meeting in right_candidates
                    if left_meeting != right_meeting
                )
                if supported:
                    values.add(right - left + 1 - count)

        # An empty profile can occur only when the local all-different
        # constraint is infeasible.  The base CNF is then unsatisfiable, so a
        # neutral placeholder keeps the artifact schema total without changing
        # any feasible objective value.
        profiles.append(tuple(sorted(values)) if values else (0,))

    return tuple(profiles)


def interpolate_participant_idle_caps(
    lower_bounds: tuple[int, ...],
    upper_bounds: tuple[int, ...],
    alpha: Fraction | str | int | float = Fraction(1, 2),
) -> tuple[int, ...]:
    """Compute ``floor(LB_p + alpha (UB_p-LB_p))`` exactly."""

    fraction = alpha if isinstance(alpha, Fraction) else Fraction(str(alpha))
    if fraction < 0 or fraction > 1:
        raise ValueError("participant idle cap alpha must lie in [0, 1]")
    if len(lower_bounds) != len(upper_bounds):
        raise ValueError("participant idle lower/upper bound lengths differ")
    caps: list[int] = []
    for lower, upper in zip(lower_bounds, upper_bounds):
        if lower < 0 or upper < lower:
            raise ValueError(f"invalid participant idle bounds [{lower}, {upper}]")
        value = Fraction(lower) + fraction * (upper - lower)
        caps.append(value.numerator // value.denominator)
    return tuple(caps)


def _propagate_distance_precedences(
    domains: list[set[int]],
    distances_by_post: list[dict[int, int]],
) -> bool:
    """Apply precedence bounds consistency over the selected filtering graph."""

    changed = False
    for post, distances in enumerate(distances_by_post):
        for pred, distance in distances.items():
            pred_domain = domains[pred]
            post_domain = domains[post]
            if not pred_domain or not post_domain:
                continue

            latest_pred = max(post_domain) - distance
            new_pred = {slot for slot in pred_domain if slot <= latest_pred}
            if new_pred != pred_domain:
                domains[pred] = pred_domain = new_pred
                changed = True
                if not pred_domain:
                    continue

            earliest_post = min(pred_domain) + distance
            new_post = {slot for slot in post_domain if slot >= earliest_post}
            if new_post != post_domain:
                domains[post] = new_post
                changed = True
    return changed


def _propagate_participant_matchings(
    inst: B2BInstance,
    domains: list[set[int]],
) -> tuple[bool, bool]:
    """Enforce GAC on every participant's all-different slot constraint.

    Returns ``(changed, feasible)``. Candidate ``meeting@slot`` is removed when
    fixing that edge prevents a full matching for the remaining meetings of the
    participant. This preprocessing is exact and does not alter the solution set.
    """

    changed = False
    for meetings in inst.meetings_by_business:
        if len(meetings) <= 1:
            continue
        if any(not domains[m] for m in meetings):
            return changed, False
        if not _has_full_slot_matching(meetings, domains):
            domains[meetings[0]].clear()
            return True, False

        for meeting in meetings:
            if len(domains[meeting]) <= 1:
                continue
            for slot in tuple(sorted(domains[meeting])):
                if not _has_full_slot_matching(
                    meetings,
                    domains,
                    fixed_meeting=meeting,
                    fixed_slot=slot,
                ):
                    domains[meeting].remove(slot)
                    changed = True
                    if not domains[meeting]:
                        return changed, False
    return changed, True


def _propagate_saturated_table_slots(
    inst: B2BInstance,
    domains: list[set[int]],
) -> tuple[bool, bool]:
    """Propagate slots already saturated by fixed/singleton meetings."""

    changed = False
    for slot in range(inst.n_total_slots):
        forced = [m for m, domain in enumerate(domains) if domain == {slot}]
        if len(forced) > inst.n_tables:
            domains[forced[0]].clear()
            return True, False
        if len(forced) != inst.n_tables:
            continue
        for meeting, domain in enumerate(domains):
            if len(domain) > 1 and slot in domain:
                domain.remove(slot)
                changed = True
                if not domain:
                    return changed, False
    return changed, True


def reduce_domains_with_precedence_profiled(
    inst: B2BInstance,
    graph: PrecedenceGraphInfo,
    domain_filter_graph: DomainFilterGraph = "distance_closure",
) -> tuple[list[list[int]], int, int, DomainReductionStats]:
    """Run exact preprocessing and return its convergence statistics.

    The fixpoint combines unary restrictions, precedence propagation over either
    direct E or distance-labelled E*, participant all-different matching GAC, and
    saturated table-slot propagation. ``iterations`` counts complete executions
    of this propagation sequence, including the final pass that confirms the
    fixpoint.
    """

    if domain_filter_graph not in VALID_DOMAIN_FILTER_GRAPHS:
        raise ValueError(
            f"Unknown domain_filter_graph={domain_filter_graph!r}"
        )
    domains = [original_eligible_slots(inst, m) for m in range(inst.n_meetings)]
    initial_count = sum(len(domain) for domain in domains)

    if graph.cycle_nodes:
        domains[graph.cycle_nodes[0]].clear()
        return (
            [sorted(domain) for domain in domains],
            initial_count,
            sum(map(len, domains)),
            DomainReductionStats(iterations=0, feasible=False),
        )

    if domain_filter_graph == "direct":
        effective_distances = [
            {pred: 1 for pred in predecessors}
            for predecessors in graph.direct_predecessors
        ]
    else:
        effective_distances = graph.longest_distance

    changed = True
    iterations = 0
    feasible = True
    while changed:
        iterations += 1
        changed = _propagate_distance_precedences(
            domains,
            effective_distances,
        )
        matching_changed, feasible = _propagate_participant_matchings(inst, domains)
        changed = changed or matching_changed
        if not feasible:
            break
        capacity_changed, feasible = _propagate_saturated_table_slots(inst, domains)
        changed = changed or capacity_changed
        if not feasible:
            break

    reduced_count = sum(len(domain) for domain in domains)
    return (
        [sorted(domain) for domain in domains],
        initial_count,
        reduced_count,
        DomainReductionStats(iterations=iterations, feasible=feasible),
    )


def reduce_domains_with_precedence(
    inst: B2BInstance,
    graph: PrecedenceGraphInfo,
    domain_filter_graph: DomainFilterGraph = "distance_closure",
) -> tuple[list[list[int]], int, int]:
    """Run exact preprocessing to a fixpoint.

    This backward-compatible wrapper omits the execution statistics returned by
    :func:`reduce_domains_with_precedence_profiled`.
    """

    domains, initial_count, reduced_count, _ = (
        reduce_domains_with_precedence_profiled(
            inst,
            graph,
            domain_filter_graph=domain_filter_graph,
        )
    )
    return domains, initial_count, reduced_count


def objective_participants(inst: B2BInstance) -> tuple[int, ...]:
    """Return P* = {p: participant p attends at least two meetings}."""

    return tuple(
        participant
        for participant, meetings in enumerate(inst.meetings_by_business)
        if len(meetings) >= 2
    )


def compute_solution_stats(
    inst: B2BInstance,
    assignment: list[int],
    *,
    participants: tuple[int, ...] | None = None,
    objective_mode: ObjectiveMode | str = "ir",
) -> B2BSolutionStats:
    """Compute journal objective metrics directly from a decoded schedule."""

    if objective_mode not in VALID_OBJECTIVE_MODES:
        raise ValueError(f"Unknown objective_mode={objective_mode!r}")

    selected_participants = (
        objective_participants(inst) if participants is None else participants
    )
    meetings_per_slot: list[list[int]] = [
        [] for _ in range(inst.n_total_slots)
    ]
    for meeting, slot in enumerate(assignment):
        if 0 <= slot < inst.n_total_slots:
            meetings_per_slot[slot].append(meeting)

    participant_idle = [0] * inst.n_business
    participant_break_groups = [0] * inst.n_business
    for participant, meetings in enumerate(inst.meetings_by_business):
        slots = sorted(
            assignment[meeting]
            for meeting in meetings
            if 0 <= meeting < len(assignment) and assignment[meeting] >= 0
        )
        if len(slots) >= 2:
            participant_idle[participant] = (
                slots[-1] - slots[0] + 1 - len(slots)
            )
            participant_break_groups[participant] = sum(
                right > left + 1
                for left, right in zip(slots, slots[1:])
            )

    objective_values = [
        participant_idle[participant]
        for participant in selected_participants
    ]
    objective_gap = (
        max(objective_values) - min(objective_values)
        if len(objective_values) >= 2
        else 0
    )
    all_participant_gap = (
        max(participant_idle) - min(participant_idle)
        if len(participant_idle) >= 2
        else 0
    )
    break_group_range = (
        max(participant_break_groups) - min(participant_break_groups)
        if len(participant_break_groups) >= 2
        else 0
    )
    total_idle = sum(participant_idle)
    total_break_groups = sum(participant_break_groups)
    objective_vectors = {
        "ir": (objective_gap,),
        "bg_d2": (total_break_groups,),
        "bg_dinf": (total_break_groups,),
        "ir_is": (objective_gap, total_idle),
        "ir_im_is": (
            objective_gap,
            max(objective_values, default=0),
            total_idle,
        ),
        "ir_im_isq": (
            objective_gap,
            max(objective_values, default=0),
            sum(value * value for value in objective_values),
        ),
        "bg_ir_is": (total_break_groups, objective_gap, total_idle),
        "is": (total_idle,),
        "isq": (sum(value * value for value in objective_values),),
        "im_is": (max(objective_values, default=0), total_idle),
    }
    return B2BSolutionStats(
        total_breaks=total_idle,
        participant_breaks=participant_idle,
        objective_gap=objective_gap,
        all_participant_idle_range=all_participant_gap,
        objective_participants=selected_participants,
        meetings_per_slot=meetings_per_slot,
        busy_participants_per_slot=[
            2 * len(meetings) for meetings in meetings_per_slot
        ],
        participant_break_groups=participant_break_groups,
        total_break_groups=total_break_groups,
        break_group_range=break_group_range,
        objective_mode=str(objective_mode),
        objective_vector=objective_vectors[str(objective_mode)],
    )


def validate_schedule_assignment(
    inst: B2BInstance,
    assignment: list[int],
    *,
    graph: PrecedenceGraphInfo | None = None,
) -> list[str]:
    """Check a schedule against the original hard B2B semantics."""

    errors: list[str] = []
    if len(assignment) != inst.n_meetings:
        return ["assignment length does not match nMeetings"]

    for meeting, slot in enumerate(assignment):
        if slot not in original_eligible_slots(inst, meeting):
            errors.append(
                f"meeting {meeting + 1} assigned to an ineligible slot "
                f"{slot + 1 if slot >= 0 else slot}"
            )

    for participant, meetings in enumerate(inst.meetings_by_business):
        seen: dict[int, int] = {}
        for meeting in meetings:
            slot = assignment[meeting]
            if slot in seen:
                errors.append(
                    f"participant {participant + 1} collision at slot {slot + 1}: "
                    f"meetings {seen[slot] + 1} and {meeting + 1}"
                )
            seen[slot] = meeting

    for slot in range(inst.n_total_slots):
        count = sum(assigned == slot for assigned in assignment)
        if count > inst.n_tables:
            errors.append(
                f"capacity exceeded at slot {slot + 1}: "
                f"{count}>{inst.n_tables}"
            )

    precedence_graph = graph or build_precedence_graph(inst.precedences)
    for post, preds in enumerate(precedence_graph.direct_predecessors):
        for pred in preds:
            if assignment[pred] >= assignment[post]:
                errors.append(
                    f"precedence violation: meeting {pred + 1} "
                    f"!< meeting {post + 1}"
                )
    return errors


def resolve_precedence_configuration(
    precedence_mode: str | None,
    precedence_encoding: str | None,
    precedence_graph: str | None,
    *,
    default_mode: PrecedenceMode,
) -> tuple[str, str, str]:
    """Resolve independent P/G flags and the deprecated composite mode.

    A caller must either provide both independent flags or neither. The legacy
    modes remain accepted for API compatibility, but conflicting legacy and
    independent values are rejected instead of being silently overridden.
    """

    if precedence_mode is not None:
        if precedence_mode not in VALID_PRECEDENCE_MODES:
            raise ValueError(f"Unknown precedence_mode={precedence_mode!r}")
        legacy_encoding, legacy_graph = LEGACY_PRECEDENCE_CONFIGURATIONS[
            precedence_mode
        ]
        if (
            precedence_encoding is not None
            and precedence_encoding != legacy_encoding
        ):
            raise ValueError(
                "precedence_mode conflicts with precedence_encoding: "
                f"{precedence_mode!r} requires {legacy_encoding!r}"
            )
        if precedence_graph is not None and precedence_graph != legacy_graph:
            raise ValueError(
                "precedence_mode conflicts with precedence_graph: "
                f"{precedence_mode!r} requires {legacy_graph!r}"
            )
        precedence_encoding = legacy_encoding
        precedence_graph = legacy_graph
    elif precedence_encoding is None and precedence_graph is None:
        precedence_mode = default_mode
        precedence_encoding, precedence_graph = (
            LEGACY_PRECEDENCE_CONFIGURATIONS[default_mode]
        )
    elif precedence_encoding is None or precedence_graph is None:
        raise ValueError(
            "precedence_encoding and precedence_graph must be specified together"
        )

    if precedence_encoding not in VALID_PRECEDENCE_ENCODINGS:
        raise ValueError(
            f"Unknown precedence_encoding={precedence_encoding!r}"
        )
    if precedence_graph not in VALID_PRECEDENCE_GRAPHS:
        raise ValueError(f"Unknown precedence_graph={precedence_graph!r}")

    legacy_mode = next(
        (
            mode
            for mode, configuration in LEGACY_PRECEDENCE_CONFIGURATIONS.items()
            if configuration == (precedence_encoding, precedence_graph)
        ),
        "factorial",
    )
    return precedence_encoding, precedence_graph, legacy_mode


# ---------------------------------------------------------------------------
# Combined optimized MaxSAT/SAT encoding
# ---------------------------------------------------------------------------


class B2BSATModel:
    """Optimized exact encoder for the journal objective family.

    The backward-compatible default optimization objective is

        minimize max_{p in P*} B(p) - min_{p in P*} B(p),

    where ``B(p)`` is the total number of empty slots strictly between the first
    and last meetings of participant ``p``, and
    ``P* = {p : |M_p| >= 2}``. Participants outside P* always have B(p)=0 and
    are excluded from the range. No hard upper bound on this gap is generated.

    The key identity used by the objective encoding is

        B(p) = last_slot(p) - first_slot(p) + 1 - |M_p|.

    This replaces per-idle-slot variables and quadratic sorting networks with a
    linear prefix/suffix span encoding and exact unary threshold literals.

    ``precedence_encoding`` (P) and ``precedence_graph`` (G) are independent:
    either encoding can consume either the direct distance-one relations or the
    distance-labelled transitive closure. ``domain_filter_graph`` (F) independently
    selects direct E or distance-labelled E* for the exact domain-reduction
    fixpoint, while the encoded precedence graph remains unchanged.

    ``domain_mode="full"`` creates the complete meeting-slot Cartesian product
    and encodes unary input restrictions as hard clauses. ``"reduced"`` omits
    variables removed by the exact preprocessing fixpoint. Every other encoding
    component follows the same code path in both modes.
    """

    def __init__(
        self,
        inst: B2BInstance,
        precedence_mode: PrecedenceMode | None = None,
        encoding_variant: EncodingVariant = "imp12+",
        domain_mode: DomainMode = "reduced",
        *,
        precedence_encoding: PrecedenceEncoding | None = None,
        precedence_graph: PrecedenceGraph | None = None,
        domain_filter_graph: DomainFilterGraph = "distance_closure",
        objective_mode: ObjectiveMode = "ir",
        compact_encoding: CompactEncoding = "reference",
        collision_amo_encoding: CollisionAMOEncoding = "pairwise",
        participant_idle_cap_rule: str = "none",
        participant_idle_cap_alpha: Fraction | str | int | float = "1/2",
    ) -> None:
        if encoding_variant not in VALID_ENCODING_VARIANTS:
            raise ValueError(f"Unknown encoding_variant={encoding_variant!r}")
        if domain_mode not in VALID_DOMAIN_MODES:
            raise ValueError(f"Unknown domain_mode={domain_mode!r}")
        if domain_filter_graph not in VALID_DOMAIN_FILTER_GRAPHS:
            raise ValueError(
                f"Unknown domain_filter_graph={domain_filter_graph!r}"
            )
        if objective_mode not in VALID_OBJECTIVE_MODES:
            raise ValueError(f"Unknown objective_mode={objective_mode!r}")
        if compact_encoding not in VALID_COMPACT_ENCODINGS:
            raise ValueError(f"Unknown compact_encoding={compact_encoding!r}")
        if collision_amo_encoding not in VALID_COLLISION_AMO_ENCODINGS:
            raise ValueError(
                "Unknown collision_amo_encoding="
                f"{collision_amo_encoding!r}"
            )
        if participant_idle_cap_rule not in VALID_PARTICIPANT_IDLE_CAP_RULES:
            raise ValueError(
                "Unknown participant_idle_cap_rule="
                f"{participant_idle_cap_rule!r}"
            )
        if participant_idle_cap_rule != "none" and objective_mode not in {
            "ir_im_is",
            "ir_im_isq",
        }:
            raise ValueError(
                "participant idle caps are defined only for ir_im_is and "
                "ir_im_isq"
            )
        cap_alpha = Fraction(str(participant_idle_cap_alpha))
        if cap_alpha < 0 or cap_alpha > 1:
            raise ValueError("participant idle cap alpha must lie in [0, 1]")

        (
            resolved_precedence_encoding,
            resolved_precedence_graph,
            resolved_precedence_mode,
        ) = resolve_precedence_configuration(
            precedence_mode,
            precedence_encoding,
            precedence_graph,
            default_mode="staircase",
        )

        self.inst = inst
        self.precedence_mode = resolved_precedence_mode
        self.precedence_encoding = resolved_precedence_encoding
        self.precedence_graph = resolved_precedence_graph
        self.precedence_configuration = (
            f"{self.precedence_encoding}+{self.precedence_graph}"
        )
        self.encoding_variant = encoding_variant
        self.domain_mode = domain_mode
        self.domain_filter_graph = domain_filter_graph
        self.objective_mode = objective_mode
        self.compact_encoding = compact_encoding
        self.compact_encoding_features = COMPACT_ENCODING_FEATURES[
            compact_encoding
        ]
        self.collision_amo_encoding = collision_amo_encoding
        self.participant_idle_cap_rule = participant_idle_cap_rule
        self.participant_idle_cap_alpha = cap_alpha
        (
            self.participant_idle_lower_bounds,
            self.participant_idle_upper_bounds,
            self.participant_idle_bounds_feasible,
        ) = compute_participant_idle_bounds(inst)
        self.participant_idle_caps = (
            interpolate_participant_idle_caps(
                self.participant_idle_lower_bounds,
                self.participant_idle_upper_bounds,
                cap_alpha,
            )
            if participant_idle_cap_rule == "interpolated_bounds"
            else tuple(self.participant_idle_upper_bounds)
        )
        self.participant_idle_cap_clause_count = 0
        self.collision_amo_cutoff = COLLISION_AMO_COMMANDER_CUTOFF
        self.collision_amo_commander_group_size = (
            COLLISION_AMO_COMMANDER_GROUP_SIZE
        )
        self.objective_participants = tuple(
            participant
            for participant, meeting_count in enumerate(inst.n_meetings_business)
            if meeting_count >= 2
        )
        self.graph = build_precedence_graph(inst.precedences)
        if self.precedence_graph == "direct":
            self._precedence_distances = [
                {pred: 1 for pred in predecessors}
                for predecessors in self.graph.direct_predecessors
            ]
        else:
            self._precedence_distances = [
                dict(distances) for distances in self.graph.longest_distance
            ]
        self._unary_eligible_slots = [
            sorted(original_eligible_slots(inst, meeting))
            for meeting in range(inst.n_meetings)
        ]
        domain_filter_started = time.perf_counter()
        (
            self._reduced_slots,
            reduction_initial_count,
            self.reduced_schedule_candidates,
            domain_filter_stats,
        ) = reduce_domains_with_precedence_profiled(
            inst,
            self.graph,
            domain_filter_graph=self.domain_filter_graph,
        )
        self.domain_filter_seconds = time.perf_counter() - domain_filter_started
        self.domain_filter_iterations = domain_filter_stats.iterations
        self.full_schedule_candidates = inst.n_meetings * inst.n_total_slots
        self.unary_eligible_schedule_candidates = sum(
            len(slots) for slots in self._unary_eligible_slots
        )
        if reduction_initial_count != self.unary_eligible_schedule_candidates:
            raise AssertionError("domain-reduction input disagrees with unary domains")

        # Backward-compatible name: historically this field counted candidates
        # after session/fixed/forbidden filtering, before exact propagation.
        self.initial_schedule_candidates = self.unary_eligible_schedule_candidates
        if domain_mode == "full":
            all_slots = list(range(inst.n_total_slots))
            self._eligible_slots = [list(all_slots) for _ in range(inst.n_meetings)]
        else:
            self._eligible_slots = [list(slots) for slots in self._reduced_slots]
        self.active_schedule_candidates = sum(
            len(slots) for slots in self._eligible_slots
        )

        self.vpool = IDPool()
        self.enabled_constraints: list[str] = []
        self._clusters: list[list[int]] | None = None
        self._artifacts: B2BModelArtifacts | None = None
        self._precedence_sparse_suffixes: dict[int, dict[int, int]] = {}
        self._precedence_pairwise_clauses = 0
        self._precedence_sparse_link_clauses = 0
        self._precedence_unique_suffix_cuts = 0
        self._used_slots_channeled = False
        self._prefix_built: set[int] = set()
        self._suffix_built: set[int] = set()
        self._prefix_states: dict[tuple[int, int], int | None] = {}
        self._suffix_states: dict[tuple[int, int], int | None] = {}
        self._occupancy_alias_count = 0
        self._prefix_alias_count = 0
        self._suffix_alias_count = 0
        self._first_alias_count = 0
        self._shared_counter_state_count = 0
        self._direct_range_soft_clauses: dict[
            str, list[tuple[int, ...]]
        ] = {}
        self._range_max_lits: dict[str, list[int]] = {}
        self._idle_threshold_levels: list[tuple[int, ...]] = [
            tuple() for _ in range(self.inst.n_business)
        ]
        self._idle_threshold_lit_by_level: list[dict[int, int]] = [
            {} for _ in range(self.inst.n_business)
        ]
        self._participant_idle_attainable_values = (
            compute_participant_attainable_idle_values(
                self.inst,
                self._reduced_slots,
            )
            if "attainable_values" in self.compact_encoding_features
            else tuple((0,) for _ in range(self.inst.n_business))
        )
        self._direct_range_soft_weights: dict[str, list[int]] = {}
        self._direct_idle_sum_clauses: list[tuple[int, ...]] = []
        self._range_max_penalty_clauses: dict[
            str, list[tuple[int, ...]]
        ] = {}
        self._range_max_penalty_weights: dict[str, list[int]] = {}
        self._aggregate_or_cache: dict[tuple[int, ...], int | bool] = {}
        self._aggregate_and_cache: dict[tuple[int, ...], int | bool] = {}
        self._objective_aggregate_dense_level_count = 0
        self._objective_aggregate_encoded_level_count = 0
        self._objective_constant_soft_weight = 0
        self._constant_true_lit: int | None = None
        self._collision_amo_pairwise_group_count = 0
        self._collision_amo_commander_group_count = 0
        self._collision_amo_commander_variable_count = 0
        self._collision_amo_clause_count = 0
        self._collision_amo_max_group_size = 0
        self._collision_amo_commander_serial = 0
        self.zero_break_certificate_participant = next(
            (
                participant
                for participant, meetings in enumerate(inst.meetings_by_business)
                if len(meetings) <= 1
            ),
            None,
        )
        self.zero_break_certificate_reason = (
            "participant_requests_at_most_one_meeting"
            if self.zero_break_certificate_participant is not None
            else ""
        )
        self.zero_break_branch = "not_applicable"

        self._schedule_vars: dict[tuple[int, int], int] = {}
        for meeting, slots in enumerate(self._eligible_slots):
            for slot in slots:
                self._schedule_vars[meeting, slot] = self.vpool.id(
                    ("schedule", meeting, slot)
                )

        self._used_vars: dict[tuple[int, int], int] = {}
        for participant, meetings in enumerate(inst.meetings_by_business):
            possible_slots = {
                slot
                for meeting in meetings
                for slot in self._eligible_slots[meeting]
            }
            for slot in sorted(possible_slots):
                scheduled = [
                    lit
                    for meeting in meetings
                    if (lit := self.x_or_none(meeting, slot)) is not None
                ]
                if "demand_driven" in self.compact_encoding_features and len(
                    scheduled
                ) == 1:
                    self._used_vars[participant, slot] = scheduled[0]
                    self._occupancy_alias_count += 1
                else:
                    self._used_vars[participant, slot] = self.vpool.id(
                        ("usedSlot", participant, slot)
                    )

    # Public variable/domain helpers -----------------------------------

    def eligible_slots(self, m: int) -> list[int]:
        """Return slots for which schedule variables exist in the active mode."""

        return list(self._eligible_slots[m])

    def unary_eligible_slots(self, m: int) -> list[int]:
        """Return slots satisfying session, fixed, and forbidden restrictions."""

        return list(self._unary_eligible_slots[m])

    def reduced_slots(self, m: int) -> list[int]:
        """Return the exact preprocessing fixpoint independently of active mode."""

        return list(self._reduced_slots[m])

    def x(self, m: int, t: int) -> int:
        try:
            return self._schedule_vars[m, t]
        except KeyError as exc:
            raise KeyError(
                f"schedule({m},{t}) does not exist in {self.domain_mode} mode"
            ) from exc

    def x_or_none(self, m: int, t: int) -> int | None:
        return self._schedule_vars.get((m, t))

    def used_or_none(self, p: int, t: int) -> int | None:
        return self._used_vars.get((p, t))

    def prefix_used(self, p: int, t: int) -> int:
        return self.vpool.id(("prefixUsed", p, t))

    def suffix_used(self, p: int, t: int) -> int:
        return self.vpool.id(("suffixUsed", p, t))

    def first_used(self, p: int, t: int) -> int:
        return self.vpool.id(("firstUsed", p, t))

    def break_threshold(self, p: int, k: int) -> int:
        return self.vpool.id(("breakSlotsAtLeast", p, k))

    def break_group_end(self, p: int, t: int) -> int:
        return self.vpool.id(("breakGroupEnd", p, t))

    def break_group_threshold(self, p: int, k: int) -> int:
        return self.vpool.id(("breakGroupsAtLeast", p, k))

    def range_max(self, family: str, k: int) -> int:
        return self.vpool.id((family, "rangeMax", k))

    def range_min(self, family: str, k: int) -> int:
        return self.vpool.id((family, "rangeMin", k))

    def range_difference(self, family: str, k: int) -> int:
        return self.vpool.id((family, "rangeDifference", k))

    # Backward-compatible accessors.
    def meeting_before(self, p: int, t: int) -> int:
        if t <= 0:
            raise IndexError("there is no slot strictly before slot 0")
        return self.prefix_used(p, t - 1)

    def meeting_after(self, p: int, t: int) -> int:
        if t >= self.inst.n_total_slots - 1:
            raise IndexError("there is no slot strictly after the final slot")
        return self.suffix_used(p, t + 1)

    def hole(self, p: int, t: int) -> int:
        return self.vpool.id(("legacyBreakSlot", p, t))

    def sorted_hole(self, p: int, k: int) -> int:
        return self.break_threshold(p, k)

    def max_break(self, k: int) -> int:
        return self.vpool.id(("maxBreakSlots", k))

    def min_break(self, k: int) -> int:
        return self.vpool.id(("minBreakSlots", k))

    def dif_break(self, k: int) -> int:
        return self.vpool.id(("difBreakSlots", k))

    def cluster_active(self, c: int, t: int) -> int:
        return self.vpool.id(("clusterActive", c, t))

    @property
    def use_implied_1(self) -> bool:
        return self.encoding_variant in {"imp1", "imp12", "imp12+"}

    @property
    def use_implied_2(self) -> bool:
        return self.encoding_variant in {"imp2", "imp12", "imp12+"}

    @property
    def use_further_improvements(self) -> bool:
        return self.encoding_variant == "imp12+"

    # Cardinality helpers ----------------------------------------------

    @staticmethod
    def _add_pairwise_atmost_one(cnf: CNF, lits: list[int]) -> None:
        for i, left in enumerate(lits):
            for right in lits[i + 1:]:
                cnf.append([-left, -right])

    def _add_exactly_one_commander(
        self,
        cnf: CNF,
        lits: list[int],
        group_size: int = 4,
    ) -> None:
        if not lits:
            cnf.append([])
            return
        if len(lits) == 1:
            cnf.append([lits[0]])
            return
        if len(lits) <= group_size:
            cnf.append(list(lits))
            self._add_pairwise_atmost_one(cnf, lits)
            return

        commanders: list[int] = []
        for start in range(0, len(lits), group_size):
            group = lits[start:start + group_size]
            commander = self.vpool.id(("commander", tuple(group)))
            commanders.append(commander)
            self._add_pairwise_atmost_one(cnf, group)
            for lit in group:
                cnf.append([-lit, commander])
            cnf.append([-commander] + group)
        self._add_exactly_one_commander(cnf, commanders, group_size)

    def _add_atmost_seqcounter(self, cnf: CNF, lits: list[int], bound: int) -> None:
        if bound < 0:
            cnf.append([])
        elif bound == 0:
            cnf.extend([[-lit] for lit in lits])
        elif bound < len(lits):
            encoding = CardEnc.atmost(
                lits=lits,
                bound=bound,
                vpool=self.vpool,
                encoding=EncType.seqcounter,
            )
            cnf.extend(encoding.clauses)

    def _add_exactly_cardnet(self, cnf: CNF, lits: list[int], bound: int) -> None:
        if bound < 0 or bound > len(lits):
            cnf.append([])
        elif bound == 0:
            cnf.extend([[-lit] for lit in lits])
        elif bound == len(lits):
            cnf.extend([[lit] for lit in lits])
        else:
            encoding = CardEnc.equals(
                lits=lits,
                bound=bound,
                vpool=self.vpool,
                encoding=EncType.cardnetwrk,
            )
            cnf.extend(encoding.clauses)

    def _add_atmost_cardnet(self, cnf: CNF, lits: list[int], bound: int) -> None:
        if bound < 0:
            cnf.append([])
        elif bound == 0:
            cnf.extend([[-lit] for lit in lits])
        elif bound < len(lits):
            encoding = CardEnc.atmost(
                lits=lits,
                bound=bound,
                vpool=self.vpool,
                encoding=EncType.cardnetwrk,
            )
            cnf.extend(encoding.clauses)

    # Build entry points ------------------------------------------------

    def build_base_cnf(self) -> B2BModelArtifacts:
        if self._artifacts is not None:
            return self._artifacts

        cnf = CNF()
        filter_label = (
            "direct E"
            if self.domain_filter_graph == "direct"
            else "distance-labelled E*"
        )
        objective_policy = (
            "objective-only optimization: no hard upper bound on objective gap"
            if self.objective_mode == "ir"
            else f"journal objective family: {self.objective_mode}"
        )
        self.enabled_constraints = [
            objective_policy,
            f"compact objective encoding preset: {self.compact_encoding}",
            f"participant collision AMO: {self.collision_amo_encoding}",
            f"F-selected {filter_label} domain propagation and cycle detection",
            "precedence configuration: "
            f"F={self.domain_filter_graph}, "
            f"P={self.precedence_encoding}, G={self.precedence_graph}",
        ]
        if self.domain_mode == "full":
            self.enabled_constraints.append(
                "Full Domain MxT schedule variables + explicit unary exclusions"
            )
        else:
            self.enabled_constraints.append(
                "Reduced Domain variables after unary filtering + matching GAC + "
                "slot saturation"
            )

        if self.graph.cycle_nodes:
            cnf.append([])
            self.enabled_constraints.append("strict precedence cycle -> UNSAT")

        self._add_assignment(cnf)
        self._add_participant_collision(cnf)
        if self.use_further_improvements:
            self._add_cluster_capacity(cnf)
        else:
            self._add_capacity_over_meetings(cnf)
        self._add_precedences(cnf)

        (
            idle_threshold_lits,
            idle_range_lits,
            break_group_end_lits,
            break_group_threshold_lits,
            break_group_range_lits,
            objective_tiers,
            objective_name,
        ) = self._build_objective_family(cnf)

        n_vars = max(self.vpool.top, cnf.nv)
        n_primary_variables = len(self._schedule_vars)
        clause_lengths = [len(clause) for clause in cnf.clauses]

        self._artifacts = B2BModelArtifacts(
            cnf=cnf,
            objective_lits=list(objective_tiers[0].literals),
            objective_name=objective_name,
            objective_mode=self.objective_mode,
            objective_tiers=objective_tiers,
            objective_participants=self.objective_participants,
            objective_gap_lits=idle_range_lits,
            idle_threshold_lits_by_participant=idle_threshold_lits,
            break_group_end_lits_by_participant=break_group_end_lits,
            break_group_threshold_lits_by_participant=(
                break_group_threshold_lits
            ),
            break_group_range_lits=break_group_range_lits,
            hole_lits_by_participant=[[] for _ in range(self.inst.n_business)],
            sorted_hole_lits_by_participant=idle_threshold_lits,
            n_vars=n_vars,
            n_clauses=len(cnf.clauses),
            n_primary_variables=n_primary_variables,
            n_auxiliary_variables=n_vars - n_primary_variables,
            n_hard_literals=sum(clause_lengths),
            max_hard_clause_length=max(clause_lengths, default=0),
            n_unit_hard_clauses=sum(length == 1 for length in clause_lengths),
            n_binary_hard_clauses=sum(length == 2 for length in clause_lengths),
            n_ternary_hard_clauses=sum(length == 3 for length in clause_lengths),
            n_long_hard_clauses=sum(length >= 4 for length in clause_lengths),
            encoding_variant=self.encoding_variant,
            precedence_mode=self.precedence_mode,
            precedence_encoding=self.precedence_encoding,
            precedence_graph=self.precedence_graph,
            precedence_configuration=self.precedence_configuration,
            domain_mode=self.domain_mode,
            domain_filter_graph=self.domain_filter_graph,
            domain_filter_iterations=self.domain_filter_iterations,
            domain_filter_seconds=self.domain_filter_seconds,
            enabled_constraints=list(self.enabled_constraints),
            full_schedule_candidates=self.full_schedule_candidates,
            unary_eligible_schedule_candidates=(
                self.unary_eligible_schedule_candidates
            ),
            initial_schedule_candidates=self.initial_schedule_candidates,
            reduced_schedule_candidates=self.reduced_schedule_candidates,
            active_schedule_candidates=self.active_schedule_candidates,
            unary_removed_schedule_candidates=(
                self.full_schedule_candidates
                - self.unary_eligible_schedule_candidates
            ),
            preprocessing_removed_schedule_candidates=(
                self.unary_eligible_schedule_candidates
                - self.reduced_schedule_candidates
            ),
            removed_schedule_candidates=(
                self.initial_schedule_candidates - self.reduced_schedule_candidates
            ),
            precedence_direct_edges=self.graph.direct_edge_count,
            precedence_transitive_edges=self.graph.transitive_edge_count,
            precedence_cycle_nodes=self.graph.cycle_nodes,
            precedence_max_distance=self.graph.max_chain_distance,
            precedence_relation_edges=sum(
                len(distances) for distances in self._precedence_distances
            ),
            precedence_pairwise_clauses=self._precedence_pairwise_clauses,
            precedence_sparse_link_clauses=(
                self._precedence_sparse_link_clauses
            ),
            precedence_unique_suffix_cuts=(
                self._precedence_unique_suffix_cuts
            ),
            objective_encoding={
                "ir": "linear first/last span with exact unary thresholds",
                "ir_is": "exact_idle_span_threshold_range_then_idle_sum",
                "ir_im_is": (
                    "exact_idle_span_threshold_range_then_maximum_then_sum"
                ),
                "ir_im_isq": (
                    "exact_idle_span_threshold_range_then_maximum_then_squared_sum"
                ),
                "is": "exact_idle_span_threshold_sum",
                "isq": "exact_idle_span_threshold_odd_weights",
                "im_is": "exact_idle_maximum_threshold_then_sum",
                "bg_d2": "exact_break_group_threshold_range_cap_d2",
                "bg_dinf": "exact_break_group_sum_without_homogeneity",
                "bg_ir_is": (
                    "exact_break_group_sum_then_idle_range_then_idle_sum"
                ),
            }[self.objective_mode]
            + f";compact={self.compact_encoding};bg_branch={self.zero_break_branch}",
            compact_encoding=self.compact_encoding,
            compact_encoding_features=tuple(
                sorted(self.compact_encoding_features)
            ),
            zero_break_certificate_participant=(
                self.zero_break_certificate_participant
            ),
            zero_break_certificate_reason=self.zero_break_certificate_reason,
            zero_break_branch=self.zero_break_branch,
            occupancy_alias_count=self._occupancy_alias_count,
            prefix_alias_count=self._prefix_alias_count,
            suffix_alias_count=self._suffix_alias_count,
            first_alias_count=self._first_alias_count,
            shared_counter_state_count=self._shared_counter_state_count,
            direct_range_soft_clause_count=sum(
                len(clauses)
                for clauses in self._direct_range_soft_clauses.values()
            ),
            collision_amo_encoding=self.collision_amo_encoding,
            collision_amo_cutoff=self.collision_amo_cutoff,
            collision_amo_commander_group_size=(
                self.collision_amo_commander_group_size
            ),
            collision_amo_pairwise_group_count=(
                self._collision_amo_pairwise_group_count
            ),
            collision_amo_commander_group_count=(
                self._collision_amo_commander_group_count
            ),
            collision_amo_commander_variable_count=(
                self._collision_amo_commander_variable_count
            ),
            collision_amo_clause_count=self._collision_amo_clause_count,
            collision_amo_max_group_size=self._collision_amo_max_group_size,
            participant_idle_cap_rule=self.participant_idle_cap_rule,
            participant_idle_cap_alpha=(
                f"{self.participant_idle_cap_alpha.numerator}/"
                f"{self.participant_idle_cap_alpha.denominator}"
            ),
            participant_idle_lower_bounds=self.participant_idle_lower_bounds,
            participant_idle_upper_bounds=self.participant_idle_upper_bounds,
            participant_idle_caps=self.participant_idle_caps,
            participant_idle_bounds_feasible=(
                self.participant_idle_bounds_feasible
            ),
            participant_idle_cap_clause_count=(
                self.participant_idle_cap_clause_count
            ),
            participant_idle_attainable_values=(
                self._participant_idle_attainable_values
            ),
            idle_threshold_dense_level_count=sum(
                self._participant_idle_attainable_values[participant][-1]
                for participant in self.objective_participants
            ),
            idle_threshold_encoded_level_count=sum(
                len(self._idle_threshold_levels[participant])
                for participant in self.objective_participants
            ),
            idle_threshold_removed_level_count=sum(
                self._participant_idle_attainable_values[participant][-1]
                - len(self._idle_threshold_levels[participant])
                for participant in self.objective_participants
            ),
            objective_aggregate_dense_level_count=(
                self._objective_aggregate_dense_level_count
            ),
            objective_aggregate_encoded_level_count=(
                self._objective_aggregate_encoded_level_count
            ),
            objective_constant_soft_weight=(
                self._objective_constant_soft_weight
            ),
        )
        return self._artifacts

    def build_wcnf(self) -> WCNF:
        """Build exact weighted MaxSAT for the selected objective family."""

        artifacts = self.build_base_cnf()
        wcnf = WCNF()
        for clause in artifacts.cnf.clauses:
            wcnf.append(clause)
        for tier in artifacts.objective_tiers:
            for clause, weight in zip(tier.maxsat_clauses, tier.maxsat_weights):
                wcnf.append(list(clause), weight=tier.scalar_weight * weight)
        return wcnf

    # Feasibility -------------------------------------------------------

    def _add_assignment(self, cnf: CNF) -> None:
        self.enabled_constraints.append(
            f"(20),(22)-(27) exactly once over {self.domain_mode} domains"
        )
        for meeting, slots in enumerate(self._eligible_slots):
            self._add_exactly_one_commander(
                cnf, [self.x(meeting, slot) for slot in slots]
            )

        if self.domain_mode == "full":
            self.enabled_constraints.append(
                "(22)-(27) session/fixed/forbidden exclusions as hard unit clauses"
            )
            for meeting, unary_slots in enumerate(self._unary_eligible_slots):
                allowed = set(unary_slots)
                for slot in range(self.inst.n_total_slots):
                    if slot not in allowed:
                        cnf.append([-self.x(meeting, slot)])

    def _add_participant_collision(self, cnf: CNF) -> None:
        self.enabled_constraints.append(
            "(19) participant atMost-one per slot; "
            f"AMO={self.collision_amo_encoding}, "
            f"commander_cutoff={self.collision_amo_cutoff}, "
            f"commander_group_size={self.collision_amo_commander_group_size}"
        )
        for meetings in self.inst.meetings_by_business:
            for slot in range(self.inst.n_total_slots):
                lits = [
                    lit
                    for meeting in meetings
                    if (lit := self.x_or_none(meeting, slot)) is not None
                ]
                if len(lits) > 1:
                    self._collision_amo_max_group_size = max(
                        self._collision_amo_max_group_size,
                        len(lits),
                    )
                    before = len(cnf.clauses)
                    if (
                        self.collision_amo_encoding == "adaptive_commander"
                        and len(lits) >= self.collision_amo_cutoff
                    ):
                        self._add_commander_atmost_one(cnf, lits)
                        self._collision_amo_commander_group_count += 1
                    else:
                        self._add_pairwise_atmost_one(cnf, lits)
                        self._collision_amo_pairwise_group_count += 1
                    self._collision_amo_clause_count += (
                        len(cnf.clauses) - before
                    )

    def _add_commander_atmost_one(
        self,
        cnf: CNF,
        lits: list[int],
    ) -> None:
        """Add an equisatisfiable commander AMO with groups of four.

        A true input implies its group commander.  Pairwise AMO inside every
        group and recursive AMO over the commanders then forbid two true
        inputs.  The reverse commander-to-input implication is deliberately
        unnecessary for an at-most-one constraint.
        """

        if len(lits) <= self.collision_amo_commander_group_size:
            self._add_pairwise_atmost_one(cnf, lits)
            return

        commanders: list[int] = []
        for start in range(
            0,
            len(lits),
            self.collision_amo_commander_group_size,
        ):
            group = lits[
                start:start + self.collision_amo_commander_group_size
            ]
            self._add_pairwise_atmost_one(cnf, group)
            self._collision_amo_commander_serial += 1
            commander = self.vpool.id(
                (
                    "collisionAMOCommander",
                    self._collision_amo_commander_serial,
                )
            )
            self._collision_amo_commander_variable_count += 1
            commanders.append(commander)
            for lit in group:
                cnf.append([-lit, commander])

        self._add_commander_atmost_one(cnf, commanders)

    def _add_capacity_over_meetings(self, cnf: CNF) -> None:
        self.enabled_constraints.append(
            f"(21) capacity over {self.domain_mode} schedule variables"
        )
        for slot in range(self.inst.n_total_slots):
            lits = [
                lit
                for meeting in range(self.inst.n_meetings)
                if (lit := self.x_or_none(meeting, slot)) is not None
            ]
            self._add_atmost_seqcounter(cnf, lits, self.inst.n_tables)

    def _compute_meeting_clusters(self) -> list[list[int]]:
        if self._clusters is not None:
            return self._clusters

        unassigned = set(range(self.inst.n_meetings))
        clusters: list[list[int]] = []
        while unassigned:
            best: list[int] = []
            for meetings in self.inst.meetings_by_business:
                candidate = sorted(unassigned.intersection(meetings))
                if len(candidate) > len(best):
                    best = candidate
            if not best:
                best = [min(unassigned)]
            clusters.append(best)
            unassigned.difference_update(best)
        self._clusters = clusters
        return clusters

    def _add_cluster_capacity(self, cnf: CNF) -> None:
        self.enabled_constraints.append(
            "(46),(47) clustered table capacity with compact forward channeling"
        )
        clusters = self._compute_meeting_clusters()

        for slot in range(self.inst.n_total_slots):
            active_clusters: list[int] = []
            for cluster, meetings in enumerate(clusters):
                member_lits = [
                    lit
                    for meeting in meetings
                    if (lit := self.x_or_none(meeting, slot)) is not None
                ]
                if not member_lits:
                    continue
                if len(member_lits) == 1:
                    active_clusters.append(member_lits[0])
                    continue

                cluster_lit = self.cluster_active(cluster, slot)
                active_clusters.append(cluster_lit)
                for lit in member_lits:
                    cnf.append([-lit, cluster_lit])
                # The reverse long clause is intentionally omitted. Forward
                # channeling is sufficient for an at-most capacity constraint.

            self._add_atmost_seqcounter(cnf, active_clusters, self.inst.n_tables)

    # Precedence --------------------------------------------------------

    def _build_sparse_precedence_suffixes(
        self,
        cnf: CNF,
        meeting: int,
        cuts: set[int],
    ) -> dict[int, int]:
        """Build exact suffix ORs only at cuts queried by the selected graph."""

        cached = self._precedence_sparse_suffixes.get(meeting)
        if cached is not None:
            return cached

        slots = self._eligible_slots[meeting]
        valid_cuts = sorted({cut for cut in cuts if 0 <= cut < len(slots)})
        suffixes: dict[int, int] = {}
        next_cut = len(slots)
        next_lit: int | None = None

        for cut in reversed(valid_cuts):
            segment = [self.x(meeting, slots[i]) for i in range(cut, next_cut)]
            if next_lit is None and len(segment) == 1:
                here = segment[0]
            else:
                here = self.vpool.id(("precedenceSparseSuffix", meeting, cut))
                for lit in segment:
                    cnf.append([-lit, here])
                if next_lit is not None:
                    cnf.append([-next_lit, here])
                reverse = [-here] + segment
                if next_lit is not None:
                    reverse.append(next_lit)
                cnf.append(reverse)
            suffixes[cut] = here
            next_cut = cut
            next_lit = here

        self._precedence_sparse_suffixes[meeting] = suffixes
        return suffixes

    def _add_sparse_suffix_precedences(self, cnf: CNF) -> None:
        self.enabled_constraints.append(
            "(28) SparseSuffix precedence over "
            f"{self.precedence_graph} distance-labelled relations"
        )

        links: list[tuple[int, int, int]] = []
        cuts_by_pred: dict[int, set[int]] = {}

        for post, distances in enumerate(self._precedence_distances):
            post_slots = self._eligible_slots[post]
            for pred, distance in sorted(distances.items()):
                pred_slots = self._eligible_slots[pred]
                if not pred_slots or not post_slots:
                    continue

                for post_slot in post_slots:
                    # pred + distance <= post_slot, hence pred <= post_slot-distance.
                    split = bisect_right(pred_slots, post_slot - distance)
                    post_lit = self.x(post, post_slot)
                    if split == 0:
                        cnf.append([-post_lit])
                        self._precedence_sparse_link_clauses += 1
                    elif split < len(pred_slots):
                        cuts_by_pred.setdefault(pred, set()).add(split)
                        links.append((post_lit, pred, split))

        self._precedence_unique_suffix_cuts = sum(
            len(cuts) for cuts in cuts_by_pred.values()
        )
        for pred, cuts in cuts_by_pred.items():
            self._build_sparse_precedence_suffixes(cnf, pred, cuts)

        for post_lit, pred, split in links:
            cnf.append([
                -post_lit,
                -self._precedence_sparse_suffixes[pred][split],
            ])
            self._precedence_sparse_link_clauses += 1

    def _add_pairwise_precedences(self, cnf: CNF) -> None:
        self.enabled_constraints.append(
            "(28) Pairwise precedence over "
            f"{self.precedence_graph} distance-labelled relations"
        )
        for post, distances in enumerate(self._precedence_distances):
            for pred, distance in sorted(distances.items()):
                for pred_slot in self._eligible_slots[pred]:
                    pred_lit = self.x(pred, pred_slot)
                    for post_slot in self._eligible_slots[post]:
                        if pred_slot + distance > post_slot:
                            cnf.append([-pred_lit, -self.x(post, post_slot)])
                            self._precedence_pairwise_clauses += 1

    def _add_precedences(self, cnf: CNF) -> None:
        if self.precedence_encoding == "pairwise":
            self._add_pairwise_precedences(cnf)
            return
        self._add_sparse_suffix_precedences(cnf)

    # Used-slot channeling and span objective --------------------------

    @staticmethod
    def _add_equiv_or(cnf: CNF, out: int, left: int, right: int) -> None:
        cnf.append([-left, out])
        cnf.append([-right, out])
        cnf.append([left, right, -out])

    @staticmethod
    def _add_equiv(cnf: CNF, left: int, right: int) -> None:
        cnf.append([-left, right])
        cnf.append([left, -right])

    def _channel_used_slots(self, cnf: CNF) -> None:
        if self._used_slots_channeled:
            return
        self._used_slots_channeled = True
        self.enabled_constraints.append("exact schedule <-> usedSlot channeling")
        for participant, meetings in enumerate(self.inst.meetings_by_business):
            for slot in range(self.inst.n_total_slots):
                used = self.used_or_none(participant, slot)
                if used is None:
                    continue
                scheduled = [
                    lit
                    for meeting in meetings
                    if (lit := self.x_or_none(meeting, slot)) is not None
                ]
                if len(scheduled) == 1 and used == scheduled[0]:
                    continue
                for lit in scheduled:
                    cnf.append([-lit, used])
                cnf.append([-used] + scheduled)

            if self.use_implied_1:
                self._add_implied_constraint_1(cnf, participant)

        if self.use_implied_2:
            self._add_implied_constraint_2(cnf)

    def _build_prefix_suffix(
        self,
        cnf: CNF,
        participant: int,
        *,
        need_prefix: bool = True,
        need_suffix: bool = True,
    ) -> None:
        total_slots = self.inst.n_total_slots
        if total_slots == 0:
            return

        demand_driven = "demand_driven" in self.compact_encoding_features
        if need_prefix and participant not in self._prefix_built:
            self._prefix_built.add(participant)
            previous: int | None = None
            for slot in range(total_slots):
                used = self.used_or_none(participant, slot)
                if demand_driven:
                    if used is None:
                        current = previous
                        if current is not None:
                            self._prefix_alias_count += 1
                    elif previous is None:
                        current = used
                        self._prefix_alias_count += 1
                    else:
                        current = self.prefix_used(participant, slot)
                        self._add_equiv_or(cnf, current, previous, used)
                    self._prefix_states[participant, slot] = current
                    previous = current
                    continue

                current = self.prefix_used(participant, slot)
                self._prefix_states[participant, slot] = current
                if slot == 0:
                    if used is None:
                        cnf.append([-current])
                    else:
                        self._add_equiv(cnf, current, used)
                else:
                    assert previous is not None
                    if used is None:
                        self._add_equiv(cnf, current, previous)
                    else:
                        self._add_equiv_or(cnf, current, previous, used)
                previous = current

        if need_suffix and participant not in self._suffix_built:
            self._suffix_built.add(participant)
            following: int | None = None
            for slot in range(total_slots - 1, -1, -1):
                used = self.used_or_none(participant, slot)
                if demand_driven:
                    if used is None:
                        current = following
                        if current is not None:
                            self._suffix_alias_count += 1
                    elif following is None:
                        current = used
                        self._suffix_alias_count += 1
                    else:
                        current = self.suffix_used(participant, slot)
                        self._add_equiv_or(cnf, current, used, following)
                    self._suffix_states[participant, slot] = current
                    following = current
                    continue

                current = self.suffix_used(participant, slot)
                self._suffix_states[participant, slot] = current
                if slot == total_slots - 1:
                    if used is None:
                        cnf.append([-current])
                    else:
                        self._add_equiv(cnf, current, used)
                else:
                    assert following is not None
                    if used is None:
                        self._add_equiv(cnf, current, following)
                    else:
                        self._add_equiv_or(cnf, current, used, following)
                following = current

    def _prefix_state(self, participant: int, slot: int) -> int | None:
        if slot < 0:
            return None
        return self._prefix_states.get((participant, slot))

    def _suffix_state(self, participant: int, slot: int) -> int | None:
        if slot >= self.inst.n_total_slots:
            return None
        return self._suffix_states.get((participant, slot))

    def _participant_span_upper_bound(self, participant: int) -> int:
        meetings = self.inst.n_meetings_business[participant]
        possible = sorted(
            slot
            for (p, slot), _ in self._used_vars.items()
            if p == participant
        )
        if meetings <= 1 or not possible:
            return 0
        return max(0, possible[-1] - possible[0] + 1 - meetings)

    def _objective_true_literal(self, cnf: CNF) -> int:
        """Return one shared literal fixed to true for constant soft costs."""

        if self._constant_true_lit is None:
            self._constant_true_lit = self.vpool.id(("objectiveConstantTrue",))
            cnf.append([self._constant_true_lit])
        return self._constant_true_lit

    def _idle_indicator_at_level(
        self,
        participant: int,
        level: int,
    ) -> int | bool:
        """Represent ``I_p >= level`` by a constant or retained threshold."""

        values = self._participant_idle_attainable_values[participant]
        if level <= values[0]:
            return True
        if level > values[-1]:
            return False
        index = bisect_right(values, level - 1)
        retained_level = values[index]
        return self._idle_threshold_lit_by_level[participant][retained_level]

    def _aggregate_indicator(
        self,
        cnf: CNF,
        signature: tuple[int | bool, ...],
        *,
        kind: str,
    ) -> int | bool:
        """Build an exact OR/AND of threshold indicators with constant folding."""

        if kind not in {"or", "and"}:
            raise ValueError(f"unknown aggregate kind={kind!r}")
        if kind == "or":
            if any(value is True for value in signature):
                return True
            literals = tuple(
                sorted({int(value) for value in signature if value is not False})
            )
            if not literals:
                return False
            if len(literals) == 1:
                return literals[0]
            cache = self._aggregate_or_cache
        else:
            if any(value is False for value in signature):
                return False
            literals = tuple(
                sorted({int(value) for value in signature if value is not True})
            )
            if not literals:
                return True
            if len(literals) == 1:
                return literals[0]
            cache = self._aggregate_and_cache

        cached = cache.get(literals)
        if cached is not None:
            return cached
        output = self.vpool.id(("idleAggregate", kind, literals))
        if kind == "or":
            for literal in literals:
                cnf.append([-literal, output])
            cnf.append([-output, *literals])
        else:
            for literal in literals:
                cnf.append([-output, literal])
            cnf.append([output, *[-literal for literal in literals]])
        cache[literals] = output
        return output

    def _penalty_for_indicator(
        self,
        cnf: CNF,
        indicator: int | bool,
        weight: int,
    ) -> tuple[tuple[int, ...], int] | None:
        """Return a soft clause whose violation charges a true indicator."""

        if weight <= 0 or indicator is False:
            return None
        if indicator is True:
            self._objective_constant_soft_weight += weight
            return ((-self._objective_true_literal(cnf),), weight)
        return ((-int(indicator),), weight)

    def _idle_cost_penalties(
        self,
        cnf: CNF,
        *,
        squared: bool,
    ) -> tuple[tuple[tuple[int, ...], ...], tuple[int, ...], int]:
        """Compile total or squared waiting from compressed threshold jumps."""

        penalties: list[tuple[int, ...]] = []
        weights: list[int] = []
        upper_bound = 0
        constant = 0
        for participant in self.objective_participants:
            values = self._participant_idle_attainable_values[participant]
            upper_bound += values[-1] ** 2 if squared else values[-1]
            constant += values[0] ** 2 if squared else values[0]
            for previous, level in zip(values, values[1:]):
                literal = self._idle_threshold_lit_by_level[participant][level]
                weight = (
                    level * level - previous * previous
                    if squared
                    else level - previous
                )
                penalties.append((-literal,))
                weights.append(weight)
        if constant:
            self._objective_constant_soft_weight += constant
            penalties.insert(0, (-self._objective_true_literal(cnf),))
            weights.insert(0, constant)
        return tuple(penalties), tuple(weights), upper_bound

    def _compressed_idle_extremes(
        self,
        cnf: CNF,
        *,
        include_range: bool,
        family: str = "idle_slots",
    ) -> tuple[
        tuple[tuple[int, ...], ...],
        tuple[int, ...],
        tuple[tuple[int, ...], ...],
        tuple[int, ...],
    ]:
        """Compile maximum and, optionally, range over attainable levels."""

        maximum_upper = max(
            (
                self._participant_idle_attainable_values[participant][-1]
                for participant in self.objective_participants
            ),
            default=0,
        )
        self._objective_aggregate_dense_level_count = max(
            self._objective_aggregate_dense_level_count,
            maximum_upper,
        )
        if maximum_upper == 0 or not self.objective_participants:
            return (), (), (), ()

        runs: list[tuple[tuple[int | bool, ...], int]] = []
        previous_signature: tuple[int | bool, ...] | None = None
        run_weight = 0
        for level in range(1, maximum_upper + 1):
            signature = tuple(
                self._idle_indicator_at_level(participant, level)
                for participant in self.objective_participants
            )
            if signature == previous_signature:
                run_weight += 1
            else:
                if previous_signature is not None:
                    runs.append((previous_signature, run_weight))
                previous_signature = signature
                run_weight = 1
        assert previous_signature is not None
        runs.append((previous_signature, run_weight))
        self._objective_aggregate_encoded_level_count = max(
            self._objective_aggregate_encoded_level_count,
            len(runs),
        )

        maximum_clauses: list[tuple[int, ...]] = []
        maximum_weights: list[int] = []
        range_clauses: list[tuple[int, ...]] = []
        range_weights: list[int] = []

        for signature, weight in runs:
            maximum = self._aggregate_indicator(cnf, signature, kind="or")
            maximum_penalty = self._penalty_for_indicator(cnf, maximum, weight)
            if maximum_penalty is not None:
                clause, penalty_weight = maximum_penalty
                maximum_clauses.append(clause)
                maximum_weights.append(penalty_weight)

            if not include_range:
                continue
            minimum = self._aggregate_indicator(cnf, signature, kind="and")
            same_indicator = (
                isinstance(maximum, int)
                and not isinstance(maximum, bool)
                and isinstance(minimum, int)
                and not isinstance(minimum, bool)
                and maximum == minimum
            ) or (
                isinstance(maximum, bool)
                and isinstance(minimum, bool)
                and maximum is minimum
            )
            if maximum is False or minimum is True or same_indicator:
                continue
            if maximum is True and minimum is False:
                self._objective_constant_soft_weight += weight
                clause = (-self._objective_true_literal(cnf),)
            elif maximum is True:
                clause = (int(minimum),)
            elif minimum is False:
                clause = (-int(maximum),)
            else:
                clause = (-int(maximum), int(minimum))
            range_clauses.append(clause)
            range_weights.append(weight)

        self._range_max_penalty_clauses[family] = list(maximum_clauses)
        self._range_max_penalty_weights[family] = list(maximum_weights)
        if include_range:
            self._direct_range_soft_clauses[family] = list(range_clauses)
            self._direct_range_soft_weights[family] = list(range_weights)
        return (
            tuple(maximum_clauses),
            tuple(maximum_weights),
            tuple(range_clauses),
            tuple(range_weights),
        )

    def _add_span_break_thresholds(self, cnf: CNF) -> list[list[int]]:
        """Encode ``B(p)>=k`` directly for objective participants in P*."""

        self.enabled_constraints.append(
            "linear P* first/last span encoding: B(p)=last-first+1-|Mp|"
        )
        self._channel_used_slots(cnf)
        thresholds_by_participant: list[list[int]] = []
        profiles = list(self._participant_idle_attainable_values)
        objective_participants = set(self.objective_participants)

        for participant in range(self.inst.n_business):
            meetings = self.inst.n_meetings_business[participant]
            possible_slots = [
                slot
                for slot in range(self.inst.n_total_slots)
                if self.used_or_none(participant, slot) is not None
            ]
            # Participants outside P* have at most one meeting, hence B(p)=0.
            # Skip their prefix/suffix variables entirely to keep the encoding compact.
            if participant not in objective_participants or not possible_slots:
                thresholds_by_participant.append([])
                profiles[participant] = (0,)
                continue

            self._build_prefix_suffix(
                cnf,
                participant,
                need_prefix=True,
                need_suffix=True,
            )
            first_lits: dict[int, int] = {}
            for slot in possible_slots:
                used = self.used_or_none(participant, slot)
                assert used is not None
                previous = self._prefix_state(participant, slot - 1)
                if (
                    "demand_driven" in self.compact_encoding_features
                    and previous is None
                ):
                    first = used
                    self._first_alias_count += 1
                else:
                    first = self.first_used(participant, slot)
                    if previous is None:
                        self._add_equiv(cnf, first, used)
                    else:
                        # first <-> used AND NOT previous-prefix.
                        cnf.append([-first, used])
                        cnf.append([-first, -previous])
                        cnf.append([-used, previous, first])
                first_lits[slot] = first

            upper = self._participant_span_upper_bound(participant)
            if "attainable_values" in self.compact_encoding_features:
                values = profiles[participant]
                levels = values[1:]
            else:
                values = tuple(range(upper + 1))
                profiles[participant] = values
                levels = values[1:]
            thresholds: list[int] = []
            for amount in levels:
                threshold = self.break_threshold(participant, amount)
                thresholds.append(threshold)
                for first_slot, first in first_lits.items():
                    target = first_slot + meetings + amount - 1
                    if target >= self.inst.n_total_slots:
                        cnf.append([-first, -threshold])
                        continue
                    suffix = self._suffix_state(participant, target)
                    if suffix is None:
                        cnf.append([-first, -threshold])
                        continue
                    # first -> (threshold <-> suffix[target]).
                    cnf.append([-first, -threshold, suffix])
                    cnf.append([-first, threshold, -suffix])

            for index in range(1, len(thresholds)):
                cnf.append([-thresholds[index], thresholds[index - 1]])
            self._idle_threshold_levels[participant] = tuple(levels)
            self._idle_threshold_lit_by_level[participant] = dict(
                zip(levels, thresholds)
            )
            thresholds_by_participant.append(thresholds)

        self._participant_idle_attainable_values = tuple(profiles)
        return thresholds_by_participant

    def _add_direct_idle_sum_cost(self, cnf: CNF) -> None:
        """Create one soft clause for each possible internal idle slot.

        For participant ``p`` and slot ``t``, the clause is violated exactly
        when ``p`` has an earlier meeting, no meeting at ``t``, and a later
        meeting.  This is the idle-slot definition itself, so the total number
        of violated clauses is the total internal waiting time.  No unary
        objective thresholds or first-slot variables are required.
        """

        self.enabled_constraints.append(
            "direct soft clauses for total internal idle slots"
        )
        self._channel_used_slots(cnf)
        for participant in self.objective_participants:
            self._build_prefix_suffix(
                cnf,
                participant,
                need_prefix=True,
                need_suffix=True,
            )
            for slot in range(1, self.inst.n_total_slots - 1):
                prefix = self._prefix_state(participant, slot - 1)
                suffix = self._suffix_state(participant, slot + 1)
                if prefix is None or suffix is None:
                    continue
                used = self.used_or_none(participant, slot)
                clause = (
                    (-prefix, -suffix)
                    if used is None
                    else (-prefix, used, -suffix)
                )
                self._direct_idle_sum_clauses.append(clause)

    def _add_exact_cardinality_thresholds(
        self,
        cnf: CNF,
        literals: list[int],
        *,
        participant: int,
        family: str,
        upper_bound: int,
    ) -> list[int]:
        """Encode exact unary literals ``[sum(literals) >= k]``."""

        thresholds: list[int] = []
        for amount in range(1, min(upper_bound, len(literals)) + 1):
            if family != "break_groups":
                raise ValueError(f"Unsupported threshold family={family!r}")
            threshold = self.break_group_threshold(participant, amount)
            thresholds.append(threshold)

            at_least = CardEnc.atleast(
                lits=literals,
                bound=amount,
                vpool=self.vpool,
                encoding=EncType.seqcounter,
            )
            for clause in at_least.clauses:
                cnf.append([-threshold, *clause])

            at_most = CardEnc.atmost(
                lits=literals,
                bound=amount - 1,
                vpool=self.vpool,
                encoding=EncType.seqcounter,
            )
            for clause in at_most.clauses:
                cnf.append([threshold, *clause])

        for index in range(1, len(thresholds)):
            cnf.append([-thresholds[index], thresholds[index - 1]])
        return thresholds

    def _add_shared_exact_cardinality_thresholds(
        self,
        cnf: CNF,
        literals: list[int],
        *,
        participant: int,
        upper_bound: int,
    ) -> list[int]:
        """Encode every exact ``sum(literals) >= k`` output in one DP."""

        if upper_bound <= 0 or not literals:
            return []
        bound = min(upper_bound, len(literals))
        previous: dict[int, int] = {}
        for index, literal in enumerate(literals, start=1):
            current: dict[int, int] = {}
            for amount in range(1, min(index, bound) + 1):
                state = self.vpool.id(
                    ("sharedBreakCounter", participant, index, amount)
                )
                self._shared_counter_state_count += 1
                same_amount = previous.get(amount)  # false when absent
                if amount == 1:
                    # state <-> same_amount OR literal
                    if same_amount is not None:
                        cnf.append([-same_amount, state])
                        cnf.append([-literal, state])
                        cnf.append([-state, same_amount, literal])
                    else:
                        cnf.append([-literal, state])
                        cnf.append([-state, literal])
                else:
                    one_less = previous[amount - 1]
                    # state <-> same_amount OR (literal AND one_less)
                    if same_amount is not None:
                        cnf.append([-same_amount, state])
                    cnf.append([-literal, -one_less, state])
                    cnf.append(
                        [-state, literal]
                        if same_amount is None
                        else [-state, same_amount, literal]
                    )
                    cnf.append(
                        [-state, one_less]
                        if same_amount is None
                        else [-state, same_amount, one_less]
                    )
                current[amount] = state
            previous = current

        return [previous[amount] for amount in range(1, bound + 1)]

    def _add_break_group_thresholds(
        self,
        cnf: CNF,
        *,
        include_thresholds: bool = True,
    ) -> tuple[list[list[int]], list[list[int]]]:
        """Encode exact maximal internal idle-block counts for every participant."""

        self.enabled_constraints.append(
            "exact break-group ends"
            + (" and unary break-group thresholds" if include_thresholds else "")
        )
        self._channel_used_slots(cnf)
        ends_by_participant: list[list[int]] = []
        thresholds_by_participant: list[list[int]] = []

        for participant, meetings in enumerate(self.inst.meetings_by_business):
            if len(meetings) < 2:
                ends_by_participant.append([])
                thresholds_by_participant.append([])
                continue

            self._build_prefix_suffix(
                cnf,
                participant,
                need_prefix=True,
                # Preserve the published reference encoding exactly.  Removing
                # the unused suffix chain is deliberately isolated as part of
                # the demand-driven compact factor.
                need_suffix=(
                    "demand_driven" not in self.compact_encoding_features
                ),
            )
            possible = {
                slot
                for slot in range(self.inst.n_total_slots)
                if self.used_or_none(participant, slot) is not None
            }
            ends: list[int] = []
            for slot in range(1, self.inst.n_total_slots - 1):
                next_used = self.used_or_none(participant, slot + 1)
                if next_used is None or not any(prior < slot for prior in possible):
                    continue
                end = self.break_group_end(participant, slot)
                current_used = self.used_or_none(participant, slot)
                prefix = self._prefix_state(participant, slot - 1)
                if prefix is None:
                    raise AssertionError(
                        "break-end candidate has no earlier prefix support"
                    )

                # end <-> next_used AND NOT current_used AND prefix.
                cnf.append([-end, next_used])
                if current_used is not None:
                    cnf.append([-end, -current_used])
                cnf.append([-end, prefix])
                reverse = [-next_used, -prefix, end]
                if current_used is not None:
                    reverse.insert(1, current_used)
                cnf.append(reverse)
                ends.append(end)

            thresholds: list[int] = []
            if include_thresholds:
                if "shared_counter" in self.compact_encoding_features:
                    meeting_count = len(meetings)
                    participant_bound = max(
                        0,
                        min(
                            self.inst.max_breaks_per_participant,
                            meeting_count - 1,
                            self.inst.n_total_slots - meeting_count,
                            len(ends),
                        ),
                    )
                    thresholds = self._add_shared_exact_cardinality_thresholds(
                        cnf,
                        ends,
                        participant=participant,
                        upper_bound=participant_bound,
                    )
                else:
                    thresholds = self._add_exact_cardinality_thresholds(
                        cnf,
                        ends,
                        participant=participant,
                        family="break_groups",
                        upper_bound=self.inst.max_breaks_per_participant,
                    )
            ends_by_participant.append(ends)
            thresholds_by_participant.append(thresholds)

        return ends_by_participant, thresholds_by_participant

    def _add_implied_constraint_1(self, cnf: CNF, participant: int) -> None:
        marker = f"(43) exactly |Mp| {self.domain_mode} usedSlot variables"
        if marker not in self.enabled_constraints:
            self.enabled_constraints.append(marker)
        lits = [
            used
            for slot in range(self.inst.n_total_slots)
            if (used := self.used_or_none(participant, slot)) is not None
        ]
        self._add_exactly_cardnet(
            cnf, lits, self.inst.n_meetings_business[participant]
        )

    def _add_implied_constraint_2(self, cnf: CNF) -> None:
        self.enabled_constraints.append("(44) atMost 2|L| busy participants per slot")
        bound = 2 * self.inst.n_tables
        for slot in range(self.inst.n_total_slots):
            lits = [
                used
                for participant in range(self.inst.n_business)
                if (used := self.used_or_none(participant, slot)) is not None
            ]
            if self.use_further_improvements:
                self._add_even_busy_cardinality(cnf, lits, bound)
            else:
                self._add_atmost_cardnet(cnf, lits, bound)

    def _add_even_busy_cardinality(self, cnf: CNF, lits: list[int], bound: int) -> None:
        """Add the useful implied even-busy constraint with a linear parity chain."""

        marker = "(45) exact even number of busy participants"
        if marker not in self.enabled_constraints:
            self.enabled_constraints.append(marker)
        self._add_atmost_cardnet(cnf, lits, bound)
        if not lits:
            return
        if len(lits) == 1:
            cnf.append([-lits[0]])
            return

        parity = lits[0]
        for index, lit in enumerate(lits[1:], start=1):
            next_parity = self.vpool.id(("busyParity", tuple(lits), index))
            cnf.append([parity, lit, -next_parity])
            cnf.append([-parity, -lit, -next_parity])
            cnf.append([parity, -lit, next_parity])
            cnf.append([-parity, lit, next_parity])
            parity = next_parity
        cnf.append([-parity])

    def _add_gap_objective(
        self,
        cnf: CNF,
        thresholds_by_participant: list[list[int]],
    ) -> list[int]:
        """Encode exactly ``max_{p in P*} B(p)-min_{p in P*} B(p)``."""

        self.enabled_constraints.append(
            "exact max/min objective gap over P* with no hard upper bound"
        )
        return self._add_exact_range(
            cnf,
            thresholds_by_participant,
            participants=self.objective_participants,
            family="idle_slots",
        )

    def _add_exact_range(
        self,
        cnf: CNF,
        thresholds_by_participant: list[list[int]],
        *,
        participants: tuple[int, ...],
        family: str,
    ) -> list[int]:
        """Encode the exact max--min range of a unary threshold family."""

        self._range_max_lits[family] = []
        if len(participants) <= 1:
            return []

        if (
            family == "idle_slots"
            and "attainable_values" in self.compact_encoding_features
        ):
            self._compressed_idle_extremes(
                cnf,
                include_range=True,
                family=family,
            )
            return []

        direct_soft = (
            "direct_range_soft" in self.compact_encoding_features
            and family == "idle_slots"
        )
        if direct_soft:
            self._direct_range_soft_clauses[family] = []
            self._direct_range_soft_weights[family] = []

        global_upper = max(
            (
                len(thresholds_by_participant[participant])
                for participant in participants
            ),
            default=0,
        )
        gap_lits: list[int] = []
        max_lits: list[int] = []
        min_lits: list[int] = []

        for amount in range(1, global_upper + 1):
            max_lit = self.range_max(family, amount)
            min_lit = self.range_min(family, amount)
            max_lits.append(max_lit)
            min_lits.append(min_lit)

            present = [
                thresholds_by_participant[participant][amount - 1]
                for participant in participants
                if amount <= len(thresholds_by_participant[participant])
            ]

            if present:
                for threshold in present:
                    cnf.append([-threshold, max_lit])
                cnf.append([-max_lit] + present)
            else:
                cnf.append([-max_lit])

            if len(present) != len(participants):
                cnf.append([-min_lit])
            else:
                for threshold in present:
                    cnf.append([-min_lit, threshold])
                cnf.append([min_lit] + [-threshold for threshold in present])

            if direct_soft:
                self._direct_range_soft_clauses[family].append(
                    (-max_lit, min_lit)
                )
                self._direct_range_soft_weights[family].append(1)
            else:
                gap_lit = self.range_difference(family, amount)
                gap_lits.append(gap_lit)
                cnf.append([-gap_lit, max_lit])
                cnf.append([-gap_lit, -min_lit])
                cnf.append([-max_lit, min_lit, gap_lit])

        for index in range(1, len(max_lits)):
            cnf.append([-max_lits[index], max_lits[index - 1]])
            cnf.append([-min_lits[index], min_lits[index - 1]])

        self._range_max_lits[family] = max_lits
        return gap_lits

    def _build_objective_family(
        self,
        cnf: CNF,
    ) -> tuple[
        list[list[int]],
        list[int],
        list[list[int]],
        list[list[int]],
        list[int],
        tuple[ObjectiveTier, ...],
        str,
    ]:
        """Build only the objective components required by ``objective_mode``."""

        needs_idle = self.objective_mode in {
            "ir",
            "ir_is",
            "ir_im_is",
            "ir_im_isq",
            "bg_ir_is",
            "is",
            "isq",
            "im_is",
        }
        needs_groups = self.objective_mode in {
            "bg_d2",
            "bg_dinf",
            "bg_ir_is",
        }
        use_certified_bg = (
            self.objective_mode == "bg_d2"
            and "certified_bg" in self.compact_encoding_features
            and self.zero_break_certificate_participant is not None
        )
        if (
            self.objective_mode == "bg_d2"
            and "certified_bg" in self.compact_encoding_features
        ):
            self.zero_break_branch = (
                "certified" if use_certified_bg else "general_fallback"
            )

        idle_thresholds = [[] for _ in range(self.inst.n_business)]
        idle_range_lits: list[int] = []
        if needs_idle:
            if (
                self.objective_mode == "is"
                and "attainable_values" in self.compact_encoding_features
            ):
                self._add_direct_idle_sum_cost(cnf)
            else:
                idle_thresholds = self._add_span_break_thresholds(cnf)
            if self.objective_mode in {
                "ir",
                "ir_is",
                "ir_im_is",
                "ir_im_isq",
                "bg_ir_is",
            }:
                idle_range_lits = self._add_gap_objective(cnf, idle_thresholds)

            if self.participant_idle_cap_rule == "interpolated_bounds":
                for participant in self.objective_participants:
                    cap = self.participant_idle_caps[participant]
                    indicator = self._idle_indicator_at_level(
                        participant,
                        cap + 1,
                    )
                    if indicator is True:
                        cnf.append([])
                        self.participant_idle_cap_clause_count += 1
                    elif indicator is not False:
                        cnf.append([-int(indicator)])
                        self.participant_idle_cap_clause_count += 1
                alpha = self.participant_idle_cap_alpha
                self.enabled_constraints.append(
                    "participant idle caps I_p <= floor(LB_p + "
                    f"{alpha.numerator}/{alpha.denominator}(UB_p-LB_p))"
                )

        group_ends = [[] for _ in range(self.inst.n_business)]
        group_thresholds = [[] for _ in range(self.inst.n_business)]
        group_range_lits: list[int] = []
        if needs_groups:
            group_ends, group_thresholds = self._add_break_group_thresholds(
                cnf,
                include_thresholds=(
                    not use_certified_bg
                    and self.objective_mode != "bg_dinf"
                ),
            )

        idle_sum_lits = [
            literal
            for participant in self.objective_participants
            for literal in idle_thresholds[participant]
        ]
        use_direct_group_cost = (
            use_certified_bg or self.objective_mode == "bg_dinf"
        )
        group_sum_lits = [
            literal
            for participant_values in (
                group_ends if use_direct_group_cost else group_thresholds
            )
            for literal in participant_values
        ]
        idle_range_soft_clauses = tuple(
            self._direct_range_soft_clauses.get("idle_slots", ())
        )
        idle_range_soft_weights = tuple(
            self._direct_range_soft_weights.get(
                "idle_slots",
                (1,) * len(idle_range_soft_clauses),
            )
        )
        use_attainable_values = (
            "attainable_values" in self.compact_encoding_features
        )
        idle_sum_penalties: tuple[tuple[int, ...], ...] = ()
        idle_sum_weights: tuple[int, ...] = ()
        idle_sum_upper = len(idle_sum_lits)
        squared_idle_penalties: tuple[tuple[int, ...], ...] = ()
        squared_idle_weights: tuple[int, ...] = ()
        squared_idle_upper = sum(
            len(idle_thresholds[participant]) ** 2
            for participant in self.objective_participants
        )
        if use_attainable_values and self.objective_mode == "is":
            idle_sum_penalties = tuple(self._direct_idle_sum_clauses)
            idle_sum_weights = (1,) * len(idle_sum_penalties)
            idle_sum_upper = sum(
                self._participant_idle_attainable_values[participant][-1]
                for participant in self.objective_participants
            )
        elif use_attainable_values and self.objective_mode in {
            "ir_is",
            "ir_im_is",
            "bg_ir_is",
            "im_is",
        }:
            (
                idle_sum_penalties,
                idle_sum_weights,
                idle_sum_upper,
            ) = self._idle_cost_penalties(cnf, squared=False)
        if use_attainable_values and self.objective_mode in {
            "isq",
            "ir_im_isq",
        }:
            (
                squared_idle_penalties,
                squared_idle_weights,
                squared_idle_upper,
            ) = self._idle_cost_penalties(cnf, squared=True)

        if self.objective_mode == "bg_d2":
            if use_certified_bg:
                for participant_ends in group_ends:
                    self._add_atmost_seqcounter(cnf, participant_ends, 2)
                self.enabled_constraints.append(
                    "certified zero-break BG-d2: per-participant G_p <= 2"
                )
            else:
                group_range_lits = self._add_exact_range(
                    cnf,
                    group_thresholds,
                    participants=tuple(range(self.inst.n_business)),
                    family="break_groups",
                )
                self._add_atmost_seqcounter(cnf, group_range_lits, 2)
                self.enabled_constraints.append(
                    "historical hard cap Delta_G <= 2"
                )
            tiers = (
                ObjectiveTier(
                    "total_break_groups",
                    tuple(group_sum_lits),
                    len(group_sum_lits),
                    1,
                ),
            )
            name = (
                "total_break_groups_subject_to_certified_individual_cap_2"
                if use_certified_bg
                else "total_break_groups_subject_to_range_at_most_2"
            )
        elif self.objective_mode == "bg_dinf":
            tiers = (
                ObjectiveTier(
                    "total_break_groups",
                    tuple(group_sum_lits),
                    len(group_sum_lits),
                    1,
                ),
            )
            name = "total_break_groups_without_homogeneity"
        elif self.objective_mode == "is":
            tiers = (
                ObjectiveTier(
                    "total_internal_idle_slots",
                    tuple() if use_attainable_values else tuple(idle_sum_lits),
                    idle_sum_upper,
                    1,
                    penalty_clauses=idle_sum_penalties,
                    penalty_weights=idle_sum_weights,
                ),
            )
            name = "total_internal_idle_slots"
        elif self.objective_mode == "isq":
            if use_attainable_values:
                weights = squared_idle_weights
                penalties = squared_idle_penalties
            else:
                weights = tuple(
                    2 * level - 1
                    for participant in self.objective_participants
                    for level in range(
                        1,
                        len(idle_thresholds[participant]) + 1,
                    )
                )
                penalties = ()
            tiers = (
                ObjectiveTier(
                    "squared_internal_idle_slots",
                    tuple() if use_attainable_values else tuple(idle_sum_lits),
                    squared_idle_upper,
                    1,
                    penalty_clauses=penalties,
                    penalty_weights=weights,
                ),
            )
            name = "sum_squared_internal_idle_slots"
        elif self.objective_mode in {"im_is", "ir_im_is", "ir_im_isq"}:
            if use_attainable_values:
                maximum_upper = max(
                    (
                        min(
                            self._participant_idle_attainable_values[
                                participant
                            ][-1],
                            self.participant_idle_caps[participant],
                        )
                        if self.participant_idle_cap_rule
                        == "interpolated_bounds"
                        else self._participant_idle_attainable_values[
                            participant
                        ][-1]
                        for participant in self.objective_participants
                    ),
                    default=0,
                )
                if "idle_slots" not in self._range_max_penalty_clauses:
                    self._compressed_idle_extremes(
                        cnf,
                        include_range=False,
                    )
                maximum_lits: list[int] = []
                maximum_penalties = tuple(
                    self._range_max_penalty_clauses.get("idle_slots", ())
                )
                maximum_penalty_weights = tuple(
                    self._range_max_penalty_weights.get("idle_slots", ())
                )
            else:
                maximum_upper = max(
                    (
                        self.participant_idle_caps[participant]
                        if self.participant_idle_cap_rule
                        == "interpolated_bounds"
                        else len(idle_thresholds[participant])
                        for participant in self.objective_participants
                    ),
                    default=0,
                )
                maximum_penalties = ()
                maximum_penalty_weights = ()

            if self.objective_mode == "im_is" and not use_attainable_values:
                maximum_lits = []
                structural_maximum_upper = max(
                    (len(idle_thresholds[participant])
                     for participant in self.objective_participants),
                    default=0,
                )
                for level in range(structural_maximum_upper):
                    inputs = [
                        idle_thresholds[participant][level]
                        for participant in self.objective_participants
                        if level < len(idle_thresholds[participant])
                    ]
                    out = self.vpool.id(("idle_maximum", level + 1))
                    for literal in inputs:
                        cnf.append([-literal, out])
                    cnf.append([-out] + inputs)
                    maximum_lits.append(out)
            elif not use_attainable_values:
                # IR already needs exactly these max-threshold states. Sharing
                # them avoids a duplicate maximum family in the compact model.
                maximum_lits = list(self._range_max_lits.get("idle_slots", ()))
                if not maximum_lits and self.objective_participants:
                    structural_maximum_upper = max(
                        (len(idle_thresholds[participant])
                         for participant in self.objective_participants),
                        default=0,
                    )
                    for level in range(structural_maximum_upper):
                        inputs = [
                            idle_thresholds[participant][level]
                            for participant in self.objective_participants
                            if level < len(idle_thresholds[participant])
                        ]
                        out = self.vpool.id(("idle_maximum", level + 1))
                        for literal in inputs:
                            cnf.append([-literal, out])
                        cnf.append([-out] + inputs)
                        maximum_lits.append(out)

            if not use_attainable_values:
                idle_sum_upper = sum(
                    self.participant_idle_caps[participant]
                    if self.participant_idle_cap_rule == "interpolated_bounds"
                    else len(idle_thresholds[participant])
                    for participant in self.objective_participants
                )
                squared_idle_upper = sum(
                    (
                        self.participant_idle_caps[participant]
                        if self.participant_idle_cap_rule
                        == "interpolated_bounds"
                        else len(idle_thresholds[participant])
                    )
                    ** 2
                    for participant in self.objective_participants
                )
            last_tier_upper = (
                squared_idle_upper
                if self.objective_mode == "ir_im_isq"
                else idle_sum_upper
            )
            maximum_weight = last_tier_upper + 1
            maximum_tier = ObjectiveTier(
                "maximum_internal_idle_slots",
                tuple() if use_attainable_values else tuple(maximum_lits),
                maximum_upper,
                maximum_weight,
                penalty_clauses=maximum_penalties,
                penalty_weights=maximum_penalty_weights,
            )
            if self.objective_mode == "ir_im_isq":
                if use_attainable_values:
                    squared_weights = squared_idle_weights
                    squared_penalties = squared_idle_penalties
                else:
                    squared_weights = tuple(
                        2 * level - 1
                        for participant in self.objective_participants
                        for level in range(
                            1,
                            len(idle_thresholds[participant]) + 1,
                        )
                    )
                    squared_penalties = ()
                last_tier = ObjectiveTier(
                    "squared_internal_idle_slots",
                    tuple() if use_attainable_values else tuple(idle_sum_lits),
                    squared_idle_upper,
                    1,
                    penalty_clauses=squared_penalties,
                    penalty_weights=squared_weights,
                )
            else:
                last_tier = ObjectiveTier(
                    "total_internal_idle_slots",
                    tuple() if use_attainable_values else tuple(idle_sum_lits),
                    idle_sum_upper,
                    1,
                    penalty_clauses=idle_sum_penalties,
                    penalty_weights=idle_sum_weights,
                )
            if self.objective_mode == "im_is":
                tiers = (maximum_tier, last_tier)
                name = "lexicographic_maximum_idle_then_idle_sum"
            else:
                # One unit of range must dominate the largest possible
                # combined IM/IS cost. Since IM <= maximum_upper and
                # IS <= idle_sum_upper, this product is exactly one larger
                # than that lower-tier upper bound.
                range_weight = (maximum_upper + 1) * (last_tier_upper + 1)
                tiers = (
                    ObjectiveTier(
                        "idle_range_pstar",
                        tuple(idle_range_lits),
                        (
                            sum(idle_range_soft_weights)
                            if idle_range_soft_clauses
                            else len(idle_range_lits)
                        ),
                        range_weight,
                        penalty_clauses=idle_range_soft_clauses,
                        penalty_weights=idle_range_soft_weights,
                    ),
                    maximum_tier,
                    last_tier,
                )
                name = (
                    "lexicographic_idle_range_maximum_idle_then_squared_idle_sum"
                    if self.objective_mode == "ir_im_isq"
                    else "lexicographic_idle_range_maximum_idle_then_idle_sum"
                )
        elif self.objective_mode == "ir_is":
            primary_weight = idle_sum_upper + 1
            idle_range_upper = (
                sum(idle_range_soft_weights)
                if idle_range_soft_clauses
                else len(idle_range_lits)
            )
            tiers = (
                ObjectiveTier(
                    "idle_range_pstar",
                    tuple(idle_range_lits),
                    idle_range_upper,
                    primary_weight,
                    penalty_clauses=idle_range_soft_clauses,
                    penalty_weights=idle_range_soft_weights,
                ),
                ObjectiveTier(
                    "total_internal_idle_slots",
                    tuple() if use_attainable_values else tuple(idle_sum_lits),
                    idle_sum_upper,
                    1,
                    penalty_clauses=idle_sum_penalties,
                    penalty_weights=idle_sum_weights,
                ),
            )
            name = "lexicographic_idle_range_then_idle_sum"
        elif self.objective_mode == "bg_ir_is":
            idle_weight = idle_sum_upper + 1
            idle_range_upper = (
                sum(idle_range_soft_weights)
                if idle_range_soft_clauses
                else len(idle_range_lits)
            )
            group_weight = (idle_range_upper + 1) * idle_weight
            tiers = (
                ObjectiveTier(
                    "total_break_groups",
                    tuple(group_sum_lits),
                    len(group_sum_lits),
                    group_weight,
                ),
                ObjectiveTier(
                    "idle_range_pstar",
                    tuple(idle_range_lits),
                    idle_range_upper,
                    idle_weight,
                    penalty_clauses=idle_range_soft_clauses,
                    penalty_weights=idle_range_soft_weights,
                ),
                ObjectiveTier(
                    "total_internal_idle_slots",
                    tuple() if use_attainable_values else tuple(idle_sum_lits),
                    idle_sum_upper,
                    1,
                    penalty_clauses=idle_sum_penalties,
                    penalty_weights=idle_sum_weights,
                ),
            )
            name = "lexicographic_break_groups_idle_range_idle_sum"
        else:
            tiers = (
                ObjectiveTier(
                    "idle_range_pstar",
                    tuple(idle_range_lits),
                    (
                        sum(idle_range_soft_weights)
                        if idle_range_soft_clauses
                        else len(idle_range_lits)
                    ),
                    1,
                    penalty_clauses=idle_range_soft_clauses,
                    penalty_weights=idle_range_soft_weights,
                ),
            )
            name = "internal_idle_slot_range_pstar"

        return (
            idle_thresholds,
            idle_range_lits,
            group_ends,
            group_thresholds,
            group_range_lits,
            tiers,
            name,
        )

    # Decoding and independent validation ------------------------------

    def decode_assignment(self, sat_model: list[int]) -> list[int]:
        positives = {lit for lit in sat_model if lit > 0}
        assignment = [-1] * self.inst.n_meetings
        for meeting, slots in enumerate(self._eligible_slots):
            chosen = [slot for slot in slots if self.x(meeting, slot) in positives]
            assignment[meeting] = chosen[0] if chosen else -1
        return assignment

    def encoded_objective_value(self, sat_model: list[int]) -> int:
        """Return the exact scalarized MaxSAT cost of a model."""

        vector = self.encoded_objective_vector(sat_model)
        artifacts = self.build_base_cnf()
        return sum(
            tier.scalar_weight * value
            for tier, value in zip(artifacts.objective_tiers, vector)
        )

    def encoded_objective_vector(self, sat_model: list[int]) -> tuple[int, ...]:
        artifacts = self.build_base_cnf()
        positives = {lit for lit in sat_model if lit > 0}

        def clause_is_violated(clause: tuple[int, ...]) -> bool:
            return all(
                (literal > 0 and literal not in positives)
                or (literal < 0 and -literal in positives)
                for literal in clause
            )

        return tuple(
            sum(weight * clause_is_violated(clause)
                for clause, weight in zip(tier.maxsat_clauses, tier.maxsat_weights))
            for tier in artifacts.objective_tiers
        )

    def objective_consistency_errors(
        self,
        sat_model: list[int],
        stats: B2BSolutionStats,
        *,
        imposed_bound: int | None = None,
        imposed_bounds: tuple[int, ...] | None = None,
        solver_cost: int | None = None,
    ) -> list[str]:
        encoded_vector = self.encoded_objective_vector(sat_model)
        expected_vector = stats.objective_vector
        scalar_cost = self.encoded_objective_value(sat_model)
        errors: list[str] = []
        if encoded_vector != expected_vector:
            errors.append(
                "objective encoding mismatch: "
                f"encoded={encoded_vector}, schedule={expected_vector}"
            )
        if imposed_bound is not None and encoded_vector[0] > imposed_bound:
            errors.append(
                "objective-bound violation: "
                f"encoded primary={encoded_vector[0]}, "
                f"imposed bound={imposed_bound}"
            )
        if imposed_bounds is not None:
            for index, bound in enumerate(imposed_bounds):
                if index < len(encoded_vector) and encoded_vector[index] > bound:
                    errors.append(
                        "objective-bound violation: "
                        f"tier={index + 1}, encoded={encoded_vector[index]}, "
                        f"imposed bound={bound}"
                    )
        if solver_cost is not None and solver_cost != scalar_cost:
            errors.append(
                "solver-cost mismatch: "
                f"solver cost={solver_cost}, encoded scalar={scalar_cost}"
            )
        if self.objective_mode == "bg_d2" and stats.break_group_range > 2:
            errors.append(
                "historical fairness-cap violation: "
                f"Delta_G={stats.break_group_range}>2"
            )
        if self.participant_idle_cap_rule == "interpolated_bounds":
            for participant in self.objective_participants:
                idle = stats.participant_breaks[participant]
                cap = self.participant_idle_caps[participant]
                if idle > cap:
                    errors.append(
                        "participant idle-cap violation: "
                        f"p={participant + 1}, I_p={idle}, b_p={cap}"
                    )
        return errors

    def compute_stats(self, assignment: list[int]) -> B2BSolutionStats:
        return compute_solution_stats(
            self.inst,
            assignment,
            participants=self.objective_participants,
            objective_mode=self.objective_mode,
        )

    def validate_assignment(self, assignment: list[int]) -> list[str]:
        """Check a decoded schedule against the original hard B2B semantics."""

        return validate_schedule_assignment(
            self.inst,
            assignment,
            graph=self.graph,
        )


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------


def _main() -> None:
    import argparse

    parser = argparse.ArgumentParser(
        description=(
            "Build the optimized objective-only B2B SAT/MaxSAT encoding."
        )
    )
    parser.add_argument("instance", help="MiniZinc .dzn instance")
    parser.add_argument(
        "--precedence-mode",
        choices=sorted(VALID_PRECEDENCE_MODES),
        help="deprecated composite alias: traditional or staircase",
    )
    parser.add_argument(
        "--precedence-encoding",
        choices=sorted(VALID_PRECEDENCE_ENCODINGS),
        help="P factor: pairwise or sparse_suffix",
    )
    parser.add_argument(
        "--precedence-graph",
        choices=sorted(VALID_PRECEDENCE_GRAPHS),
        help="G factor: direct or distance_closure",
    )
    parser.add_argument(
        "--domain-filter-graph",
        choices=sorted(VALID_DOMAIN_FILTER_GRAPHS),
        default="distance_closure",
        help="F factor for Reduced preprocessing: direct (E) or closure (E*)",
    )
    parser.add_argument(
        "--encoding-variant",
        choices=sorted(VALID_ENCODING_VARIANTS),
        default="imp12+",
    )
    parser.add_argument(
        "--domain-mode",
        choices=sorted(VALID_DOMAIN_MODES),
        default="reduced",
    )
    parser.add_argument(
        "--objective-mode",
        choices=sorted(VALID_OBJECTIVE_MODES),
        default="ir",
    )
    parser.add_argument(
        "--compact-encoding",
        choices=sorted(VALID_COMPACT_ENCODINGS),
        default="reference",
    )
    parser.add_argument(
        "--collision-amo",
        choices=sorted(VALID_COLLISION_AMO_ENCODINGS),
        default="pairwise",
    )
    parser.add_argument(
        "--participant-idle-cap-rule",
        choices=sorted(VALID_PARTICIPANT_IDLE_CAP_RULES),
        default="none",
    )
    parser.add_argument(
        "--participant-idle-cap-alpha",
        default="1/2",
        help="exact alpha in [0,1], e.g. 1/2, for interpolated_bounds",
    )
    parser.add_argument("--write-cnf", type=Path)
    parser.add_argument("--write-wcnf", type=Path)
    parser.add_argument("--skip-meetingsx-validation", action="store_true")
    args = parser.parse_args()
    if args.precedence_mode is not None and (
        args.precedence_encoding is not None or args.precedence_graph is not None
    ):
        parser.error(
            "--precedence-mode cannot be combined with independent P/G flags"
        )
    if (args.precedence_encoding is None) != (args.precedence_graph is None):
        parser.error(
            "--precedence-encoding and --precedence-graph must be used together"
        )

    inst = read_instance(
        args.instance,
        validate_meetingsx_business=not args.skip_meetingsx_validation,
    )
    model = B2BSATModel(
        inst=inst,
        precedence_mode=args.precedence_mode,
        precedence_encoding=args.precedence_encoding,
        precedence_graph=args.precedence_graph,
        domain_filter_graph=args.domain_filter_graph,
        encoding_variant=args.encoding_variant,
        domain_mode=args.domain_mode,
        objective_mode=args.objective_mode,
        compact_encoding=args.compact_encoding,
        collision_amo_encoding=args.collision_amo,
        participant_idle_cap_rule=args.participant_idle_cap_rule,
        participant_idle_cap_alpha=args.participant_idle_cap_alpha,
    )
    artifacts = model.build_base_cnf()

    print(f"instance={inst.instance_name}")
    print(f"variant={artifacts.encoding_variant}")
    print(f"precedence_mode={artifacts.precedence_mode}")
    print(f"precedence_encoding={artifacts.precedence_encoding}")
    print(f"precedence_graph={artifacts.precedence_graph}")
    print(f"precedence_configuration={artifacts.precedence_configuration}")
    print(f"domain_mode={artifacts.domain_mode}")
    print(f"domain_filter_graph={artifacts.domain_filter_graph}")
    print(f"domain_filter_iterations={artifacts.domain_filter_iterations}")
    print(f"domain_filter_seconds={artifacts.domain_filter_seconds:.6f}")
    print(
        "schedule_candidates="
        f"active:{artifacts.active_schedule_candidates}, "
        f"full:{artifacts.full_schedule_candidates}, "
        f"unary_eligible:{artifacts.unary_eligible_schedule_candidates}, "
        f"reduced:{artifacts.reduced_schedule_candidates}"
    )
    print(
        "precedence_edges="
        f"direct:{artifacts.precedence_direct_edges}, "
        f"closure:{artifacts.precedence_transitive_edges}, "
        f"max_distance:{artifacts.precedence_max_distance}"
    )
    print(
        "precedence_encoding_metrics="
        f"relations:{artifacts.precedence_relation_edges}, "
        f"pairwise_clauses:{artifacts.precedence_pairwise_clauses}, "
        f"sparse_links:{artifacts.precedence_sparse_link_clauses}, "
        f"unique_cuts:{artifacts.precedence_unique_suffix_cuts}"
    )
    print(
        "precedence_cycle_nodes="
        f"{[node + 1 for node in artifacts.precedence_cycle_nodes]}"
    )
    print(f"vars={artifacts.n_vars}")
    print(f"clauses={artifacts.n_clauses}")
    print(f"objective={artifacts.objective_name}")
    print(f"objective_mode={artifacts.objective_mode}")
    print(f"compact_encoding={artifacts.compact_encoding}")
    print(
        "compact_encoding_features="
        f"{','.join(artifacts.compact_encoding_features)}"
    )
    print(f"collision_amo={artifacts.collision_amo_encoding}")
    print(f"participant_idle_cap_rule={artifacts.participant_idle_cap_rule}")
    print(f"participant_idle_cap_alpha={artifacts.participant_idle_cap_alpha}")
    print(f"participant_idle_lower_bounds={artifacts.participant_idle_lower_bounds}")
    print(f"participant_idle_upper_bounds={artifacts.participant_idle_upper_bounds}")
    print(f"participant_idle_caps={artifacts.participant_idle_caps}")
    print(
        "collision_amo_metrics="
        f"cutoff:{artifacts.collision_amo_cutoff}, "
        "commander_group_size:"
        f"{artifacts.collision_amo_commander_group_size}, "
        f"pairwise_groups:{artifacts.collision_amo_pairwise_group_count}, "
        f"commander_groups:{artifacts.collision_amo_commander_group_count}, "
        "commander_variables:"
        f"{artifacts.collision_amo_commander_variable_count}, "
        f"clauses:{artifacts.collision_amo_clause_count}, "
        f"max_group:{artifacts.collision_amo_max_group_size}"
    )
    print(
        "objective_tiers="
        + ", ".join(
            f"{tier.name}:{tier.upper_bound}@{tier.scalar_weight}"
            for tier in artifacts.objective_tiers
        )
    )
    print(
        "objective_participants="
        f"{[participant + 1 for participant in artifacts.objective_participants]}"
    )
    print(f"objective_encoding={artifacts.objective_encoding}")
    print(f"objective_literals={len(artifacts.objective_lits)}")
    print("enabled_constraints=")
    for item in artifacts.enabled_constraints:
        print(f"  - {item}")

    if args.write_cnf is not None:
        artifacts.cnf.to_file(str(args.write_cnf))
        print(f"wrote_cnf={args.write_cnf}")
    if args.write_wcnf is not None:
        model.build_wcnf().to_file(str(args.write_wcnf))
        print(f"wrote_wcnf={args.write_wcnf}")


if __name__ == "__main__":
    _main()
