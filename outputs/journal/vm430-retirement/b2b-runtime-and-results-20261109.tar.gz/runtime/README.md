# B2B SAT/MaxSAT journal objective framework

For the current **1,638-run All-126 first repetition**, see
[the T1–T3 run instructions](#first-all-126-journal-campaign-t1t3).

This repository implements the conference formulation and the journal
objective extension of the Business-to-Business Meeting Scheduling Problem.
Source code is available under the [MIT License](LICENSE). Author-generated
experimental records and analysis outputs are available under
[CC BY 4.0](DATA_LICENSE.md); the source benchmark instances retain their
original terms.
The backward-compatible default objective is

\[
\operatorname{IdleRange}(P^\star)
= \max_{p\in P^\star} B(p)-\min_{p\in P^\star} B(p),
\qquad
P^\star=\{p:|M_p|\ge 2\},
\]

where `B(p)` is the number of idle slots strictly between participant `p`'s
first and last meetings. Participants with zero or one meeting are excluded
because their internal idle time is structurally zero.

The shared Boolean model additionally supports:

| CLI mode | Exact objective |
|---|---|
| `ir` | minimize `IdleRange(P*)` (conference default) |
| `bg_d2` | minimize total break groups subject to hard `BreakGroupRange <= 2` |
| `bg_dinf` | minimize total break groups without a homogeneity constraint (`d = infinity`) |
| `ir_is` | lexicographically minimize `(IdleRange(P*), total internal idle slots)` |
| `ir_im_is` | lexicographically minimize `(IdleRange(P*), maximum participant idle, total internal idle slots)` |
| `ir_im_isq` | lexicographically minimize `(IdleRange(P*), maximum participant idle, squared idle sum)` (MaxSAT only) |
| `bg_ir_is` | lexicographically minimize `(total break groups, IdleRange(P*), total internal idle slots)` |
| `is` | minimize total internal idle slots |
| `isq` | minimize the sum of squared participant idle counts (MaxSAT only) |
| `im_is` | lexicographically minimize `(maximum participant idle, total internal idle slots)` |

`MaxSAT_Solver.py` uses exact dominating weights and weighted ISQ penalties.
`Multiple_SAT.py` and `IncrementalSAT_Solver.py` optimize supported unweighted
tiers sequentially; ISQ is rejected. The latter retains one
solver and its learned clauses across tiers. Commercial MIP/CP adapters still
support only `ir`, and the CLI rejects other modes for those solvers.

Participant-specific idle caps remain available as an optional sensitivity
study, but they are disabled in the baseline and final-tier comparisons. To
enable them explicitly, add
`--participant-idle-cap-rule interpolated_bounds` and an exact rational
`--participant-idle-cap-alpha`. For each
participant, the implementation computes a shortest matching-feasible unary
interval `LB_p`, the widest unary-domain span `UB_p`, and

```text
b_p = floor(LB_p + alpha * (UB_p - LB_p)).
```

It then adds the hard clause `I_p <= b_p`. Bounds use only session, fixed, and
forbidden-slot domains, so the legacy Full model and Reduced compact model use
the same cap. Every detailed row records all lower bounds, upper bounds, caps,
alpha, and the number of cap clauses.

The objective encoder also exposes an independent compactness factor through
`--compact-encoding`:

| Preset | Refinement | Effective scope |
|---|---|---|
| `reference` | unchanged exact reference encoding | all engines/modes |
| `certified_bg` | A: replace BG-d2 range by per-participant `AtMost(2)` when an input certificate proves a zero-break participant | BG-d2; exact general fallback otherwise |
| `shared_counter` | B: one bidirectional dynamic-programming counter for all break-group thresholds | modes that retain break-group thresholds |
| `demand_driven` | C: build only consumed prefix/suffix states and reuse exact singleton/unchanged literals | all modes |
| `direct_range_soft` | D: penalize each idle-range level by `not qmax or qmin` without a range-difference variable | MaxSAT idle-range modes only |
| `optimized` | compatible A+B+C+D bundle | MaxSAT; D is inactive when no idle range is used |

The default remains `reference`, so previous commands and configuration IDs
are stable. The runner records the selected preset, effective feature list,
certificate participant/reason, selected certified/fallback branch, alias
counts, shared-counter states, and direct range soft-clause count. It rejects
D instead of silently translating its non-unit soft clauses into an invalid
SAT cardinality tier.

Participant-collision AMO is a separate factor.  The default
`--collision-amo pairwise` preserves previous formulas and configuration IDs.
`--collision-amo adaptive_commander` keeps pairwise AMO for groups of at most
five literals and uses group-size-four commander AMO from six literals onward.
The cutoff is fixed by the exact clause-count crossover, not tuned per
instance.  Detailed rows record the selected AMO, group counts, commander
variables, AMO clauses, and maximum group size.  Combine it with
`--compact-encoding optimized` for the implemented A+B+C+D+F model.

## Main components

- `src/B2B_Instance.py`: parser, exact domain reduction, compact feasibility,
  exact idle/break-group objective encodings, decoding, and validation.
- `src/Journal_Metrics.py`: assignment-only independent evaluator for every
  journal metric and objective vector; it does not call encoder helpers.
- `src/Journal_Objectives.py`: development-only RC2 oracle for `IR-IS`.
- `src/MaxSAT_Solver.py`: exact weighted partial MaxSAT with required UWrMaxSAT
  production execution and an explicit RC2 development backend.
- `src/Multiple_SAT.py`: fresh-solver, multi-phase SAT optimization.
- `src/IncrementalSAT_Solver.py`: solver-preserving, multi-phase SAT optimization.
- `src/MIP_SpanRange.py`: one solver-neutral linear model shared byte-for-byte
  at the variable/constraint IR level by both commercial MIP adapters.
- `src/Gurobi_MIP_Solver.py`: Gurobi implementation of `MIP-SpanRange`.
- `src/CPLEX_MIP_Solver.py`: CPLEX/DOcplex.MP implementation of the same
  `MIP-SpanRange` coefficient matrix.
- `src/CPLEX_CP_Solver.py`: CP Optimizer meeting-time formulation using native
  `all_diff`, `count`, `min`, and `max` expressions.
- `src/Exact_Model_Common.py`: shared reduced domains, precedence closure,
  objective participants, validation, and result records for exact baselines.
- `src/Dataset_Manifest.py`: canonical SHA-256 manifest for the official UdG
  benchmark archive.
- `src/Main.py`: timeout-controlled benchmark runner and CSV/XLSX exporter.
- `src/ORG_new.py`: the strongest legacy paper-style MaxSAT baseline. Its
  original IR cell is preserved, and its per-slot/cardinality encoding also
  supports IR-IM-IS and IR-IM-ISQ, with optional participant idle caps.

## Full versus Reduced Domain

Both modes are generated by the same shared encoder and differ only in the
schedule-variable domain:

- `Full` creates every `schedule(m,t)` variable in the Cartesian product
  \(M\times T\). Session, fixed-slot, and forbidden-slot violations are disabled
  by explicit hard unit clauses.
- `Reduced` creates schedule variables only at the exact preprocessing fixed
  point after unary filtering, precedence propagation over the selected filter
  graph, participant all-different matching GAC, and saturated slot-capacity
  propagation.

All other hard constraints, `SpanThreshold` idle encoding, `IdleRange(P*)`
objective, precedence configuration, and optimizer are shared. Use
`--domain-mode full|reduced|both` in the benchmark runner.

Detailed CSV output distinguishes `full_schedule_candidates` (\(|M||T|\)),
`unary_eligible_schedule_candidates`, `reduced_schedule_candidates`, and
`active_schedule_candidates`. The legacy `initial_schedule_candidates` field
remains an alias for the unary-eligible count.

## Independent precedence factors

The shared encoder exposes the precedence constraint encoding (P) and graph
(G) as independent flags:

- `--precedence-encoding pairwise` emits one binary clause for each violating
  meeting-slot pair.
- `--precedence-encoding sparse_suffix` uses exact shared suffix literals at
  only the cut positions queried by the selected relations.
- `--precedence-graph direct` encodes each input edge with distance one.
- `--precedence-graph distance_closure` encodes every transitive relation with
  its longest-path distance.

This gives the complete `2 x 2` P/G factorial matrix. Reduced-domain
preprocessing has a separate F factor:

- `--domain-filter-graph direct` uses the direct input graph E (`Filter-E`).
- `--domain-filter-graph distance_closure` uses the distance-labelled closure
  E* (`Filter-E*`, the backward-compatible default).
- `--domain-filter-graph both` emits both Reduced configurations. Full is
  emitted once because preprocessing does not change its schedule variables.

Thus F controls domain filtering while G controls only the relations encoded
in the CNF. The deprecated aliases remain exact P/G mappings:
`traditional = pairwise + direct` and
`staircase = sparse_suffix + distance_closure`.

Detailed CSV output records `domain_filter_graph`, `precedence_encoding`,
`precedence_graph`, their factor labels, selected relation count, pairwise
clause count, sparse link count, and unique suffix-cut count.

## Commercial exact baselines

The cross-paradigm experiment adds exactly three configurations:

| CLI solver | Formulation | Fixed comparison configuration |
|---|---|---|
| `gurobi_mip` | `MIP-SpanRange` | Reduced domain + distance closure |
| `cplex_mip` | `MIP-SpanRange` | Reduced domain + distance closure |
| `cplex_cp` | `CP-MeetingTime-SpanRange` | Reduced domain + distance closure |

These configurations are main comparison baselines, not SAT-factor ablations.
Consequently, they are each run once per instance and are not multiplied by
`--domain-mode`, P/G, or `--encoding-variant`. Gurobi MIP and CPLEX MIP consume
the same solver-neutral variable list, coefficient matrix, bounds, variable
types, and objective. The CP model uses one sparse-domain integer time variable
per meeting and CP Optimizer global constraints.

Install the optional Python APIs with:

```bash
python3 -m pip install -r src/requirements-exact.txt
```

This does not install commercial licenses. Gurobi needs a usable Gurobi
license; CPLEX MIP and CPLEX CP need their respective IBM runtimes/licenses.
The runner fails before the batch when a requested Python API is absent and
never substitutes another solver.

## Run examples

The production implied-constraint package defaults to `imp12+`. On an instance
without precedence, omitted P/G flags automatically collapse to the neutral
`pairwise + direct` cell, giving exactly `2 domains x 3 engines = 6` runs:

```bash
python3 src/Main.py \
  --instance data_table03_origin/tic-12.original.dzn \
  --solver sat_all \
  --domain-mode both \
  --timeout 120 \
  --csv output/benchmark_results.csv
```

Run a development correctness smoke for `IR-IS` with all Boolean methods:

```bash
python3 src/Main.py \
  --instance data_table03_origin/tic-12.original.dzn \
  --solver sat_all \
  --objective-mode ir_is \
  --domain-mode both \
  --maxsat-backend rc2 \
  --timeout 120 \
  --csv output/journal_ir_is_smoke.csv
```

Run every effective compact preset for a MaxSAT objective ablation:

```bash
python3 src/Main.py \
  --instance data_table03_origin/tic-12.original.dzn \
  --solver maxsat \
  --maxsat-backend rc2 \
  --objective-mode ir_is \
  --compact-encoding all \
  --domain-mode reduced \
  --timeout 120 \
  --csv output/compact_ir_is_smoke.csv
```

Use pinned UWrMaxSAT instead of RC2 for production. Every detailed row records
the objective mode/vector, tier values/weights, break-group and idle metrics,
phase time/calls, and independent-validation errors.

On a precedence instance the same omitted P/G flags expand to all four cells,
giving exactly `2 domains x 4 P/G cells x 3 engines = 24` runs. Explicit P/G
flags always override this automatic collapse. Use `--encoding-variant all`
only for a diagnostic implied-constraint ablation.

Run only the new Filter-E Reduced cells while retaining the full P/G matrix:

```bash
python3 src/Main.py \
  --manifest instances_manifest.csv \
  --family precedence \
  --solver sat_all \
  --domain-mode reduced \
  --domain-filter-graph direct \
  --precedence-encoding both \
  --precedence-graph both \
  --encoding-variant imp12+ \
  --csv output/precedence_filter_e.csv
```

Run the complete additive Filter-E campaign across every precedence density
used in the study with:

```bash
PLAN_ONLY=1 ./run_filter_e_all_precedence.sh

UWRMAXSAT_BIN=/absolute/path/to/uwrmaxsat \
./run_filter_e_all_precedence.sh
```

The plan contains all three Boolean engines and the full P/G factorial at
Reduced domains. Full-domain models are not duplicated because F does not alter
their \(x_{m,t}\) variables.

| Dataset block | Variants | Instances | Filter-E cells/instance | New runs |
| --- | --- | ---: | ---: | ---: |
| Official precedence | `prec15`, `prec25` | 40 | 12 | 480 |
| Stress | `prec30`, `prec35`, `prec40` | 60 | 12 | 720 |
| Stress-high | `prec50`, `prec60` | 40 | 12 | 480 |
| **Total** | `prec15`--`prec60` | **140** | **12** | **1680** |

Here each instance contributes
`3 engines x 2 precedence encodings x 2 CNF precedence graphs = 12` cells.
The runner writes separate detailed CSVs for the three blocks and calls
`src/Validate_Filter_E_Run.py` before creating an archive. Terminal timeouts
count as executed cells, while missing, duplicate, Filter-E*, or solver-error
rows fail validation.

Run only the three commercial exact baselines:

```bash
python3 src/Main.py \
  --instance data_table03_origin/tic-12.original.dzn \
  --solver exact_all \
  --threads 1 \
  --random-seed 0 \
  --timeout 7200 \
  --csv output/exact_results.csv
```

Run the primary six-configuration comparison (three Boolean methods plus three
commercial exact baselines) with:

```bash
python3 src/Main.py \
  --instance data_table03_origin/tic-12.original.dzn \
  --solver all \
  --domain-mode reduced \
  --precedence-encoding sparse_suffix \
  --precedence-graph distance_closure \
  --encoding-variant imp12+ \
  --threads 1 \
  --random-seed 0 \
  --timeout 7200 \
  --csv output/six_solver_comparison.csv
```

Omitting the SAT factor flags with `--solver all` still expands the requested
SAT ablations while retaining only one run for each exact backend. The default
is `--solver sat_all`, preserving the original SAT/MaxSAT workflow on machines
without commercial APIs.

Run the canonical, deduplicated precedence family with production UWrMaxSAT:

```bash
python3 src/Main.py \
  --manifest instances_manifest.csv \
  --family precedence \
  --solver maxsat \
  --maxsat-backend uwrmaxsat \
  --uwrmaxsat-bin /absolute/path/to/uwrmaxsat \
  --uwrmaxsat-sha256 <expected-64-character-sha256> \
  --precedence-encoding sparse_suffix \
  --precedence-graph distance_closure \
  --encoding-variant imp12+ \
  --domain-mode reduced \
  --timeout 7200 \
  --csv output/table8_results.csv
```

`Main.py` defaults to UWrMaxSAT for MaxSAT and CaDiCaL 1.5.3 for both SAT
methods. It validates every requested backend before the first benchmark run.
Missing or failing production backends are errors: there is no automatic
UWrMaxSAT-to-RC2 or CaDiCaL-to-Glucose substitution. The detailed CSV records
the selected backend, version, executable path, UWrMaxSAT binary SHA-256, and
command line. `--maxsat-backend rc2` and `--sat-backend glucose` remain explicit
development-only choices and must not be mixed with production results.

## Official dataset and canonical manifest

The benchmark source is the `b2b.zip` archive linked as **B2B benchmarks** on
the UdG Logic and Artificial Intelligence page. The extracted `noves/`
directory contains 140 official paths. SHA-256 grouping yields 126 distinct
contents: 20 original, 26 forbidden, 40 fixed, and 40 precedence instances.
These contents derive from exactly 20 base lineages. The manifest records
`base_lineage_id`; statistical resampling and held-out splits must not treat
constraint variants from one lineage as independent base problems.
Fourteen forbidden contents each have two official names. The four repository
data directories mirror those 140 paths without cross-family copies.

Regenerate the checked-in manifest from the official extracted directory:

```bash
python3 src/Dataset_Manifest.py \
  --source-dir ../noves \
  --output instances_manifest.csv
```

With no `--instance`, `--data-dir`, or `--manifest`, `Main.py` uses the checked-in
manifest. Manifest and directory inputs are content-deduplicated by default;
`--keep-path-aliases` disables deduplication for an explicit `--data-dir`, and
`--family` selects `original`, `forbidden`, `fixed`, or `precedence`. Every
result records the content ID, full SHA-256, official aliases, repository
aliases, source page, and archive hash.

The official runner selects every family from the canonical manifest. The 40
official Forbidden paths represent 26 unique contents; the solver runs once per
content, while `source_alias_paths` retains coverage of all 40 names from
`noves/`.

| Family | Official paths | Solved contents | Main configurations/content | Computed Main rows | Computed ORG rows |
| --- | ---: | ---: | ---: | ---: | ---: |
| original | 20 | 20 | 6 | 120 | 20 |
| forbidden | 40 | 26 | 6 | 156 | 26 |
| fixed | 40 | 40 | 6 | 240 | 40 |
| precedence | 40 | 40 | 24 | 960 | 40 |
| **Total** | **140** | **126** |  | **1476** | **126** |

If each alias is expanded as a separate logical table row, coverage is still
1560 Main path-configuration cells and 140 ORG path cells; the 84 Main and 14
ORG alias cells do not require another solver run.

Run it with:

```bash
NOVES_DIR=/absolute/path/to/noves \
UWRMAXSAT_BIN=/absolute/path/to/uwrmaxsat \
./run_official_ic12p.sh
```

Before archiving the result, the runner calls `src/Validate_Official_Run.py`.
The archive is created only when 1476 computed Main rows and 126 computed ORG
rows pass their result and metadata checks and their aliases cover all 140
official paths.

## Derived precedence-density stress dataset

`data_precedence_stress/` is deliberately separate from the official archive.
It contains witness-preserving DAG instances at `prec30`, `prec35`, and
`prec40`. For participant \(p\), the generator uses exactly
\(\lfloor\gamma |M_p|/100\rfloor\) direct arcs, matching the edge-budget
convention observed in every official `prec15` and `prec25` file. Fixed seeds,
canonical feasible witnesses, content hashes, realized densities, and closure
statistics are recorded in the directory manifests.

Regenerate into a new directory and independently validate the checked-in
dataset with:

```bash
python3 src/Generate_Precedence_Stress.py generate \
  --output-dir /path/to/a/new/output-directory

python3 src/Generate_Precedence_Stress.py validate \
  --data-dir data_precedence_stress
```

The generator refuses to overwrite an existing directory. Use the
runner-compatible derived manifest for the four-cell Reduced/UWrMaxSAT pilot:

```bash
python3 src/Main.py \
  --manifest data_precedence_stress/instances_manifest.csv \
  --family precedence \
  --solver maxsat \
  --maxsat-backend uwrmaxsat \
  --uwrmaxsat-bin /absolute/path/to/uwrmaxsat \
  --domain-mode reduced \
  --precedence-encoding both \
  --precedence-graph both \
  --encoding-variant imp12+ \
  --timeout 7200 \
  --csv output/precedence_stress_pilot.csv
```

The primary all-engine Filter-E campaign does not stop at `prec40`; it includes
all 60 instances in this directory through
`run_filter_e_all_precedence.sh` (720 new Filter-E runs).

### High-density extension

`data_precedence_stress_high/` adds 20 witness-preserving contents at each of
`prec50` and `prec60` without replacing the original stress set.  It uses the
same source contents, canonical witnesses, global seed, and participant edge
ladders as `data_precedence_stress/`.  The test suite verifies the cross-dataset
nesting `prec40` $\subset$ `prec50` $\subset$ `prec60` for every source
content.

Regenerate, validate, and run the four-cell Reduced/UWrMaxSAT block with:

```bash
python3 src/Generate_Precedence_Stress.py generate \
  --output-dir data_precedence_stress_high \
  --gammas 50 60

python3 src/Generate_Precedence_Stress.py validate \
  --data-dir data_precedence_stress_high

python3 src/Main.py \
  --manifest data_precedence_stress_high/instances_manifest.csv \
  --family precedence \
  --solver maxsat \
  --maxsat-backend uwrmaxsat \
  --uwrmaxsat-bin /absolute/path/to/uwrmaxsat \
  --domain-mode reduced \
  --precedence-encoding both \
  --precedence-graph both \
  --encoding-variant imp12+ \
  --timeout 7200 \
  --csv output/precedence_stress_high_pilot.csv
```

The same primary Filter-E campaign includes all 40 `prec50`/`prec60` instances
through `run_filter_e_all_precedence.sh` (480 new Filter-E runs).

To clean an older run in which the Fixed rows leaked into
`data_table06_forb`, without rerunning a solver:

```bash
python3 src/Normalize_Official_Run.py \
  --source output/<old-run> \
  --output output/<old-run>-normalized
```

## Configuration identity

Every row stores nine factors separately: M (domain), F (domain-filter graph),
P (precedence encoding), G (CNF precedence graph), B (`SpanThreshold`), O
(`IdleRangePstar`, `BreakGroupsD2`, or a lexicographic mode), S (optimization
engine), I (implied package), and C (compact-objective encoding). Existing
Filter-E* labels and `cfg2` machine IDs remain unchanged so completed results
remain reusable. A new Filter-E label such as
`R-FE-SS-DC-ST-IRP-UW-IC12P` and its `cfg4` machine ID explicitly record
`f-direct`.

The I-factor names have distinct, documented roles:

| Model | CLI/machine variant | Compact label/code | Display name |
| --- | --- | --- | --- |
| Main | `imp12+` | `IC12P` | `IC12+` |
| ORG old-best baseline | `org_old_best_ic12plus` | `OBIC12P` | `OldBestIC12+` |

Here `P` means “plus” in compact identifiers. ORG uses `OBIC12P`, rather than
Main's `IC12P`, so the two implied packages cannot be confused in aggregated
results.

## Per-instance Excel logs

In addition to the aggregate and detailed CSV files, `Main.py` writes one
workbook named `<instance>.xlsx` per instance. By default the files are placed
in an `excel` directory next to `--csv`; use `--excel-dir` to select another
directory. The workbook is atomically refreshed after every completed
configuration, so results already obtained survive an interrupted batch.

The `Results` sheet has one row per configuration and records, among other
fields, the stable configuration label/ID, variables, total/hard/soft clauses,
hard/soft literals, clause-length distribution, SAT-bound overhead, status,
best returned objective value, proven optimum, dataset identity, environment,
memory, and timing. For MaxSAT, hard and soft clause counts are separate. The
`README` sheet defines the measurement scopes.

`runtime_seconds` is end-to-end monotonic wall time measured inside the worker:
from immediately before reading/parsing the `.dzn` file through formula
construction, optimization, decoding, and independent validation. It excludes
worker-process startup and CSV/XLSX export. `input_parsing_seconds`,
`model_construction_seconds`, `model_build_seconds`, and
`solve_and_validate_seconds` retain the components. A timeout is a right-censored
controller cutoff and is marked by `runtime_censored=TRUE`.
For MIP/CP, `backend_model_construction_seconds` separately measures
translation of the solver-neutral IR/specification into the commercial API;
it is included in `solve_and_validate_seconds` and in the end-to-end runtime.
This start point matches the historical `ORG_old.py` total timer, which begins
immediately before `read_input()`. The 2022 paper labels its table entries as
solving times but does not state a more precise timer boundary, so both the
explicit end-to-end value and its components are retained instead of silently
equating the two definitions.

Formula size fields describe the shared base CNF. MaxSAT's
`n_total_clauses` additionally includes the soft objective clauses (unit in the
reference encoding and possibly binary for direct range penalties). SAT
optimizer-specific bound/totalizer variables, clauses, and literals are kept in
separate `optimizer_added_*` fields, together with solver-call and bound-encoding
counts. SAT incumbents are sent to the controller during optimization, so a hard
timeout retains the best validated objective found so far.

MIP rows instead report binary/integer/continuous variables, linear
constraints, nonzeros, best bound, MIP gap, and branch-and-bound nodes. CP rows
report meeting-time integer variables, linear/global constraints, best bound,
gap, branches, and fails. Clause and constraint counts are intentionally not
presented as the same metric.

## Legacy ORG MaxSAT baseline

`ORG_new.py` is not another level of the shared M/P/G factorial model. It is a
separately labelled baseline for the strongest MaxSAT formulation of the old
paper: full meeting-slot variables, the legacy per-slot/cardinality waiting
encoding, its implied-constraint package, and UWrMaxSAT. The adaptation uses
`IdleRange(P*)`, has no lexicographic secondary objective, and does not generate
the old hard fairness constraint (d=2). Its compact configuration label is
`ORG-F-PW-DE-PSC-IRP-UW-OBIC12P`.

```bash
python3 src/ORG_new.py \
  --manifest instances_manifest.csv \
  --family precedence \
  --uwrmaxsat-bin /absolute/path/to/uwrmaxsat \
  --uwrmaxsat-sha256 <expected-64-character-sha256> \
  --timeout 7200 \
  --csv output/org_baseline.csv \
  --excel-dir output/excel_org
```

The baseline uses the same dataset manifest, UWrMaxSAT pinning, end-to-end timer,
result schema, per-instance Excel output, and independent schedule/objective
validation as the shared runner.

## JAIR experiment campaigns

The journal extension has a separate, independent historical `BG-d2` baseline
in `src/ORG_BG_D2.py`, four shared objective modes (`ir`, `bg_d2`, `ir_is`, and
exploratory `bg_ir_is`), a witness-first Generated-300 benchmark generator, a
pre-solve feature extractor, and an append-only campaign runner. Development
RC2 timings are correctness evidence only and must not be reported as production
results.

The frozen confirmatory matrices are:

| Config | Scope | Runs |
| --- | --- | ---: |
| `production_smoke.json` | pinned production gate, 12 contents | 168 |
| `official_core.json` | E1--E3, All-126, five repetitions | 8,820 |
| `precedence_ablation.json` | E4, 140 precedence contents, three repetitions | 3,360 |
| `generated_core.json` | E5, Generated-300, three repetitions | 4,500 |
| `compact_smoke.json` | pinned A--D gate, 12 contents | 168 |
| `compact_ablation.json` | paired A--D ablations, All-126, three repetitions | 5,292 |
| `compact_f_smoke.json` | optimized A--D versus A--D+F gate, 12 contents | 72 |
| `compact_f_ablation.json` | paired F ablation, All-126, three repetitions | 2,268 |

On the GCP VM, preserve the conference Python environment and solver binary.
Production configs enforce the recorded conference profile: Intel Xeon Platinum
8581C at 2.30 GHz, 4 physical/8 logical CPUs, 15,000--16,500 MiB RAM, no swap,
one run thread, random seed 0, and a 7,200-second cutoff. The 300-second smoke
and warm-up campaigns are excluded from reported timing. Copy
`journal_gcp.env.example` to the git-ignored `journal_gcp.env`, set the absolute
UWrMaxSAT path, verify the prefilled conference binary SHA-256, then run:

```bash
scripts/run_journal_gcp.sh setup

# Generate once, audit the manifests/witnesses, then commit the frozen dataset.
ALLOW_DIRTY=1 scripts/run_journal_gcp.sh generate

# From the resulting clean commit:
scripts/run_journal_gcp.sh plan
scripts/run_journal_gcp.sh coverage
scripts/run_journal_gcp.sh correctness
scripts/run_journal_gcp.sh smoke
scripts/run_journal_gcp.sh compact-smoke
scripts/run_journal_gcp.sh compact-f-smoke
scripts/run_journal_gcp.sh pilot
```

Do not start the confirmatory campaigns until the pilot validation report has
confirmed RAM/compute feasibility and the matrix and analysis specification are
frozen. The pilot does not tune the precommitted 7,200-second cutoff. Afterwards:

```bash
scripts/run_journal_gcp.sh official
scripts/run_journal_gcp.sh precedence
scripts/run_journal_gcp.sh compact
scripts/run_journal_gcp.sh compact-f
scripts/run_journal_gcp.sh generated-development

# Open held-out data exactly once after all tuning decisions are frozen.
HELDOUT_FROZEN=YES scripts/run_journal_gcp.sh generated-heldout
```

Each command runs only one benchmark worker. Thread-count environment variables
are fixed to one, and optional `CPU_CORE` affinity is inherited by every child
solver. Every cell is fsync'ed to `raw/results.jsonl`; normalized CSV and a
strict `validation_report.json` are regenerated from the latest attempts.
After VM preemption or SSH loss, repeat the same command: `--resume` is added
automatically, completed keys are skipped, and the interrupted cell is rerun.
The runner refuses a changed plan, commit, manifest, configuration, solver hash,
or dirty production worktree. When a failed VM must be replaced, set
`ALLOW_ENVIRONMENT_DRIFT=1` to accept a changed Git commit, VM profile,
Python/kernel, or pinned solver binary while retaining the original rows and
recording the new environment in `resume_environment_history`. The plan,
configuration, dataset manifests, shard count, shard indices, and assignment
policy must still match. An explicit `RETRY_ERRORS=1` creates a new
append-only attempt for existing `ERROR` rows; it never reruns a completed
timeout under a silently changed cutoff.

Keep `OUTPUT_ROOT` on a persistent disk. A campaign is paper-eligible only when
its validation report has `valid: true`, no missing/error rows, and provenance
records `git_dirty: false`. Planning or development output is not a substitute
for these conditions.

Build and inspect one CNF/WCNF directly:

```bash
python3 src/B2B_Instance.py \
  data_table03_origin/tic-12.original.dzn \
  --precedence-encoding pairwise \
  --precedence-graph distance_closure \
  --encoding-variant imp12+ \
  --domain-mode full \
  --objective-mode ir_is \
  --compact-encoding optimized \
  --collision-amo adaptive_commander
```

## Test

```bash
python3 -m pip install -r src/requirements.txt
python3 -m unittest discover -s tests -v
```

The exact-model unit tests exercise the shared MIP coefficient matrix, sparse
occupancy variables, zero-based idle identity, CP global-constraint
specification, configuration expansion, and no-fallback behavior without
requiring a commercial license.
## Balanced-scheduling journal campaigns

The experiment suite first compares the models on their native feasible set.
The optional cap sensitivity study remains separate and is deferred until the
uncapped baseline has been evaluated.

| Config | Purpose | Jobs |
|---|---:|---:|
| `compact_objectives.json` | reference/A/C/D/F compact ablation for BG-d2, IR, and uncapped IR-IM-IS | 1,890 |
| `idle_cap_sensitivity.json` | deferred optional cap study at alpha 1/2, 3/4, and 1 | 378 |
| `main_objectives.json` | 2022 vs compact, three primary objectives, three repetitions | 2,268 rows; 378 reused, 1,890 new runs |
| `conference_historical_reuse.json` | audited archive of independent BG-d2 and published IR repetitions | 252 reused rows; no solver runs |
| `conference_reference.json` | conference compact backbone, three primary objectives, three repetitions | 1,134 rows; 630 reused, 504 new runs |
| `bg_dinf_quality.json` | Compact BG-d-infinity control on the common base-feasible set | 126 |
| generated by `Select_Final_Tier_Experiment.py` | IR-IM-ISQ on Compact C+D+F; reuse its main IR-IM-IS results | 378 |

Run the small gates first:

```bash
bash scripts/run_journal_gcp.sh compact-objectives-smoke
bash scripts/run_journal_gcp.sh main-objectives-smoke
bash scripts/run_journal_gcp.sh conference-reference-smoke
```

Then run the frozen campaigns in the order below. Each command remains
append-only and resumable, and accepts the existing
`SHARD_COUNT`/`SHARD_INDICES` environment variables. Sharded outputs are
written below a `shard-*-of-*` subdirectory. `main-objectives` imports the
matching BG-d2 A+C+F, IR C+D+F, and IR-IM-IS C+D+F repetition-1 rows from
`compact-objectives`; it executes only the remaining 1,890 jobs. With
sharding, each VM reuses its matching local compact shard by default. Set
`COMPACT_OBJECTIVES_OUTPUT` when using a merged source or a non-default path.
Merge every main-objective shard before running `final-tier`, and point
`MAIN_OBJECTIVES_OUTPUT` to that merged directory. The final-tier campaign can
then be sharded independently with the same variables.

```bash
bash scripts/run_journal_gcp.sh compact-objectives
bash scripts/run_journal_gcp.sh main-objectives
bash scripts/run_journal_gcp.sh prepare-conference-reuse
ALLOW_DIRTY=1 ALLOW_ENVIRONMENT_DRIFT=1 \
  bash scripts/run_journal_gcp.sh conference-reference
bash scripts/run_journal_gcp.sh bg-dinf-quality
bash scripts/run_journal_gcp.sh final-tier
```

When both completed main-objective shards are already present on one machine,
the complete Compact IR-IM-ISQ campaign can be launched with:

```bash
bash scripts/run_ir_im_isq_one_vm.sh
```

The helper merges the two main shards when needed, fixes the final-tier
baseline to Compact C+D+F, clears shard selection, and runs all 378 IR-IM-ISQ
jobs on that machine. Repeating the command resumes the same campaign.

### Resume the interrupted shard on a replacement VM

The committed `main-objectives/shard-1-of-2` normalized CSV contained all
1,134 assigned rows although 1,133 corresponding JSONL records were lost. They
can be restored without invoking a solver; every restored record contains the
CSV SHA-256 and `raw_record_origin=recovered_from_normalized_csv`:

```bash
python3 src/Recover_Journal_Results.py \
  --output outputs/journal/main-objectives/shard-1-of-2 \
  --allow-dirty \
  --allow-environment-drift
```

After that recovery, `main-objectives` has no missing shard-1 job. The
replacement VM only needs to solve the 217 missing `compact-objectives` jobs.
Use the same frozen two-shard assignment and explicitly accept the recorded VM
transition:

```bash
git pull --ff-only
export SHARD_COUNT=2
export SHARD_INDICES=1
export ALLOW_DIRTY=1
export ALLOW_ENVIRONMENT_DRIFT=1

bash scripts/run_journal_gcp.sh compact-objectives
bash scripts/run_journal_gcp.sh main-objectives
```

Resume identifies completed work by the immutable `run_key`. Terminal rows
(`OPTIMAL`, `UNSAT`, and `TIMEOUT`) are skipped; only absent rows are run.
`main-objectives` is still invoked so it can validate its reuse source and
materialize status, but it should report `pending_selected=0` after recovery.
The separate warm-up campaign may run again and is not part of these job
counts.

Once both shards are complete, mixed VM/Python/solver provenance must be
accepted explicitly during merge:

```bash
bash scripts/run_journal_gcp.sh merge-shards \
  --input outputs/journal/compact-objectives/shard-0-of-2 \
  --input outputs/journal/compact-objectives/shard-1-of-2 \
  --output outputs/journal/compact-objectives-merged \
  --allow-dirty \
  --allow-mixed-environments
```

The merged archive retains every source `environment.json` under
`environments/` and lists each accepted difference in its top-level
`environment.json`.

The main plan still contains all 2,268 comparison rows so validation and the
final-tier selector see three repetitions for both model families. Reused rows
are copied into the main archive with `result_origin=reused` and source
campaign, plan, run-key, configuration, repetition, and record-hash fields.

The conference-reference campaign keeps the three unsimplified reference
encodings in a separate frozen plan. IR is the conference configuration;
BG-d2 and IR-IM-IS retain its feasibility backbone and replace only the
objective layer. It imports 378 completed repetition-1 cells from
`compact-objectives`, an independent 126-row BG-d2 reference repetition, and
the 126-row published conference IR repetition. It therefore executes only
BG-d2 repetition 3, IR repetition 3, and IR-IM-IS repetitions 2--3: 504 new
runs.

`prepare-conference-reuse` is solver-free. It reconstructs a 252-row archive
from the checked-in result files and the fourth All-126 shard on
`origin/IR-IM-IS`. Before writing any row, it checks all 35 recorded formula
size fields, status, and the primary proven optimum against the current
reference result for every one of the 126 contents. The archive retains the
original configuration, Git commit, dirty flag, solver hash, source-row hash,
and a formula-identity certificate. Fetch `origin/IR-IM-IS` first if the clone
does not contain that remote-tracking branch.

Launch the final campaign with
`ALLOW_DIRTY=1 ALLOW_ENVIRONMENT_DRIFT=1`; these flags authorize the recorded
source provenance and do not alter reused rows. The runner rejects a missing,
incomplete, configuration-mismatched, or unaudited source rather than silently
accepting it.

The published IR repetition used a third UWrMaxSAT binary and is about 15%
faster than the current reference run in the paired archive audit. After the
conference and main archives have been merged, generate the mandatory
runtime/PAR-2/RSS sensitivity report with:

```bash
python3 src/Audit_Conference_Runtime_Sensitivity.py \
  --conference-csv outputs/journal/conference-reference/normalized/detailed.csv \
  --comparison-csv outputs/journal/main-objectives/normalized/detailed.csv \
  --output outputs/journal/conference-runtime-sensitivity.json \
  --require-stable-ranking
```

For sharded campaigns, repeat `--conference-csv` or `--comparison-csv` for
each shard, or point each option to the corresponding merged archive. The
report computes every IR summary and model ranking both with and without the
historical repetition; the strict flag fails if any PAR-2, runtime, or RSS
ranking changes.

`final-tier` first validates the complete main campaign. It writes the frozen
Compact C+D+F config and an audit report below `outputs/journal/`, then runs
only IR-IM-ISQ with the uncapped feasible set. The corresponding Compact
IR-IM-IS results are read from the completed main campaign and are not run
again. The audit report also records the observed cross-model ranking, but that
ranking does not change the prespecified Compact baseline for this objective
comparison.

The deferred cap study can later be run independently with
`cap-sensitivity-smoke` followed by `cap-sensitivity`; its rows are not part of
the baseline comparison or model selection.

For a read-only plan check without the wrapper:

```bash
python3 src/Journal_Experiment.py \
  --config journal_configs/main_objectives.json \
  --output-dir /tmp/b2b-main-plan \
  --plan-only
```

## First All-126 journal campaign (T1–T3)

The current journal matrix has **13 configurations per canonical input**:
7 BG-d2 fidelity/ablation cells, 4 waiting-objective cells (IR-IS, IS, ISQ,
IM-IS), and 2 additional IM-IS ablations. The IM-IS C+F cell is reused from
the quality block. Repetition 1 contains **1,638 jobs**, not 4,914.

From this repository root:

```bash
# Plan only; works locally without the GCP environment or UWrMaxSAT binary.
bash scripts/run_journal_gcp.sh all126-first-plan

# On GCP, using the existing journal_gcp.env pins and conference environment:
bash scripts/run_journal_gcp.sh all126-first-smoke
bash scripts/run_journal_gcp.sh all126-first
```

### Split the frozen All-126 campaign across two GCP VMs

Sharding changes only where a job runs; it does not change the 1,638-job plan,
its plan SHA-256, timeout, seed, objective, or solver settings. The assignment
is deterministic and content-paired: every configuration for one canonical
instance runs on the same VM. This avoids adding a VM effect inside paired
objective/encoding comparisons.

For a VM with relatively few credits and another with substantially more, use
four shards and allocate one versus three. Shards 2 and 3 contain 403 jobs;
shards 0 and 1 contain 416. On the low-credit VM:

| Approximate low:high credit ratio | `SHARD_COUNT` | Low VM indices/jobs | High VM indices/jobs |
|---|---:|---:|---:|
| 1:1 | 2 | `1` / 819 | `0` / 819 |
| 1:2 | 3 | `2` / 546 | `0,1` / 1,092 |
| 1:3 | 4 | `3` / 403 | `0,1,2` / 1,235 |

The commands below use the recommended 1:3 allocation. On the low-credit VM:

```bash
export SHARD_COUNT=4
export SHARD_INDICES=3
bash scripts/run_journal_gcp.sh all126-first-plan
bash scripts/run_journal_gcp.sh all126-first-smoke
bash scripts/run_journal_gcp.sh all126-first
```

On the high-credit VM, from the exact same clean Git commit, environment, data
manifest, and pinned UWrMaxSAT binary:

```bash
export SHARD_COUNT=4
export SHARD_INDICES=0,1,2
bash scripts/run_journal_gcp.sh all126-first-plan
bash scripts/run_journal_gcp.sh all126-first-smoke
bash scripts/run_journal_gcp.sh all126-first
```

The production output directories are respectively
`outputs/journal/all126-first/shard-3-of-4` and
`outputs/journal/all126-first/shards-0-1-2-of-4`. Repeating the same command on
the same VM resumes only that VM's assigned shards. If the low-credit VM must
be retired, first copy its whole, possibly incomplete shard directory to the
other VM at the same relative location, then run the low-VM command there; the
runner continues the unfinished shard without repeating terminal jobs.

After both parts finish, copy both directories to one machine and merge into a
new, empty destination:

```bash
bash scripts/run_journal_gcp.sh merge-shards \
  --input collected/shard-3-of-4 \
  --input collected/shards-0-1-2-of-4 \
  --output outputs/journal/all126-first-merged

python3 src/Validate_Journal_Run.py \
  --output outputs/journal/all126-first-merged
```

The merge command rejects overlapping/missing shards, incomplete jobs,
different plan or Git hashes, dirty production sources, different Python or
solver hashes, and incompatible CPU environments. It retains the two source
environment records and VM-separated logs before performing strict validation
of all 1,638 run keys.

The smoke gate is 156 development jobs at 300 s; production is 1,638 jobs
at 7,200 s each. Production preserves the conference CPU/RAM/no-swap profile,
one worker, one solver thread, and seed 0. Warm-up is separate from those counts.
The new commands do not require Generated-300 or launch the older broad campaigns.
Review and commit the source/configuration changes before copying the same
clean commit to GCP. Keep `ALLOW_DIRTY=0` for production and use the pinned
`UWRMAXSAT_BIN` and `UWRMAXSAT_SHA256` in `journal_gcp.env`.

Default output: `outputs/journal/all126-first/`, containing `plan.json`,
`environment.json`, append-only `raw/results.jsonl`, normalized CSV and logs.
Run `all126-first` again after an interruption: completed terminal jobs are
skipped and unfinished jobs are resumed under the same plan/environment.
Do not change the manifest, code commit or solver binary mid-campaign.
`RETRY_ERRORS=1` retries ERROR records; TIMEOUT is a completed observation.

```bash
bash scripts/run_journal_gcp.sh validate outputs/journal/all126-first
```

`--objective-mode is` minimizes total internal idle, `isq` minimizes its sum
of squares, and `im_is` lexicographically minimizes maximum then total idle.
`--objective-mode ir_im_is` minimizes idle range first, maximum individual
idle second, and total idle third. Its exact one-shot MaxSAT weights are
`((U_max + 1)(U_sum + 1), U_sum + 1, 1)`, so every higher-priority unit
strictly dominates all possible lower-tier costs. It is available for a
focused sensitivity study but is intentionally not inserted into the frozen
1,638-job first-repetition matrix. A development run is, for example:

```bash
python3 src/Main.py --solver maxsat --objective-mode ir_im_is \
  --compact-encoding optimized --collision-amo adaptive_commander \
  --domain-mode reduced --maxsat-backend rc2 \
  --instance data_table03_origin/forum-13.original.dzn --no-excel
```

ISQ uses odd threshold weights (1,3,5,...), not duplicated unit literals;
it is MaxSAT-only. IM-IS uses exact maximum thresholds with dominating weight
`U_sum + 1` and one weighted-MaxSAT call, including all setup and optimization
in the common timeout. Its optional SAT implementation uses maximum-threshold
tiers; direct-cap SAT and threshold-free E are not part of this campaign.
Results include maximum idle, squared idle, coefficient bit lengths and full
objective vectors. RC2 is an explicit development backend, never a production
fallback. Three repetitions would total 4,914 jobs but are not launched by
`all126-first`.
