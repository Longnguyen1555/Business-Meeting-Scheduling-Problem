#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PROJECT_DIR=$(cd -- "$SCRIPT_DIR/.." && pwd)
cd "$PROJECT_DIR"

# Planning is read-only with respect to solver state and needs no GCP pins.
if [[ "${1:-}" == "all126-first-plan" ]]; then
  plan_env_file=${JOURNAL_ENV_FILE:-$PROJECT_DIR/journal_gcp.env}
  if [[ -f "$plan_env_file" ]]; then
    # shellcheck disable=SC1090
    source "$plan_env_file"
  fi
  plan_python=${PLAN_PYTHON:-python3}
  if [[ -z "${PLAN_PYTHON:-}" && -x "${JOURNAL_VENV:-.venv-ubuntu}/bin/python" ]]; then
    plan_python="${JOURNAL_VENV:-.venv-ubuntu}/bin/python"
  fi
  plan_shard_args=()
  if [[ -n "${SHARD_COUNT:-}" || -n "${SHARD_INDICES:-}" ]]; then
    if [[ ! "${SHARD_COUNT:-}" =~ ^[1-9][0-9]*$ || -z "${SHARD_INDICES:-}" ]]; then
      echo "ERROR: set SHARD_COUNT and comma-separated SHARD_INDICES together" >&2
      exit 2
    fi
    plan_shard_args+=(--shard-count "$SHARD_COUNT")
    IFS=',' read -r -a plan_shard_indices <<< "$SHARD_INDICES"
    for plan_shard_index in "${plan_shard_indices[@]}"; do
      plan_shard_args+=(--shard-index "$plan_shard_index")
    done
  fi
  exec "$plan_python" src/Journal_Experiment.py \
    --config journal_configs/all126_first.json \
    --output-dir "${OUTPUT_ROOT:-$PROJECT_DIR/outputs/journal}/all126-first" \
    --plan-only \
    "${plan_shard_args[@]}"
fi

# Merging completed shards is a local, solver-free operation.
if [[ "${1:-}" == "merge-shards" ]]; then
  shift
  merge_python=${PLAN_PYTHON:-python3}
  exec "$merge_python" src/Merge_Journal_Shards.py "$@"
fi

# Historical reuse preparation is solver-free and verifies every archived row
# against the checked-in current reference results before writing an archive.
if [[ "${1:-}" == "prepare-conference-reuse" ]]; then
  prepare_python=${PLAN_PYTHON:-python3}
  exec "$prepare_python" src/Prepare_Conference_Reuse.py \
    --output "${CONFERENCE_HISTORICAL_REUSE_OUTPUT:-${OUTPUT_ROOT:-$PROJECT_DIR/outputs/journal}/conference-historical-reuse}"
fi

ENV_FILE=${JOURNAL_ENV_FILE:-$PROJECT_DIR/journal_gcp.env}
if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: copy journal_gcp.env.example to $ENV_FILE and fill the pins" >&2
  exit 2
fi
# shellcheck disable=SC1090
source "$ENV_FILE"

JOURNAL_VENV=${JOURNAL_VENV:-.venv-ubuntu}
OUTPUT_ROOT=${OUTPUT_ROOT:-$PROJECT_DIR/outputs/journal}
ALLOW_DIRTY=${ALLOW_DIRTY:-0}
ALLOW_ENVIRONMENT_DRIFT=${ALLOW_ENVIRONMENT_DRIFT:-0}
RETRY_ERRORS=${RETRY_ERRORS:-0}
SHARD_COUNT=${SHARD_COUNT:-}
SHARD_INDICES=${SHARD_INDICES:-}

if [[ -n "$SHARD_COUNT" || -n "$SHARD_INDICES" ]]; then
  if [[ ! "$SHARD_COUNT" =~ ^[1-9][0-9]*$ || -z "$SHARD_INDICES" ]]; then
    echo "ERROR: set SHARD_COUNT and comma-separated SHARD_INDICES together" >&2
    exit 2
  fi
fi

shard_args=()
shard_label=""
if [[ -n "$SHARD_COUNT" ]]; then
  shard_args+=(--shard-count "$SHARD_COUNT")
  IFS=',' read -r -a shard_index_values <<< "$SHARD_INDICES"
  for shard_index in "${shard_index_values[@]}"; do
    if [[ ! "$shard_index" =~ ^[0-9]+$ || "$shard_index" -ge "$SHARD_COUNT" ]]; then
      echo "ERROR: invalid shard index $shard_index for SHARD_COUNT=$SHARD_COUNT" >&2
      exit 2
    fi
    shard_args+=(--shard-index "$shard_index")
  done
  shard_suffix=${SHARD_INDICES//,/-}
  if [[ "$SHARD_INDICES" == *,* ]]; then
    shard_label="shards-$shard_suffix-of-$SHARD_COUNT"
  else
    shard_label="shard-$shard_suffix-of-$SHARD_COUNT"
  fi
fi

if [[ ! -x "$JOURNAL_VENV/bin/python" ]]; then
  echo "ERROR: missing Python environment $JOURNAL_VENV" >&2
  exit 2
fi
if [[ -z "${UWRMAXSAT_BIN:-}" || ! -x "$UWRMAXSAT_BIN" ]]; then
  echo "ERROR: UWRMAXSAT_BIN is missing or not executable" >&2
  exit 2
fi
if [[ ! "${UWRMAXSAT_SHA256:-}" =~ ^[0-9a-f]{64}$ ]]; then
  echo "ERROR: UWRMAXSAT_SHA256 is not a 64-digit lowercase hash" >&2
  exit 2
fi
actual_hash=$(sha256sum "$UWRMAXSAT_BIN" | awk '{print $1}')
if [[ "$actual_hash" != "$UWRMAXSAT_SHA256" ]]; then
  echo "ERROR: UWrMaxSAT hash mismatch: $actual_hash" >&2
  exit 2
fi
if [[ "$ALLOW_DIRTY" != "1" && -n "$(git status --porcelain)" ]]; then
  echo "ERROR: production runs require a clean worktree" >&2
  git status --short >&2
  exit 2
fi

mkdir -p "$OUTPUT_ROOT"
exec 9>"$OUTPUT_ROOT/.campaign.lock"
if ! flock -n 9; then
  echo "ERROR: another journal campaign holds $OUTPUT_ROOT/.campaign.lock" >&2
  exit 2
fi

export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
export PYTHONHASHSEED=0

PYTHON="$JOURNAL_VENV/bin/python"
RUNNER=("$PYTHON" -u src/Journal_Experiment.py)
if [[ -n "${CPU_CORE:-}" ]]; then
  if ! taskset -c "$CPU_CORE" true >/dev/null 2>&1; then
    echo "ERROR: CPU_CORE=$CPU_CORE is not available to this VM/process" >&2
    exit 2
  fi
  RUNNER=(taskset -c "$CPU_CORE" "${RUNNER[@]}")
fi

runner_common=(
  --uwrmaxsat-bin "$UWRMAXSAT_BIN"
  --uwrmaxsat-sha256 "$UWRMAXSAT_SHA256"
)
if [[ "$ALLOW_DIRTY" == "1" ]]; then
  runner_common+=(--allow-dirty)
fi
if [[ "$ALLOW_ENVIRONMENT_DRIFT" == "1" ]]; then
  runner_common+=(--allow-environment-drift)
fi
if [[ "$RETRY_ERRORS" == "1" ]]; then
  runner_common+=(--retry-errors)
fi

run_campaign() {
  local config_name=$1
  local output_name=$2
  shift 2
  local output_dir="$OUTPUT_ROOT/$output_name"
  local resume_args=()
  if [[ -f "$output_dir/plan.json" ]]; then
    resume_args+=(--resume)
  fi
  local runner_status=0
  local validator_status=0
  "${RUNNER[@]}" \
    --config "journal_configs/$config_name.json" \
    --output-dir "$output_dir" \
    "${runner_common[@]}" \
    "${resume_args[@]}" \
    "$@" || runner_status=$?
  validate_existing "$output_dir" || validator_status=$?
  if [[ "$runner_status" -ne 0 ]]; then
    return "$runner_status"
  fi
  return "$validator_status"
}

run_campaign_config_path() {
  local config_path=$1
  local output_name=$2
  shift 2
  local output_dir="$OUTPUT_ROOT/$output_name"
  local resume_args=()
  if [[ -f "$output_dir/plan.json" ]]; then
    resume_args+=(--resume)
  fi
  local runner_status=0
  local validator_status=0
  "${RUNNER[@]}" \
    --config "$config_path" \
    --output-dir "$output_dir" \
    "${runner_common[@]}" \
    "${resume_args[@]}" \
    "$@" || runner_status=$?
  validate_existing "$output_dir" || validator_status=$?
  if [[ "$runner_status" -ne 0 ]]; then
    return "$runner_status"
  fi
  return "$validator_status"
}

plan_campaign() {
  local config_name=$1
  local output_name=$2
  shift 2
  local output_dir="$OUTPUT_ROOT/$output_name"
  local resume_args=()
  if [[ -f "$output_dir/plan.json" ]]; then
    resume_args+=(--resume)
  fi
  "${RUNNER[@]}" \
    --config "journal_configs/$config_name.json" \
    --output-dir "$output_dir" \
    --plan-only \
    "${resume_args[@]}" \
    "$@"
}

generate_data() {
  if [[ -d data_journal_generated ]]; then
    "$PYTHON" src/Generate_Journal_Benchmark.py validate \
      --data-dir data_journal_generated
  else
    "$PYTHON" src/Generate_Journal_Benchmark.py generate \
      --output-dir data_journal_generated \
      --n-development 240 \
      --n-heldout 60 \
      --master-seed 20260808
    "$PYTHON" src/Generate_Journal_Benchmark.py validate \
      --data-dir data_journal_generated
  fi
}

require_generated_data() {
  if [[ ! -d data_journal_generated ]]; then
    echo "ERROR: run '$0 generate', audit the manifests, and commit the frozen dataset first" >&2
    exit 2
  fi
  "$PYTHON" src/Generate_Journal_Benchmark.py validate \
    --data-dir data_journal_generated
}

extract_features() {
  local feature_file="$OUTPUT_ROOT/instance_features.csv"
  if [[ -f "$feature_file" ]]; then
    echo "feature file already frozen: $feature_file"
    return
  fi
  "$PYTHON" src/Journal_Instance_Features.py \
    --dataset official:instances_manifest.csv \
    --dataset stress:data_precedence_stress/instances_manifest.csv \
    --dataset stress_high:data_precedence_stress_high/instances_manifest.csv \
    --dataset generated:data_journal_generated/instances_manifest.csv \
    --family all \
    --output "$feature_file"
}

audit_coverage() {
  local audit_dir="$OUTPUT_ROOT/coverage_audit"
  if [[ -f "$audit_dir/coverage_summary.json" ]]; then
    echo "coverage audit already frozen: $audit_dir/coverage_summary.json"
    return
  fi
  "$PYTHON" src/Audit_Journal_Coverage.py \
    --features "$OUTPUT_ROOT/instance_features.csv" \
    --generation-manifest data_journal_generated/generation_manifest.csv \
    --output-dir "$audit_dir"
}

validate_existing() {
  local output_dir=$1
  local validation_args=()
  if [[ "$ALLOW_DIRTY" == "1" ]]; then
    validation_args+=(--allow-dirty)
  fi
  if [[ "$ALLOW_ENVIRONMENT_DRIFT" == "1" ]]; then
    validation_args+=(--allow-environment-drift)
  fi
  if [[ -n "$SHARD_COUNT" ]]; then
    validation_args+=(--allow-incomplete)
  fi
  "$PYTHON" src/Validate_Journal_Run.py \
    --output "$output_dir" "${validation_args[@]}"
}

run_warmup() {
  local boot_id
  local commit_id
  boot_id=$(cat /proc/sys/kernel/random/boot_id)
  commit_id=$(git rev-parse --short=12 HEAD)
  run_campaign warmup "warmup/$boot_id/$commit_id"
}

command=${1:-help}
case "$command" in
  setup)
    "$SCRIPT_DIR/setup_journal_gcp.sh"
    ;;
  generate)
    generate_data
    ;;
  features)
    require_generated_data
    extract_features
    audit_coverage
    ;;
  coverage)
    require_generated_data
    extract_features
    audit_coverage
    ;;
  correctness)
    run_campaign correctness correctness-development
    ;;
  smoke)
    run_campaign production_smoke production-smoke
    ;;
  compact-smoke)
    run_campaign compact_smoke compact-smoke
    ;;
  compact-f-smoke)
    run_campaign compact_f_smoke compact-f-smoke
    ;;
  compact-objectives-smoke)
    run_campaign compact_objectives_smoke compact-objectives-smoke
    ;;
  cap-sensitivity-smoke)
    run_campaign idle_cap_sensitivity_smoke idle-cap-sensitivity-smoke
    ;;
  main-objectives-smoke)
    run_campaign main_objectives_smoke main-objectives-smoke
    ;;
  conference-reference-smoke)
    run_campaign conference_reference_smoke conference-reference-smoke
    ;;
  bg-dinf-quality-smoke)
    run_campaign bg_dinf_quality_smoke bg-dinf-quality-smoke
    ;;
  all126-first-smoke)
    smoke_output=all126-first-smoke
    if [[ -n "$shard_label" ]]; then
      smoke_output="$smoke_output/$shard_label"
    fi
    run_campaign all126_first_smoke "$smoke_output" "${shard_args[@]}"
    ;;
  all126-first)
    run_warmup
    first_output=all126-first
    if [[ -n "$shard_label" ]]; then
      first_output="$first_output/$shard_label"
    fi
    run_campaign all126_first "$first_output" "${shard_args[@]}"
    ;;
  pilot)
    require_generated_data
    run_warmup
    run_campaign pilot stratified-pilot
    ;;
  official)
    run_warmup
    run_campaign official_core official-core
    ;;
  precedence)
    run_warmup
    run_campaign precedence_ablation precedence-ablation
    ;;
  compact)
    run_warmup
    run_campaign compact_ablation compact-ablation
    ;;
  compact-f)
    run_warmup
    run_campaign compact_f_ablation compact-f-ablation
    ;;
  compact-objectives)
    run_warmup
    compact_objectives_output=compact-objectives
    if [[ -n "$shard_label" ]]; then
      compact_objectives_output="$compact_objectives_output/$shard_label"
    fi
    run_campaign compact_objectives "$compact_objectives_output" "${shard_args[@]}"
    ;;
  cap-sensitivity)
    run_warmup
    cap_sensitivity_output=idle-cap-sensitivity
    if [[ -n "$shard_label" ]]; then
      cap_sensitivity_output="$cap_sensitivity_output/$shard_label"
    fi
    run_campaign idle_cap_sensitivity "$cap_sensitivity_output" "${shard_args[@]}"
    ;;
  main-objectives)
    run_warmup
    main_objectives_output=main-objectives
    compact_reuse_output=${COMPACT_OBJECTIVES_OUTPUT:-}
    if [[ -n "$shard_label" ]]; then
      main_objectives_output="$main_objectives_output/$shard_label"
      if [[ -z "$compact_reuse_output" ]]; then
        compact_reuse_output="$OUTPUT_ROOT/compact-objectives/$shard_label"
      fi
    elif [[ -z "$compact_reuse_output" ]]; then
      if [[ -d "$OUTPUT_ROOT/compact-objectives-merged" ]]; then
        compact_reuse_output="$OUTPUT_ROOT/compact-objectives-merged"
      else
        compact_reuse_output="$OUTPUT_ROOT/compact-objectives"
      fi
    fi
    if [[ ! -f "$compact_reuse_output/plan.json" ]]; then
      echo "ERROR: main-objectives reuses compact-objectives repetition 1" >&2
      echo "ERROR: missing reuse source $compact_reuse_output" >&2
      echo "ERROR: run compact-objectives first or set COMPACT_OBJECTIVES_OUTPUT" >&2
      exit 2
    fi
    run_campaign main_objectives "$main_objectives_output" \
      --reuse-output "$compact_reuse_output" \
      "${shard_args[@]}"
    ;;
  conference-reference)
    if [[ "$ALLOW_DIRTY" != "1" || "$ALLOW_ENVIRONMENT_DRIFT" != "1" ]]; then
      echo "ERROR: conference-reference reuses approved mixed-environment and historical repetitions" >&2
      echo "ERROR: set ALLOW_DIRTY=1 and ALLOW_ENVIRONMENT_DRIFT=1 to record that approval" >&2
      exit 2
    fi
    run_warmup
    conference_reference_output=conference-reference
    compact_reuse_output=${COMPACT_OBJECTIVES_OUTPUT:-}
    historical_reuse_output=${CONFERENCE_HISTORICAL_REUSE_OUTPUT:-$OUTPUT_ROOT/conference-historical-reuse}
    if [[ -n "$shard_label" ]]; then
      conference_reference_output="$conference_reference_output/$shard_label"
      if [[ -z "$compact_reuse_output" ]]; then
        compact_reuse_output="$OUTPUT_ROOT/compact-objectives/$shard_label"
      fi
    elif [[ -z "$compact_reuse_output" ]]; then
      if [[ -d "$OUTPUT_ROOT/compact-objectives-merged" ]]; then
        compact_reuse_output="$OUTPUT_ROOT/compact-objectives-merged"
      else
        compact_reuse_output="$OUTPUT_ROOT/compact-objectives"
      fi
    fi
    if [[ ! -f "$compact_reuse_output/plan.json" ]]; then
      echo "ERROR: conference-reference reuses compact-objectives repetition 1" >&2
      echo "ERROR: missing reuse source $compact_reuse_output" >&2
      echo "ERROR: merge compact-objectives or set COMPACT_OBJECTIVES_OUTPUT" >&2
      exit 2
    fi
    if [[ ! -f "$historical_reuse_output/plan.json" ]]; then
      "$PYTHON" src/Prepare_Conference_Reuse.py \
        --output "$historical_reuse_output"
    fi
    run_campaign conference_reference "$conference_reference_output" \
      --reuse-output "$compact_reuse_output" \
      --reuse-output "$historical_reuse_output" \
      "${shard_args[@]}"
    ;;
  bg-dinf-quality)
    run_warmup
    bg_dinf_output=bg-dinf-quality
    if [[ -n "$shard_label" ]]; then
      bg_dinf_output="$bg_dinf_output/$shard_label"
    fi
    run_campaign bg_dinf_quality "$bg_dinf_output" "${shard_args[@]}"
    ;;
  final-tier)
    main_output=${MAIN_OBJECTIVES_OUTPUT:-$OUTPUT_ROOT/main-objectives}
    final_config="$OUTPUT_ROOT/final-tier-compact.json"
    selector_args=()
    if [[ "$ALLOW_DIRTY" == "1" ]]; then
      selector_args+=(--allow-dirty)
    fi
    if [[ "$ALLOW_ENVIRONMENT_DRIFT" == "1" ]]; then
      selector_args+=(--allow-environment-drift)
    fi
    "$PYTHON" src/Select_Final_Tier_Experiment.py \
      --main-output "$main_output" \
      --main-config journal_configs/main_objectives.json \
      --output-config "$final_config" \
      "${selector_args[@]}"
    run_warmup
    final_tier_output=final-tier-compact
    if [[ -n "$shard_label" ]]; then
      final_tier_output="$final_tier_output/$shard_label"
    fi
    run_campaign_config_path "$final_config" "$final_tier_output" "${shard_args[@]}"
    ;;
  generated-development)
    require_generated_data
    run_warmup
    run_campaign generated_core generated-development \
      --only-block e5_generated_development
    ;;
  generated-heldout)
    if [[ "${HELDOUT_FROZEN:-}" != "YES" ]]; then
      echo "ERROR: set HELDOUT_FROZEN=YES only after confirming the fixed timeout and freezing model/analysis" >&2
      exit 2
    fi
    require_generated_data
    run_warmup
    run_campaign generated_core generated-heldout \
      --only-block e5_generated_heldout
    ;;
  plan)
    require_generated_data
    plan_campaign production_smoke production-smoke
    plan_campaign pilot stratified-pilot
    plan_campaign official_core official-core
    plan_campaign precedence_ablation precedence-ablation
    plan_campaign compact_smoke compact-smoke
    plan_campaign compact_ablation compact-ablation
    plan_campaign compact_f_smoke compact-f-smoke
    plan_campaign compact_f_ablation compact-f-ablation
    plan_campaign compact_objectives compact-objectives
    plan_campaign main_objectives main-objectives
    plan_campaign conference_reference conference-reference
    plan_campaign bg_dinf_quality bg-dinf-quality
    plan_campaign generated_core generated-development \
      --only-block e5_generated_development
    plan_campaign generated_core generated-heldout \
      --only-block e5_generated_heldout
    ;;
  all-development)
    require_generated_data
    extract_features
    audit_coverage
    run_campaign correctness correctness-development
    run_campaign production_smoke production-smoke
    run_warmup
    run_campaign pilot stratified-pilot
    echo "Pilot complete. Confirm compute/matrix/analysis; cutoff remains fixed at 7200 seconds."
    ;;
  validate)
    if [[ $# -ne 2 ]]; then
      echo "usage: $0 validate OUTPUT_DIRECTORY" >&2
      exit 2
    fi
    validate_existing "$2"
    ;;
  help|-h|--help)
    cat <<'EOF'
Usage: scripts/run_journal_gcp.sh COMMAND

Commands:
  setup                  verify the existing conference environment
  generate               freeze/validate Generated-300
  features               extract all pre-solve feature rows once
  coverage               extract features and audit marginal/joint coverage
  correctness             local RC2/CaDiCaL 12-content gate
  smoke                   pinned production solver 12-content gate
  compact-smoke           pinned A-D compact gate (168 runs)
  compact-f-smoke         pinned optimized-vs-F gate (72 runs)
  compact-objectives-smoke  two-input A/C/D/F x objective gate (30 runs)
  cap-sensitivity-smoke   deferred optional two-input cap-alpha gate (6 runs)
  main-objectives-smoke   two-input 2-model x 3-objective gate (12 runs)
  conference-reference-smoke  two-input conference-backbone x 3-objective gate (6 runs)
  bg-dinf-quality-smoke   two-input Compact BG-d-infinity gate (2 runs)
  all126-first-plan       freeze/check 1,638 jobs; no GCP env or solver needed
  all126-first-smoke      all 13 configurations on 12 inputs (156 development runs)
  all126-first            T1-T3 All-126, repetition 1 only (1,638 runs)
  merge-shards ARGS       merge complete disjoint VM outputs and validate them
  pilot                   7,200-second development-only stratified pilot
  official                E1-E3 All-126 (8,820 runs)
  precedence              E4 2x2x2 ablation (3,360 runs)
  compact                 paired A-D All-126 ablation (5,292 runs)
  compact-f               paired F All-126 ablation (2,268 runs)
  compact-objectives      A/C/D/F x BG-d2/IR/uncapped IR-IM-IS (1,890 runs)
  cap-sensitivity         deferred optional compact cap-alpha study (378 runs)
  main-objectives         2 models x 3 objectives x 3 reps (378 reused; 1,890 new)
  prepare-conference-reuse audit/build the 252-row BG-d2/IR historical archive
  conference-reference    conference backbone x 3 objectives x 3 reps (630 reused; 504 new)
  bg-dinf-quality         Compact BG-d-infinity x All-126 x 1 rep (126 runs)
  final-tier              run Compact C+D+F IR-IM-ISQ only (378 runs)
  generated-development   E5 Development-240 only
  generated-heldout       E5 Held-out-60; requires HELDOUT_FROZEN=YES
  plan                    create and report active uncapped deterministic plans
  all-development         features, coverage, correctness, smoke and pilot
  validate DIR            strictly validate one completed campaign

Every campaign is single-worker, append-only and resumable. Re-run the same
command after interruption; the script adds --resume automatically.
Set SHARD_COUNT=N and SHARD_INDICES=i[,j...] to divide one unchanged plan
between VMs. Shard indices are zero-based.
main-objectives requires the matching compact-objectives output and reuses its
three selected repetition-1 cells. Set COMPACT_OBJECTIVES_OUTPUT only when the
source is outside the default matching shard/output directory.
conference-reference reuses the three reference repetition-1 cells from the
compact source plus audited historical BG-d2 and IR repetition-2 cells. It
builds the historical archive if needed. Set ALLOW_DIRTY=1 and
ALLOW_ENVIRONMENT_DRIFT=1 to record the approved source provenance.
Set RETRY_ERRORS=1 only to create a new attempt for existing ERROR rows.
Set ALLOW_ENVIRONMENT_DRIFT=1 only when deliberately resuming an unchanged
plan after a VM, Git commit, Python/kernel, or pinned solver-binary change.
EOF
    ;;
  *)
    echo "ERROR: unknown command: $command" >&2
    exit 2
    ;;
esac
